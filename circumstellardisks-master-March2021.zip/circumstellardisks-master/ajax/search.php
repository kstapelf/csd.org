<?php

define("root","../");
require "../library.inc.php";

//deal with 19 fields individually
/*
d_name
d_ra
d_dec
d_nearby

d_spty
d_sfr
d_category
d_class

d_diameterunits

d_rmagmin
d_rmagmax
d_distmin
d_distmax
d_diametermin
d_diametermax

status

r_title
r_authors
r_datemin
r_datemax

include
*/

//build query
$query = "SELECT d.*, COUNT() as count FROM disks AS d INNER JOIN disk_refs AS dr ON d.disk_id = dr.disk_id";
$conditions = array();
$args = array();

//tables needed: disks and disk_refs, if include references, refs
$data = $_POST;


//Disk Details
$name = $data['d_name'];
if ($name) {
	$conditions[] = "(d.name LIKE ? OR d.secondname LIKE ?)";
	$args[] = "%".$name."%";
	$args[] = "%".$name."%";
}

$ra = position_to_degrees($data['d_ra']);
$dec = position_to_degrees($data['d_dec']);
if (is_numeric($ra) && is_numeric($dec) && is_numeric($data['d_nearby'])) { //if search nearby
	$arr = near($ra,$dec,$data['d_nearby']);
	if ($arr["query"]) {
		$conditions[] = $arr["query"];
		$args = array_merge($args,$arr['args']);
	}
} else if (is_numeric($ra)) {
	$conditions[] = "ra_deg = ?";
	$args[] = $ra;
} else if (is_numeric($dec)) {
	$conditions[] = "dec_deg = ?";
	$args[] = $dec;
}

$boring = array("spty","sfr","category","class");

foreach ($boring as $col) {
	if ($data["d_".$col] && check_disk_col($col)) {
		$conditions[] = "d.$col LIKE ?";
		$args[] = $data["d_".$col];
	}
}

if ($data['d_diameterunits'] == "AU") {
	$data['d_size_aumin'] = $data['d_diametermin'];
	$data['d_size_aumax'] = $data['d_diametermax'];
} else {
	$data['d_majorextentmin'] = $data['d_diametermin'];
	$data['d_majorextentmax'] = $data['d_diametermax'];
}

$between = array("rmag","dist","majorextent","size_au");

foreach ($between as $col) {
	if (check_disk_col($col)) {
		if (isset($data["d_".$col."min"])) {
			$conditions[] = "d.$col >= ?";
			$args[] = $data["d_".$col."min"];
		}
		if (isset($data["d_".$col."max"])) {
			$conditions[] = "d.$col <= ?";
			$args[] = $data["d_".$col."max"];
		}
	}
}


if (count($data['status'])) {
	$conditions[] = "status IN (".trim(str_repeat('?,',count($data['status'])),',').")";
	$args = array_merge($args,$data['status']);
}



if ($data['r_title']) {
	$titles = array_map(function($t) { return "%".trim($t)."%"; },explode(",",$data['r_title']));
	if ($data['r_titlecombine']=="AND") {
		$conditions = array_merge($conditions,array_pad(array(),count($titles),"d.disk_id IN (SELECT dr.disk_id FROM disk_refs AS dr 
							INNER JOIN refs AS r ON r.ref_id = dr.ref_id WHERE r.title LIKE ?)"));
	} else {
		$conditions[] = "d.disk_id IN (SELECT dr.disk_id FROM disk_refs AS dr 
							INNER JOIN refs AS r ON r.ref_id = dr.ref_id 
							WHERE ".implode(" OR ",array_pad(array(),count($titles),"r.title LIKE ?")).")";
	}
	implode(" OR ",array_pad(array(),count($titles),""));
	$args = array_merge($args,$titles);
}
if ($data['r_authors']) {
	$authors = array_map(function($t) { return "%".trim($t)."%"; },explode(",",$data['r_authors']));
	if ($data['r_authorcombine']=="AND") {
		$conditions = array_merge($conditions,array_pad(array(),count($authors),"d.disk_id IN (SELECT dr.disk_id FROM disk_refs AS dr 
							INNER JOIN refs AS r ON r.ref_id = dr.ref_id WHERE r.authors LIKE ?)"));
	} else {
		$conditions[] = "d.disk_id IN (SELECT dr.disk_id FROM disk_refs AS dr 
							INNER JOIN refs AS r ON r.ref_id = dr.ref_id 
							WHERE ".implode(" OR ",array_pad(array(),count($authors),"r.authors LIKE ?")).")";
	}
	implode(" OR ",array_pad(array(),count($authors),""));
	$args = array_merge($args,$authors);
}

//Reference Details
if (isset($data['r_datemin'])||isset($data['r_datemax'])) {
	$query .= " INNER JOIN refs AS r ON dr.ref_id = r.ref_id";
}

if (isset($data['r_datemin'])) {
	$conditions[] = "r.date_dec >= ?";
	$args[] = date_to_dec($data['r_datemin']);
}

if (isset($data['r_datemax'])) {
	$conditions[] = "r.date_dec <= ?";
	$args[] = date_to_dec($data['r_datemax']);
}

//include
if (isset($data['include']) && count($data['include'])) {
	if (in_array("photo",$data['include'])) {
		$conditions[] = 'NOT dr.photo IS NULL AND NOT dr.photo = ""';
	}
	
	if (in_array("photometry",$data['include'])) {
		$conditions[] = "d.disk_id IN (SELECT disk_id FROM disk_bands)";
	}
}


$query_order_arr = order_disks($data['order'],$ra,$dec);

$orderstr = $query_order_arr[0].$query_order_arr[1];

$query = $query.(count($conditions)>0?" WHERE ":"").implode(" AND ",$conditions)." GROUP BY dr.disk_id";

$disks = call_user_func_array(prepare_query,array_merge(array($query.$orderstr),$args,$query_order_arr[2]));

echo '<ul id="tabbar"><li class="col-12 nohover" style="max-width:100%;"><span>Total number of disks: '.count($disks).'</span></li></ul>
<hr class="clear" />';


if ($_POST['compare_photometry']!="true") {

	$col_order = 'order_resolved';
	$cols_1 = query("SELECT * FROM disk_cols WHERE ".$col_order." >= 0 ORDER BY ".$col_order);
	$cols_2 = query("SELECT * FROM disk_cols WHERE ".$col_order." < 0 AND NOT ".$col_order."= -5");

	echo '<div class="container"><div><div class="col-6 border-right wide-align-right clickable" id="colvis"></div><div class="col-6"><a class="clickable" id="csv" href="#">Download as .csv</a></div></div></div>
	<hr class="clear" />
	<div class="scroller1"><div></div></div>
	<div class="scroller2">
	<table id="object_table" class="fake-link cell-border compact">';


	echo '<thead><tr class="manual-alternate1">';
	foreach ($cols_1 as $c) {
		echo '<th col="'.$c['col'].'"><br>'.$c['display'].'</th>';
	}
	echo '<th col="numref"><br># References</th>';
	foreach ($cols_2 as $c) {
		echo '<th col="'.$c['col'].'"><br>'.$c['display'].'</th>';
	}
	echo '</tr></thead><tbody>';
	
	foreach ($disks as $disk) {
		$first = true;
		echo '<tr class="alternate" diskid="'.$disk['disk_id'].'">';
		foreach ($cols_1 as $c) {
			if ($c['type']=="boolean") {
				$str = ($disk[$c['col']])?"Yes":"No";
			} else $str = display_string($disk[$c['col']]);
			echo '<td>';
			if ($first) echo '<a href="show.php?id='.$disk['disk_id'].'&name='.display_string($disk[$c['col']]).'">';
			echo $str;
			if ($first) echo "</a>";
			echo '</td>';
			$first = false;
		}
		echo '<td>'.$disk['count'].'</td>';
		foreach ($cols_2 as $c) {
			if ($c['type']=="boolean") {
				$str = ($disk[$c['col']])?"Yes":"No";
			} else $str = display_string($disk[$c['col']]);
			echo "<td>$str</td>";
		}
		echo '</tr>';
	}
	echo '
	</tbody></table>
	</div>';

} else {
	$bands = query("SELECT * FROM bands AS b
						INNER JOIN (SELECT source, MIN(wavelength) AS min FROM bands GROUP BY source) AS sort ON sort.source = b.source
						ORDER BY sort.min ASC, b.wavelength ASC");
	echo '<div style="width:100%;text-align:center" class="clickable" id="colvis"></div>
	<hr class="clear" />
	<div class="scroller1"><div></div></div>
	<div class="scroller2">
	
	<table id="object_table" class="fake-link cell-border compact">';
	
	echo '<thead><tr class="manual-alternate1">';
	$name_label = prepare_query1("SELECT display FROM disk_cols WHERE col = ?","name");
	$ra_label = prepare_query1("SELECT display FROM disk_cols WHERE col = ?","ra");
	$dec_label = prepare_query1("SELECT display FROM disk_cols WHERE col = ?","dec");
	echo '<th><br>'.($name_label[0]).'</th>';
	echo '<th><br>'.($ra_label[0]).'</th>';
	echo '<th><br>'.($dec_label[0]).'</th>';
	
	foreach ($bands as $b) {
		echo '<th><br>'.$b['band'].'<br>('.$b['source'].')</th>';
	}
	echo '</tr></thead><tbody>';
	
	$stmt = prepare_multiquery("SELECT magnitude AS mag, uncertainty AS unc, units FROM disk_bands WHERE disk_id = ? AND band_id = ?");
	
	foreach ($disks as $disk) {
		echo '<tr class="alternate" diskid="'.$disk['disk_id'].'">';
		echo '<td class="text"><a href="show/viewmag.php?id='.$disk['disk_id'].'">'.display_string($disk['name']).'</a></td>';
		echo '<td class="text">'.display_string($disk['ra']).'</td>';
		echo '<td class="text">'.display_string($disk['dec']).'</td>';
	
		foreach ($bands as $b) {
			$m = execute_multiquery($stmt,$disk['disk_id'],$b['band_id']);
			$m = $m[0];
			if (!$m) {
				echo "<td></td>";
			} else {
			//cut off based on error
			if ($m['unc'] <= 0) {
				echo "<td>".sprintf("%.2g %s",$m['mag'],$m['units'])."</td>";
			} else {
				//get order of magnitude
				$mOom = floor(log10(abs($m['mag'])));
				$errOom = floor(log10($m['unc']));
				
				$errFormat = abs($errOom)<3?"%.".(floor(abs($errOom)+1))."f":"%.1"."e";
				$mFormat = (abs($mOom)<3?(-$errOom)."f":($mOom - $errOom)."e");
				
				
				echo "<td>".sprintf("%.$mFormat %s",$m['mag'],$m['units'])."</td>";
			}
			}
		}
		echo '</tr>';
	}
echo '</tbody></table>
</div>';
	
}
?>