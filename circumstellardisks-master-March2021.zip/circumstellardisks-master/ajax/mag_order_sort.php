<?php
if (!defined('root')) {
	define('root',"../");
}
require_once(root."library.inc.php");
$disk_id = $_GET['id'];
$disk_id = (int)$disk_id;
$units = $_GET['units'];


$bands = prepare_query("SELECT *, db.units AS u FROM disk_bands AS db 
							INNER JOIN bands AS b ON db.band_id = b.band_id 
							INNER JOIN (SELECT source, MIN(wavelength) AS min FROM bands GROUP BY source) AS sort ON sort.source = b.source
							WHERE db.disk_id = ? ORDER BY sort.min ASC, b.wavelength ASC",$disk_id);
							
							
if (count($bands)) {
	?>
	<table class="display-disk">
    <tr><th>Band</th><th>Wavelength<br />(micron)</th><th>Measurement<br /></th><th>Uncertainty</th><th>Reference</th></tr>
	<?php
	foreach ($bands as $b) {
		$m = units_conversion($units,$b['u'],$b['magnitude'],$b['uncertainty'],$b['band_id']);
		echo "<tr>";
		echo "<td>".$b['band']." (".str_replace(" ","&nbsp;",$b['source']).")</td>";
		echo "<td>".$b['wavelength']."</td>";
		
		//cut off based on error
		if ($m['unc'] <= 0) {
			echo "<td>".sprintf("%.2g %s",$m['mag'],$m['units'])."</td>";
			echo "<td>Upper Bound</td>";
		} else {
			//get order of magnitude
			$mOom = floor(log10(abs($m['mag'])));
			$errOom = floor(log10($m['unc']));
			
			$errFormat = abs($errOom)<3?"%.".(floor(abs($errOom)+1))."f":"%.1"."e";
			$mFormat = (abs($mOom)<3?(-$errOom)."f":($mOom - $errOom)."e");
			
			
			echo "<td>".sprintf("%.$mFormat %s",$m['mag'],$m['units'])."</td>";
			echo "<td>".sprintf($errFormat." %s",$m['unc'],$m['units'])."</td>";
			
		}
		echo "<td>";
		if (is_numeric($b['dr_id'])) {
			$dr = prepare_query1("SELECT ref_id from disk_refs WHERE dr_id = ?",$b['dr_id']);
			echo "<a href=\"".root."reference.php?id=".$dr['ref_id']."\">View</a>";
		}
		
		echo "</td></tr>";
		
		
	}
	?>
    <tr>
    <td colspan="5">Change Units
    <select id="change_units">
    	<optgroup label="Convert to...">
        <option value="" >None</option>
        <option value="Mag" <?php echo ($units=="Mag"?"selected":""); ?>>Magnitudes</option>
        <option value="Jy" <?php echo ($units=="Jy"?"selected":""); ?>>Janskies</option>
        </optgroup></select></td></tr></table><?php
	
	
} else {
	echo "<h4>No photometry data found.</h4>";
}


?>