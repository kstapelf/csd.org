<?php
header("Cache-Control: no-store");
header("Pragma: no-cache");
header("Content-Security-Policy: default-src 'self';style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline' 'unsafe-eval';");
header("X-Content-Type-Options: nosniff");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/default.dwt.php" codeOutsideHTMLIsLocked="false" -->
<!-- InstanceBeginEditable name="initialize" -->
<?php

	define("root","");
	require root."library.inc.php";

?>
<!-- InstanceEndEditable -->

<?php 
	//new is 2 months ago
	$sixmonths = date("Y-m-d",time()-(2*30*24*60*60));
	
?>


<head>
<!--Code written by Isabelle Jansen. Written for http://www.circumstellardisks.org/. Copyright 2016.-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- InstanceBeginEditable name="Keywords" --><!-- InstanceEndEditable -->
<base target="_blank">

<link rel="stylesheet" type="text/css" href="layout/main.css" />
<link rel="stylesheet" type="text/css" href="layout/mobile.css" />
<script type="text/javascript" src="ajax/jquery-3.5.1.min.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Catalog of Circumstellar Disks | Search</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<style type="text/css">
.photometry td:not(.text) {
	text-align:right;
}

.narrow {
	width:50px;
}
.wide {
	width:75%;
}
</style>

<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
<script type="text/javascript">
$(function(){
	$("#target").on("click","[diskid]",function(e){
		e.preventDefault()
		window.open($(this).find("a").attr("href"),'_blank');
	})
	
	$("#target").on("click","#csv",function(e) {
		var table = $("#object_table")
		var cols =  $.map(table.find("[col]:visible"), function(th) {return $(th).attr("col");});
		var disks = $.map(table.find("[diskid]"), function(tr) {return $(tr).attr("diskid");});
		$(this).attr("href","get_csv.php?"+ $.param({columns:cols,disks:disks}))
		return
	})
	
	$("form").on("submit",function(e) {
		e.preventDefault()
		$("#target").empty()
		$("#target").html("Loading....")
		
		$.post("ajax/search.php",$(this).serialize(),function(data,status){
			if(status == "success") {
				
				$("#target").html(data);
				var table = $("#object_table")
				
				if ($("form").find("[name='compare_photometry']").val()=="true") {
					array = []
					rows = $("#object_table tbody tr")
					for (j = 0; j < table.find("th").length; j++) {
						empty = true
						rows.each(function(){
							empty = empty && ($(this).children().eq(j).text()=="")
						})
						if (empty) array.push(j);
					}
				} else {
					offset = table.find("th").index(table.find("th[col='numref']"))+1
					array =  Array.apply(null, Array(table.find("th").length-offset)).map(function (_, i) {return i+ offset;});
				}
				$("form").find("[name='compare_photometry']").val("false")
				table.DataTable({
					dom: 'Bfrtip',
					buttons: [{extend: 'colvis',}],
					"columnDefs": [{ "targets": array, "visible": false }],
					colReorder: true,
					searching: false,
					paging: false,
					"drawCallback": function( settings ) {
						$(".scroller1 div").css("width",$("#object_table").css("width"))
					}
				});
				var button = $("#object_table_wrapper>.dt-buttons")
				button.children().removeClass("dt-button buttons-collection buttons-colvis")
				button.detach()
				button.appendTo("#colvis")
				
				$("#target").find(".scroller1").scroll(function(){
					$(".scroller2").scrollLeft($(".scroller1").scrollLeft());
				});
				
				
				$("#target").find(".scroller2").scroll(function(){
					$(".scroller1").scrollLeft($(".scroller2").scrollLeft());
				});
			}
		})
	})
})

function photometry_compare() {
	$("form").find("[name='compare_photometry']").val("true")
	$("form").find("#include5").prop( "checked", true )
	$("form").trigger("submit")
}
</script>
<!-- InstanceEndEditable -->
</head>

<body>

<div id="navbar" class="container">
<div>
<a class="col-2" href="index.php" target="_self">Home
</a><a class="col-2" href="search.php" target="_self">Search
</a><a class="col-2" href="updates.php" target="_self">What's New
</a><a class="col-2" href="<?php echo root; ?>description.php" target="_self">Catalog Description
</a><span class="col-2 hover">Catalogs
<span><a href="index.php?catalog=resolved" target="_self">Resolved Disks</a><a href="index.php?catalog=candidate" target="_self">Unresolved Disks</a><a href="index.php?catalog=refuted" target="_self">Refuted Disks</a></span></span>
</a><a class="col-2" href="contribute.php">Contribute
</a></div></div>


<div id="banner"><div class="pagetitle" ><div><span><img src="layout/imgs/pagetitle.png" alt="Catelog of Circumstellar Disks" /></span></div></div><img src="layout/imgs/banner.png" class="banner"  /></div>

<div id="content" class="col-12">
<h1><!-- InstanceBeginEditable name="pagetitle" -->
Search the Database
<!-- InstanceEndEditable --></h1><hr />

<!-- InstanceBeginEditable name="tabbar" -->
<!-- InstanceEndEditable -->


<!-- InstanceBeginEditable name="content" -->

<form method="post" class="manual-alternate1">
<div class="container">
<div><div class="col-6 border-right">
<h4 class="header">Objects</h4>
<div class="container">
<span><label class="col-4">Name</label>		<span><input type="text" name="d_name" class="wide" /></span></span>
<span><label>Position</label>				<span><input type="text" name="d_ra" placeholder="RA (2000)" /><input type="text" name="d_dec" placeholder="DEC (2000)" /><br /><label style="text-emphasis:accent; font-style:oblique;">Search position within <input type="text" name="d_nearby" class="narrow" placeholder="0.01" value="0.01" /> degrees</label></span></span>
<span><label>Spectral Type</label>			<span><input type="text" name="d_spty" class="wide" /></span></span>
<span><label>Star-Forming Region</label>	<span><input type="text" name="d_sfr" class="wide"/></span></span>
<span><label>Category</label>				<span><input type="text" name="d_category" class="wide" /></span></span>
<span><label>Class</label>					<span><input type="text" name="d_class" class="wide" /></span></span>
<span><label>R band (mag)</label>			<label><input type="text" name="d_rmagmin" class="narrow" placeholder="Min" /> to <input type="text" name="d_rmagmax"  class="narrow" placeholder="Max" /></label></span>
<span><label>Distance (pc)</label>			<label><input type="text" name="d_distmin" class="narrow" placeholder="Min" /> to <input type="text" name="d_distmax"  class="narrow" placeholder="Max" /></label></span>
<span><label>Disk Diameter</label>			<label><input type="text" name="d_diametermin" class="narrow" placeholder="Min" /> to <input type="text" name="d_diametermax"  class="narrow" placeholder="Max" /><select name="d_diameterunits"><optgroup label="Units"><option value='"'>"</option><option value="AU">AU</option></optgroup></select></label></span>


</div>
</div><div class="col-6">

<h4 class="header">References</h4>
<div class="container">

<span><label class="col-4">Title</label><span><textarea name="r_title" class="wide" rows="5" placeholder="Separate titles or parts of titles with a comma" /></textarea>
<br />Combine titles using: <input type="radio" name="r_titlecombine" value="OR" id="rtitleor" /><label for="rtitleor">OR</label><input type="radio" name="r_titlecombine" value="AND" id="rtitleand" /><label for="rtitleand">AND</label></span></span>
<span><label>Authors</label><span><textarea name="r_authors" class="wide" rows="5" placeholder="Separate authors with a comma" /></textarea>
<br />Combine authors using: <input type="radio" name="r_authorcombine" checked="checked" value="OR" id="rauthoror" /><label for="rauthoror">OR</label><input type="radio" name="r_authorcombine" value="AND" id="rauthorand" /><label for="rauthorand">AND</label></span></span>
<span><label>Publication Date</label><span><input type="text" name="r_datemin" placeholder="Min" /> to <input type="text" name="r_datemax"  placeholder="Max" /></span></span>

<span><label style="text-emphasis:accent; font-style:oblique;">Order by</label>
<select name="order">
<option selected="selected" value="name">Name</option><option value="distance">Distance from given position</option><option value="ra">RA</option><option value="dec">DEC</option><option value="date_update_dec">Last Update- Newest First</option><option value="date_update_dec DESC">Last Update- Oldest First</option></select></span>
</div>
</div></div></div>
<hr />
<div style="padding:5px;">
<input type="checkbox" name="status[]" checked="checked" value="1" id="include1" /><label for="include1">Resolved</label>
<input type="checkbox" name="status[]" checked="checked" value="0" id="include2"/><label for="include2">Unresolved disks</label>
<input type="checkbox" name="status[]" value="-1" id="include3" /><label for="include3">Refuted or withdrawn disks</label>
<input type="checkbox" name="include[]" value="photo" id="include4" /><label for="include4">Objects with image</label>
<input type="checkbox" name="include[]" value="photometry" id="include5" /><label for="include5">Objects with photometery data</label>
<div style="float:right"><input type="submit" value="Search" /><input type="button" onclick="photometry_compare()" value="Compare Photometry Data" /><input type="hidden" value="false" name="compare_photometry" /></div><br class="clear" /></div>
</form><hr>
<div id="target"></div>

<!-- InstanceEndEditable -->
<br />
<div id="footer">Created by Caer McCabe. Redesigned by Isabelle H. Jansen. Maintained by <a href="mailto:Karl.R.Stapelfeldt at jpl.nasa.gov">Karl Stapelfeldt</a>. Last updated <?php 
if (isset($disk_id)) $edit = prepare_query1("SELECT date FROM edits WHERE disk_id = ? ORDER BY date_dec DESC LIMIT 1",$disk_id); 
else $edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1"); 

echo date("F j, Y",strtotime($edit['date'])); ?>.</div>
</div>

</body>
<!-- InstanceEnd --></html>
