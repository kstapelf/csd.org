<?php
header("Cache-Control: no-store");
header("Pragma: no-cache");
header("Content-Security-Policy: default-src 'self';style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline' 'unsafe-eval';");
header("X-Content-Type-Options: nosniff");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/default.dwt.php" codeOutsideHTMLIsLocked="false" -->
<!-- InstanceBeginEditable name="initialize" -->
<?php
	require "library.inc.php";
	
?>

<?php 
	$show_ms = false;
	$catalog = isset($_GET['catalog'])?$_GET['catalog']:'default';
	
	switch ($catalog) {
		case 'candidate':
			$query_extra = "status = 0";
			$col_order = 'order_candidate';
			$title = 'Unresolved';
			break;
		case 'refuted':
			$query_extra = "status = -1";
			$col_order = 'order_refuted';
			$title = 'Withdrawn or Refuted';
			break;
		case 'resolved':
		default:
			$query_extra = "status = 1";
			$col_order = 'order_resolved';
			$title = 'Resolved';
			$show_ms = true;
			break;
		/*default:
			$query_extra = "status = 1 OR status = 0";
			$col_order = 'order_default';
			$show_ms = true;
			$title = 'Resolved and Candidate';//*/
	} 
	
	$query_order_arr = order_disks('name',NULL,NULL);
	
	$disks = query("SELECT disks.*, COUNT() as count FROM disks INNER JOIN disk_refs ON disks.disk_id = disk_refs.disk_id WHERE ".$query_extra." GROUP BY disk_refs.disk_id ".$query_order_arr[0].$query_order_arr[1]);
	$MS = count(query("SELECT * FROM disks WHERE UPPER(category) = 'DEBRIS' AND ".$query_extra));
	
	$cols_1 = query("SELECT * FROM disk_cols WHERE ".$col_order." >= 0 ORDER BY ".$col_order);
	$cols_2 = query("SELECT * FROM disk_cols WHERE ".$col_order." < 0 AND NOT ".$col_order."= -5");
	?>

<!-- InstanceEndEditable -->

<?php 
	//new is 2 months ago
	$sixmonths = date("Y-m-d",time()-(2*30*24*60*60));
	
?>


<head>
<!--Code written by Isabelle Jansen. Written for http://www.circumstellardisks.org/. Copyright 2016.-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- InstanceBeginEditable name="Keywords" --><meta name="keywords" content="Circumstellar,Disks,Catalog,Resolved,NASA,JPL,debris,YSO,MS"><meta name="description" content="Confirmed circumstellar debris disks and references. Maintained by Karl Stapelfeldt. Last updated <?php 
if (isset($disk_id)) $edit = prepare_query1("SELECT date FROM edits WHERE disk_id = ? ORDER BY date_dec DESC LIMIT 1",$disk_id); 
else $edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1"); 
echo date("F j, Y",strtotime($edit['date'])); ?>."><!-- InstanceEndEditable -->
<base target="_blank">

<link rel="stylesheet" type="text/css" href="layout/main.css" />
<link rel="stylesheet" type="text/css" href="layout/mobile.css" />
<script type="text/javascript" src="ajax/jquery-3.5.1.min.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Catalog of Circumstellar Disks</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<style type="text/css">
</style>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

<script type="text/javascript">

function displayNum(number,type,row) {
	// Changes number value to 
	var i = parseFloat(number);
	if (isNaN(i)) {
		return number;
	}
	if ((i > 1e-2) || (i< -1e-2)) {
		return i.toString();
	} else {
		return i.toExponential(2);
	}
}

$(function(){
	$("[diskid]").click(function(e){
		e.preventDefault()
		window.open("show.php?id="+$(this).attr("diskid"),'_blank');
	})
	
	// Make table into a DataTable which is sortable
	var table = $("#object_table")
	table.DataTable({
		dom: 'Bfrtip',
		"columns": [
		<?php  
			
			foreach ($cols_1 as $c) {
				
				$render = ($c["type"]=="number") || ($c["type"]=="calculate")?", render:displayNum":"";
				
				echo '{ data: "'.$c['col'].'"'.$render.' },';
			}
			echo '{ data: "'.$c['numref'].'" },';
			foreach ($cols_2 as $c) {
				
				$render = ($c["type"]=="number") || ($c["type"]=="calculate")?", render:displayNum":"";
				
				echo '{ data: "'.$c['col'].'"'.$render.', visible:false },';
			}
		?>
	    ],
		
		colReorder: true, //allow columns to be reordered
    	searching: false, //disable search filtering
		paging: false, //show all table, not "page 1, page 2..."
		"drawCallback": function( settings ) {
        	$(".scroller1 div").css("width",$("#object_table").css("width"))
    	}
	});
	var button = $("#object_table_wrapper>.dt-buttons")
	button.children().removeClass("dt-button buttons-collection buttons-colvis")
	
	button.detach()
	button.appendTo("#colvis")
	
	
	$("#csv").on("click",function(e) {
		var table = $("#object_table")
	
		var cols =  $.map(table.find("[col]:visible"), function(th) {return $(th).attr("col");});
		var disks = $.map(table.find("[diskid]"), function(tr) {return $(tr).attr("diskid");});
		
		$(this).attr("href","get_csv.php?"+ $.param({columns:cols,disks:disks}))
		return
	})
	
	$(".scroller1").scroll(function(){
		$(".scroller2").scrollLeft($(".scroller1").scrollLeft());
	});
	$(".scroller2").scroll(function(){
		$(".scroller1").scrollLeft($(".scroller2").scrollLeft());
	});
})
</script>
<!-- InstanceEndEditable -->
</head>

<body>

<div id="navbar" class="container">
<div>
<a class="col-2" href="index.php" target="_self">Home
</a><a class="col-2" href="search.php" target="_self">Search
</a><a class="col-2" href="updates.php" target="_self">What's New
</a><a class="col-2" href="<?php echo root; ?>description.php" target="_self">Catalog Description
</a><span class="col-2 hover">Catalogs
<span><a href="index.php?catalog=resolved" target="_self">Resolved Disks</a><a href="index.php?catalog=candidate" target="_self">Unresolved Disks</a><a href="index.php?catalog=refuted" target="_self">Refuted Disks</a></span></span>
</a><a class="col-2" href="contribute.php">Contribute
</a></div></div>


<div id="banner"><div class="pagetitle" ><div><span><img src="layout/imgs/pagetitle.png" alt="Catelog of Circumstellar Disks" /></span></div></div><img src="layout/imgs/banner.png" class="banner"  /></div>

<div id="content" class="col-12">
<h1><!-- InstanceBeginEditable name="pagetitle" -->
<?php echo $title; ?> Disks
<!-- InstanceEndEditable --></h1><hr />

<!-- InstanceBeginEditable name="tabbar" -->
<ul id="tabbar"><li class="col-12 nohover" style="max-width:100%;"><span>Total number of disks: <?php echo count($disks); ?>
<?php if ($show_ms) echo " (Pre-Main Sequence disks: ".(count($disks)-$MS).", Debris Disks: ".$MS.")"; ?></span></li></ul>
<!-- InstanceEndEditable -->


<!-- InstanceBeginEditable name="content" -->
<?php 
//look up a random picture
$query_str = "SELECT disk_refs.photo, disk_refs.disk_id FROM disk_refs INNER JOIN disks ON disk_refs.disk_id = disks.disk_id
				WHERE photo NOT LIKE '' AND photo NOT NULL AND ".$query_extra." ORDER BY RANDOM() LIMIT 15";
	$pictures = query($query_str);
	if ($pictures) {
		echo "<div id=\"imgbox\"><hr class=\"clear\" style=\"margin-bottom:3px;\" />";
			foreach ($pictures as $pic) {
				echo "<a href=\"".root."show.php?id=".$pic['disk_id']."\"><img src=\"".root.'imgs/'.$pic['photo']."\" /></a>";
			}
		echo "</div><hr class=\"clear\" />";
	}


?>
<div class="container"><div><div class="col-6 border-right wide-align-right clickable" id="colvis"></div><div class="col-6"><a class="clickable" id="csv" href="#">Download as .csv</a></div></div></div>
<hr class="clear" />



<div class="scroller1"><div></div></div>
<div class="scroller2">

<table id="object_table" class="fake-link cell-border compact">
<?php 
echo '<thead><tr class="manual-alternate1">';
foreach ($cols_1 as $c) {
	echo '<th col="'.$c['col'].'"><br>'.$c['display'].'</th>';
}
echo '<th col="numref"><br># References</th>';
foreach ($cols_2 as $c) {
	echo '<th col="'.$c['col'].'"><br>'.$c['display'].'</th>';
}
echo '</tr></thead><tbody>';

foreach ($disks as $disk) {
	$first = true;
	echo '<tr class="alternate" diskid="'.$disk['disk_id'].'">';
	foreach ($cols_1 as $c) {
		if ($c['type']=="boolean") {
			$str = ($disk[$c['col']])?"Yes":"No";
		} else $str = display_string($disk[$c['col']]);
		echo '<td>';
		if ($first) {
			if ($disk['date'] > $sixmonths) echo "<img src='".root."layout/imgs/new1.gif' width='25'/>";
			echo '<a href="'.root.'show.php?id='.$disk['disk_id'].'&name='.display_string($disk[$c['col']]).'">';
		}
		echo $str;
		if ($first) echo "</a>";
		echo '</td>';
		$first = false;
	}
	echo '<td>'.$disk['count'].'</td>';
	foreach ($cols_2 as $c) {
		if ($c['type']=="boolean") {
			$str = ($disk[$c['col']])?"Yes":"No";
		} else $str = display_string($disk[$c['col']]);
		echo "<td>$str</td>";
	}
	echo '</tr>';
}

?>
</tbody></table>
</div>
<!-- InstanceEndEditable -->
<br />
<div id="footer">Created by Caer McCabe. Redesigned by Isabelle H. Jansen. Maintained by <a href="mailto:Karl.R.Stapelfeldt at jpl.nasa.gov">Karl Stapelfeldt</a>. Last updated <?php 
if (isset($disk_id)) $edit = prepare_query1("SELECT date FROM edits WHERE disk_id = ? ORDER BY date_dec DESC LIMIT 1",$disk_id); 
else $edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1"); 

echo date("F j, Y",strtotime($edit['date'])); ?>.</div>
</div>

</body>
<!-- InstanceEnd --></html>
