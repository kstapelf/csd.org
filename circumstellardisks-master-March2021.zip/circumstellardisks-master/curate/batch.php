<?php
define("root","../");
require "../library.inc.php";

?>

<?php
include root."layout/head.php";
?>

<title>Edit Disk Details</title>
<script src="../curate/ajax/curate.js"></script>
<script type="text/javascript"></script>
<style type="text/css"></style>
</head>

<body>
<?php
include root."layout/start.php";
?>


<!-- Content Below -->
<h2><center>Edit Disk Details</center></h2>


<div id="tabholder">
<div class="tabbar"><span>Disk Details</span><span>References</span><span>Magnitudes</span></div>

<div class="tab">Disk Details</div>
<div class="tab">References</div>
<div class="tab">Magnitudes</div>

</div>


<?php
include root."layout/end.php";
?>
</body>
</html>