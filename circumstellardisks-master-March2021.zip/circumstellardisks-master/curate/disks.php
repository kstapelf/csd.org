<?php
header("Cache-Control: no-store");
header("Pragma: no-cache");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/default.dwt.php" codeOutsideHTMLIsLocked="false" -->
<!-- InstanceBeginEditable name="initialize" -->
<?php

	define("root","../");
	require "../library.inc.php";
	include "library.curate.php";

	$disk_id = -1;
	if (isset($_GET['id']) && count(prepare_query("SELECT disk_id FROM disks WHERE disk_id = ?",$_GET['id']))) {
		$disk_id = $_GET['id'];
		extract(prepare_query1("SELECT name FROM disks WHERE disk_id = ?",$disk_id));
	}
	
?>
<!-- InstanceEndEditable -->

<?php 
	//new is 2 months ago
	$sixmonths = date("Y-m-d",time()-(2*30*24*60*60));
	
?>


<head>
<!--Code written by Isabelle Jansen. Written for http://www.circumstellardisks.org/. Copyright 2016.-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- InstanceBeginEditable name="Keywords" --><meta name="keywords" content=""><!-- InstanceEndEditable -->
<base target="_blank">

<link rel="stylesheet" type="text/css" href="../layout/main.css" />
<link rel="stylesheet" type="text/css" href="../layout/mobile.css" />
<script type="text/javascript" src="../ajax/jquery-3.5.1.min.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Catalog of Circumstellar Disks | Edit Disk Details<?php echo isset($name)?" | $name":"";?></title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<script src="curate.js"></script>
<script src="disks.js"></script>


<style type="text/css">
[name="select_reference"] {
	width:100px;
}

.resultbox-container {
	max-height:150px;
}
</style>
<script type="text/javascript">
$(function(){
	if (<?php echo $disk_id; ?> > 0) add_reset($('.disk form'))
})
</script>
<!-- InstanceEndEditable -->
</head>

<body>

<div id="navbar" class="container">
<div>
<a class="col-2" href="../index.php" target="_self">Home
</a><a class="col-2" href="../search.php" target="_self">Search
</a><a class="col-2" href="../updates.php" target="_self">What's New
</a><a class="col-2" href="<?php echo root; ?>description.php" target="_self">Catalog Description
</a><span class="col-2 hover">Catalogs
<span><a href="../index.php?catalog=resolved" target="_self">Resolved Disks</a><a href="../index.php?catalog=candidate" target="_self">Unresolved Disks</a><a href="../index.php?catalog=refuted" target="_self">Refuted Disks</a></span></span>
</a><a class="col-2" href="../contribute.php">Contribute
</a></div></div>


<div id="banner"><div class="pagetitle" ><div><span><img src="../layout/imgs/pagetitle.png" alt="Catelog of Circumstellar Disks" /></span></div></div><img src="../layout/imgs/banner.png" class="banner"  /></div>

<div id="content" class="col-12">
<h1><!-- InstanceBeginEditable name="pagetitle" -->
Edit Disk Details<?php echo isset($name)?" | $name":"";?>
<!-- InstanceEndEditable --></h1><hr />

<!-- InstanceBeginEditable name="tabbar" -->
<ul id="tabbar" class="ellipsis"><li class="col-2"><span>Disk Details</span></li><li class="col-2"><span>References</span></li><li class="col-2"><span>Magnitudes</span></li><?php echo ($disk_id>0)?"<li class=\"col-2\"><span>View Disk</span></li><li class=\"col-2\"><span>Edit History</span></li>":""; ?><li class="col-2"><span><input type="button" onClick="save_all()" value="Save All" /></span></li></ul>
<hr />
<!-- InstanceEndEditable -->


<!-- InstanceBeginEditable name="content" -->

<div id="tabholder">

    <div class="tab disk container">
    	<?php 
			include "ajax/load_disk.php";
		?>
    </div>

   	<div class="tab ref">
		<div class="container">
    	
        <div class="ref_filter">
            <div class="col-4 border-right"><h3>Filter Existing References</h3>
            	<?php reference_filter($disk_id) ?>
            </div>
            <div class="col-8">
        		<h3>Existing References <input type="button" value="Close List" class="reftoggle" \></h3>
                <span class="resultbox-container resultbox"></span></div>
        </div>   
             
         <form action="" id="newref" enctype="multipart/form-data" method="post">
    		<input type="hidden" name="id" value="-1" \>
            <input type="hidden" name="disk_id" value="<?php echo $disk_id; ?>" number="1" class="disk_id"\>
		<div class="col-4 border-right"><div class="container">
		<span><label>Title</label><?php show_field("title","text","New Reference",true); ?></span>
		<span><label>Link</label><?php show_field("url","text",'',true); ?></span>
		<span><label>Date</label><?php show_field("date","date",''); ?></span>
		<span><label>Authors</label><?php show_field("authors","textarea",'',true); ?></span>
		</div></div>
        
        <div class="col-4 border-right"><div class="container">
		<span><label>Description</label><?php show_field("description","textarea",''); ?></span>
		<span><label>Photo Alt</label><?php show_field("img_alt","text",''); ?></span>
		</div><input type="submit" value="Add Reference" \>
		<input type="reset" value="Reset" onClick="
        	var form = $(this).parents('form').first(); 
            form.find('[name=date]').attr('type','date');
            form.find('[name=id]').val(-1)
            form.find('img').attr('src','../layout/imgs/transparent.png');
            form.find('li.highlight').removeClass('highlight')
        	" \>
        <input type="button" value="View Existing References" class="reftoggle" \></div>
        
        <div class="col-4"><div class="container">
		<span class="display"><label>Photo</label> <?php show_field("image","image",''); ?></span></span>
		</div></div>
		</form>
		</div><hr>
        
        
	<?php
	$refs = get_all_disk_references($disk_id);
	
	foreach ($refs as $ref) {
		display_ref($ref['dr_id'],root);
	}
	?>
</div>
	
    <div class="tab mag container"><div>
        <div class="col-8 border-right">
            <form id="bands" class="container">
            <span class="header"><label>Band</label><label>Measurement</label><label>Uncertainty</label><label>Units</label><label">Reference</label></span>
            <?php 
                $bands = prepare_query("SELECT b.band, b.source, db.* FROM disk_bands AS db 
                                    INNER JOIN bands AS b ON db.band_id = b.band_id 
                                    INNER JOIN (SELECT source, MIN(wavelength) AS min FROM bands GROUP BY source) AS sort ON sort.source = b.source
                                    WHERE db.disk_id = ? ORDER BY sort.min ASC, b.wavelength ASC",$disk_id);
                        
                $unit_options = array(array("name"=>"Magnitude","value"=>"Mag"),array("name"=>"Jansky","value"=>"Jy"));
                $ref_options = array_map(function($r) { return array("name"=>$r['title'],"value"=>$r['dr_id']); },$refs);
				array_unshift($ref_options, array("name"=>"None","value"=>"-1"));
                foreach ($bands as $band) { 
                    echo "<span bandid=\"".$band['band_id']."\" class=\"alternate\"><label>".$band['band']." (".$band['source'].")</label>";
            
                    show_field("mag","text",$band['magnitude']);
                    show_field("unc","text",$band['uncertainty']);
                    show_field("units","select",$band['units'],true,$unit_options);
                    show_field("select_reference","select",$band['dr_id'],false,$ref_options);
                    echo "</span>";
                }
            
            ?>
            <span><span><input type="hidden" class="disk_id" name="disk_id" number="1" value="<?php echo $disk_id; ?>" \></span>
            	<span><input type="submit" value="Save"></span>
                <span><input type="reset"></span>
            </span>
            </form>
            <div id="new_band" style="display:none">
            <?php 
			echo "<span bandid=\"-1\" class=\"alternate new\"><label></label>";
            show_field("mag","text");
            show_field("unc","text");
            show_field("units","select","Mag",true,$unit_options);
            show_field("select_reference","select",-1,false,$ref_options);
            echo "</span>";
			?></div>
        </div>
        
        <div class="col-4 newband"><h3>Available Bands</h3>
            <ul class="nodots ellipsis container">
            <li class="header">
               <span>Band</span>
               <span>Source</span>
               <span>Wavelength</span>
            </li>
            <?php 
                $unused = prepare_query("SELECT b.* FROM bands AS b
                                            INNER JOIN (SELECT source, MIN(wavelength) AS min FROM bands GROUP BY source) AS sort
                                                ON sort.source = b.source
                                        WHERE NOT b.band_id IN (SELECT band_id FROM disk_bands WHERE disk_id = ?) 
                                        ORDER BY sort.min ASC, b.wavelength ASC",$disk_id);
                
                foreach ($unused as $band) {
                    ?>
                    <li bandid="<?php echo $band['band_id']; ?>" units="<?php echo $band['units']; ?>" class="alternate">
                        <span class="band"><?php echo $band['band']; ?></span>
                        <span class="source"><?php echo $band['source']; ?></span>
                        <span class="wavelength"><?php echo $band['wavelength']; ?></span>
                        </li>
                    <?php
                }
            ?>
            </ul>
        </div>
	</div></div>

	<?php 
        if ($disk_id>0) {
            echo "<div class=\"tab\" id=\"view_disk$disk_id\">";
            include "../show/show.php";
            echo "</div>";
			echo "<div class=\"tab\" id=\"view_history\">";
            include "ajax/disk_history.php";
            echo "</div>";
        } ?>
</div>

<!-- InstanceEndEditable -->
<br />
<div id="footer">Created by Caer McCabe. Redesigned by Isabelle H. Jansen. Maintained by <a href="mailto:Karl.R.Stapelfeldt at jpl.nasa.gov">Karl Stapelfeldt</a>. Last updated <?php 
if (isset($disk_id)) $edit = prepare_query1("SELECT date FROM edits WHERE disk_id = ? ORDER BY date_dec DESC LIMIT 1",$disk_id); 
else $edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1"); 

echo date("F j, Y",strtotime($edit['date'])); ?>.</div>
</div>

</body>
<!-- InstanceEnd --></html>
