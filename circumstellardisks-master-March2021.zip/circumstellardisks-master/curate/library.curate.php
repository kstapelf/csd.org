<?php
function show_field($name,$type,$value= NULL,$required = false,$options=NULL) {
	$required_str = ($required)?"required":"";
	echo "<span>";
	if ($type == "date") {
		//if date does not match date regular expression, then use different input
		if (preg_match("/^\d{4}-(0[1-9]|1[0-2])-[0-3]\d$/",$value) || $value=="") {
			?><input type="date" name="<?php echo $name; ?>" <?php echo $required_str; ?> value="<?php echo $value; ?>" /><?php
		} else {
			?><input type="text" name="<?php echo $name; ?>" <?php echo $required_str; ?> value="<?php echo $value; ?>" /><?php
		}
	} else if ($type == "textarea") {
		?><textarea name="<?php echo $name; ?>" <?php echo $required_str; ?> rows="5"><?php echo $value; ?></textarea><?php
	} else if ($type == "boolean") {
		?>
        <input type="hidden" name="<?php echo $name; ?>" value="<?php echo $value; ?>"><input <?php echo ($value==1)?"checked":""; ?> type="checkbox" onclick="this.previousSibling.value=1-this.previousSibling.value">
		<?php
	} else if ($type == "status") {
		if ($value == "") $value = 0;
		$options = array(array("name"=>"Resolved","value"=>1),array("name"=>"Unresolved","value"=>0),array("name"=>"Refuted","value"=>-1));
		show_field($name,"select",$value,$required,$options);
		
	} else if ($type == "image") { 
		?>
		<input type="file" name="<?php echo $name; ?>" <?php echo $required_str; ?> /><br />
      	<img class="preview" src="<?php echo ($value!= '')?"../imgs/".$value:"../layout/imgs/transparent.png"; ?>" />
	<?php
	} else if ($type == "select") { 
		?>
		<select name="<?php echo $name; ?>" <?php echo $required_str; ?> autocomplete="off">
        	<?php
            foreach ($options as $o) {
				?>
				<option value="<?php echo $o['value']; ?>" <?php echo ($o['value']==$value)?"selected=\"selected\"":""; ?>><?php echo $o['name']; ?></option>
				<?php
			}
			?>
      	</select>
	<?php
	} else if ($type == "int") { 
		?>
		<input type="text" style="width:40px;" name="<?php echo $name; ?>" <?php echo $required_str; ?> value="<?php echo $value; ?>" />
	<?php
	} else {
		?>
		<input type="text" name="<?php echo $name; ?>" <?php echo $required_str; ?> value="<?php echo $value; ?>" />
		<?php
	}
	echo "</span>";
}


function save_image($file) {
		
		if ((is_uploaded_file($file['tmp_name']))&&(getimagesize($file['tmp_name']))) {
			
			$invalid = array('"',' ',"'");
			$basename = str_replace($invalid,"",basename($file['name']));
			
			$match = preg_match("/^(.+)(\..+)$/",$basename,$matches);
			
			if ($match) {
				$base = $matches[1];
				$ending = $matches[2];
			} else {
				$base = $basename;
				$ending = '';
			}
			
			$target = $base.$ending;
			
			$j = 1;
			while (file_exists(root."imgs/".$target)) {
				$target = $base.$j.$ending;
				$j++;
			}
			$target = clean_string($target);
			
			move_uploaded_file($file['tmp_name'], root."imgs/".$target);
			
			return $target;
		} else return false;
}

function set_update($message,$disk_id = NULL,$show = 0) {
	if (!isset($message) || $message == "") return;
	
	$date = get_date("today","Y-m-d  H:i:s");
	$date_dec = datetime_to_dec($date);
	
	if (isset($disk_id)) {
		prepare_query("UPDATE disks SET date_update = ?, date_update_dec = ? WHERE disk_id = ?",$date,$date_dec,$disk_id);
	}
	
	prepare_query("INSERT INTO edits(date,date_dec,disk_id,change,display) VALUES (?,?,?,?,?)",$date,$date_dec,$disk_id,$message,$show);
}


function reference_filter($disk_id = -1) {
	?>
    <form action="" enctype="multipart/form-data" method="post">
        <input type="hidden" name="disk_id" number="1" class="disk_id" value="<?php echo $disk_id; ?>" />
        <div class="container">
        <span><label>Title:</label><?php show_field("title","text"); ?></span>
        <span><label>Link:</label><?php show_field("url","text"); ?></span>
        <span><label>Authors:</label><?php show_field("authors","textarea"); ?></span>
        <span><label>Date:</label><?php show_field("date","date"); ?></span></div>
        <div><input type="checkbox" name="daterange" checked /> Search dates within <input name="datespan" value="6" style="width:50px;"> months</div>
	<input type="submit" value="Search"></form>
<?php
}

function disk_filter($ref_id = -1) {
	?>
    <form action="" enctype="multipart/form-data" method="post">
    	<input type="hidden" name="ref_id" number="1" class="ref_id" value="<?php echo $ref_id; ?>" />
        <div class="container">
    	<span><label>Name:</label><?php show_field("name","text"); ?></span>
    	<span><label>RA:</label><?php show_field("ra","text"); ?></span>
   		<span><label>DEC:</label><?php show_field("dec","text"); ?></span></div>
    	<div><input type="checkbox" name="nearby" checked /> Search within <input name="dist" value="0.05" style="width:30px;"> degrees</div>
        <div>Order by: <select name="order"><option selected="selected" value="name">Name</option><option value="distance">Distance</option><option value="ra">RA</option><option value="dec">DEC</option><option value="date_update_dec">Last Update- Newest First</option><option value="date_update_dec DESC">Last Update- Oldest First</option></select></div>
    <span><input type="submit" value="Search"></span></form>
<?php
}

?>