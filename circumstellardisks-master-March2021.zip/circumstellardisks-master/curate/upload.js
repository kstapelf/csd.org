// JavaScript Document
$(function(){
	$("#upload [name='upload']").change(function(){
		$("#upload_target").empty()
		$("#upload_target").html("Processing...");
		$.ajax({
			url: "ajax/csv_upload.php?function=stage_1",
			type: "POST",
			data: new FormData(this.parentNode), // var form is not Jquery!
			contentType: false,
			cache: false,
			processData:false,
			success: function(data) {
				$("#upload_target").html(data)
			}
		})
	})
	
	$("#upload_target").on('submit',function(e){
		e.preventDefault()
		$.ajax({
			url: "ajax/csv_upload.php?function=stage_2",
			type: "POST",
			data: new FormData(this), // var form is not Jquery!
			contentType: false,
			cache: false,
			processData:false,
			success: function(data) {
				$("#upload").trigger('reset')
				$("#upload_target").empty()
				$("#upload_target").html(data)
			}
		})
	})
	
	
	band_row = null
	$("#band_chooser li:not(.header,.addnew)").click(function(e){
		if (band_row != null) {
			//change wavelength, band, and source
			var kids = band_row.children()
			kids.eq(0).html("Photometry band selected");
			kids.eq(1).find("i").html(" ("+$(this).find("[wavelength]").html()+")")
			kids.eq(2).replaceWith("<label><i>"+$(this).find("[band]").html()+"</i></label>")
			kids.eq(3).replaceWith("<label><i>"+$(this).find("[source]").html()+"</i></label>")
			band_row.find("[value='Add']").val("Confirm")
			
			//add band_id
			band_row.find('[name="band_id"]').remove()
			band_row.append('<input type="hidden" name="band_id" value="'+$(this).attr("bandid")+'" />')
		}
		band_row = null	
		$('#band_chooser').css('display','none')
	})
	
	$("#band_chooser li.addnew").click(function(e){
		e.stopPropagation()
		if (band_row != null) {
			//change wavelength, band, and source
			var kids = band_row.children()
			kids.eq(0).html("Add new photometry band");
			kids.eq(1).find("i").html("")
			kids.eq(2).replaceWith("<span><input type='text' name='band' value='Name' required></span>")
			kids.eq(3).replaceWith("<span><input type='text' name='source' value='Source' required></span>")
			band_row.find("[value='Confirm']").val("Add")
			
			band_row.find('[name="band_id"]').remove()
		}
		band_row = null	
		$('#band_chooser').css('display','none')
	})
	
	
	ref_row = null
	$("#ref_chooser .resultbox").on('click',"li:not(.header,.addnew)",function(e){
		if (ref_row != null) {
			//change wavelength, ref, and source
			var kids = ref_row.children()
			kids.eq(0).html("Reference selected");
			kids.eq(1).replaceWith("<label><a href=../curate/\""+$(this).find('a').attr('href')+"\">"+$(this).find('.title').html()+"</a></label>")
			kids.eq(2).replaceWith("<label>"+$(this).find('.authors').attr("val")+"</label>")
			kids.eq(3).replaceWith("<label>"+$(this).attr('date')+"</label>")
			ref_row.find("[value='Add']").val("Confirm")
			
			//add ref_id
			ref_row.find('[name="ref_id"]').remove()
			ref_row.append('<input type="hidden" name="ref_id" value="'+$(this).attr("refid")+'" />')
		}
		ref_row = null	
		$('#ref_chooser').css('display','none')
	})
	
	$("#ref_chooser .resultbox").on('click',"li.addnew",function(e){
		e.stopPropagation()
		if (ref_row != null) {
			//change wavelength, ref, and source
			var kids = ref_row.children()
			kids.eq(0).html("<a href='../curate/"+ref_row.attr("ref")+"'>Add new reference</a>");
			kids.eq(1).replaceWith("<span><input type='text' name='title' required value='Title'></span>")
			kids.eq(2).replaceWith("<span><textarea name='authors' required rows='5' cols='50'>Authors</textarea></span>")
			kids.eq(3).replaceWith("<span><input type='date' name='date' required /></span>")
			ref_row.find("[value='Confirm']").val("Add")
			
			ref_row.find('[name="ref_id"]').remove()
		}
		ref_row = null	
		$('#ref_chooser').css('display','none')
	})
	
	
	disk_row = null
	$("#disk_chooser .resultbox").on('click',"li:not(.header,.addnew)",function(e){
		if (disk_row != null) {
			//add row directly underneath
			var arrdisk = disk_row.attr("arrdisk")
			
			var str = '<div class="'+disk_row.attr('class')+'" arrdisk="'+arrdisk+'"><label></label><label>'+$(this).find('[name="name"]').html()+'</label><label>'+$(this).find('[name="ra"]').html()+'</label><label>'+$(this).find('[name="dec"]').html()+'</label><span><input value="Confirm" type="button" onclick="confirm_disk(this,'+arrdisk+','+$(this).attr('diskid')+')"></span><span></span><span></span></div>';
			
			disk_row.after(str)
			}
		disk_row = null	
		$('#disk_chooser').css('display','none')
	})
	
	$("#disk_chooser .resultbox").on('click',"li.addnew",function(e){
		e.stopPropagation()
		disk_row = null	
		$('#disk_chooser').css('display','none')
	})
})

function choose_band(button) {
	$('#band_chooser').css('display','block')
	band_row = $(button).parents("[band]").first()
}

function confirm_band(button) {
	//get parent row
	var b_row = $(button).parents("[band]").first()
	
	//check info
	if (check_required(b_row)) $.post("ajax/csv_upload.php?function=confirm_band",$(b_row).find("input").serializeArray(),function(data,status){
		if(status == "success") {
			//make buttons unavailable
			console.log(data)
			b_row.children().first().html(data);
			b_row.find("[type=button]").remove();
			activate_process()
		}
	})
}

function cancel_band(button) {
	//get parent row
	var b_row = $(button).parents("[band]").first()
	
	b_row.children().first().html("Skipping photometry band")
	b_row.addClass("inactive").find("[type=button]").remove();
	activate_process()
}


function choose_ref(button) {
	$('#ref_chooser').css('display','block')
	ref_row = $(button).parents("[ref]").first()
}

function confirm_ref(button) {
	//get parent row
	var r_row = $(button).parents("[ref]").first()
	
	//check info
	if (check_required(r_row)) $.post("ajax/csv_upload.php?function=confirm_ref",$(r_row).find("input,textarea").serializeArray(),function(data,status){
		if(status == "success") {
			//make buttons unavailable
			r_row.children().first().html(data);
			r_row.find("[type=button]").remove();
			activate_process()
		}
	})
}

function cancel_ref(button) {
	//get parent row
	var r_row = $(button).parents("[ref]").first()
	
	r_row.children().first().html("Skipping reference")
	r_row.addClass("inactive").find("[type=button]").remove();
	activate_process()
}


function choose_disk(button) {
	disk_row = $(button).parents("[disk]").first()
	
	//fill in search details
	$("#disk_chooser form [name='name']").val(disk_row.find("[name='name']").html())
	$("#disk_chooser form [name='ra']").val(disk_row.find("[name='ra']").html())
	$("#disk_chooser form [name='dec']").val(disk_row.find("[name='dec']").html())
	$("#disk_chooser form").trigger("submit")
	$("#disk_chooser").css('display','block')
}

function confirm_disk(button,arrdisk,id) {
	$.post("ajax/csv_upload.php?function=confirm_disk",{arrdisk:arrdisk, disk_id:id},function(data,status){
		if(status == "success") {
			//make buttons unavailable
			console.log(data)
			$("[arrdisk='"+arrdisk+"']:not([disk])").remove();
			$("[arrdisk='"+arrdisk+"']").find("[type=button]").remove();
			$("[arrdisk='"+arrdisk+"']").children().first().html(data);
			activate_process();
		}
	})
}

function cancel_disk(button) {
	var arrdisk = $(button).parents("[disk]").first().attr("arrdisk")
	$(button).parents("[disk]").children().first().html("Skipping disk")
	$("[arrdisk='"+arrdisk+"']").addClass("inactive").find("[type=button]").remove();
	activate_process()
}


function cancel_upload() {
	var check = confirm("Are you sure you want to cancel the upload?\nAny new entries already added to the database will remain.");
	
	if (check) {
		$.get("ajax/csv_upload.php?function=cancel_upload",function(data){
			$("#upload_target").empty()
			$("#upload_target").html(data)
		})
	}
}


function confirm_all_bands() {
	$("#upload_target [band]").find("[value='Confirm']").trigger("click")
}

function confirm_all_refs() {
	$("#upload_target [ref]").find("[value='Confirm']").trigger("click")
}

function confirm_all_disks() {
	$("#upload_target [disk]").each(function(){
		$(this).next().find("[value='Confirm']").trigger("click")
	})
}

function skip_all() {
	$("#upload_target").find("[value='Skip']").trigger("click")
}

function activate_process() {
	if ($("#upload_target [type='button']:not([extra])").length == 0) {
		$("#process").removeClass("inactive")
		$("#process").attr("active","true")
	}
}

function process_upload() {
	if ($("#process").attr("active")=="true") $.get("ajax/csv_upload.php?function=stage_2",function(data, status) {
			$("#upload_target").html(data)
		}
	)
}