<?php 
include "ajax/csv_upload_classes.php";
session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/default.dwt.php" codeOutsideHTMLIsLocked="false" -->
<!-- InstanceBeginEditable name="initialize" -->
<?php
	define("root","../");
	require root."library.inc.php";
	include "library.curate.php";

?>
<!-- InstanceEndEditable -->

<?php 
	//new is 2 months ago
	$sixmonths = date("Y-m-d",time()-(2*30*24*60*60));
	
?>


<head>
<!--Code written by Isabelle Jansen. Written for http://www.circumstellardisks.org/. Copyright 2016.-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- InstanceBeginEditable name="Keywords" --><!-- InstanceEndEditable -->
<base target="_blank">

<link rel="stylesheet" type="text/css" href="../layout/main.css" />
<link rel="stylesheet" type="text/css" href="../layout/mobile.css" />
<script type="text/javascript" src="../ajax/jquery-3.5.1.min.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Catalog of Circumstellar Disks | Curate Home</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<script src="curate.js"></script>
<script src="upload.js"></script>

<style type="text/css">
.history span {
	display:block;
}

.history .name {
	padding-top:0.5em;
	font-weight:bold;
}

.history .date {
	font-size:smaller;
	font-style:italic;
	text-emphasis:accent;
}

.history .change {
	padding-left:20px;
}

.history .change::before {
	content:"-";
}


.resultbox {
	height:400px;
}

.resultbox-container {
	max-height:400px;
}

.chooser {
	display:none;
	position:fixed;
	width:50%;
	top:10%;
	left:25%;
	border:solid 3px #666;
	background-color:white;
	z-index:3;
}

#process {
	font-size:large;
	padding:5px;
	color:black;
	border:medium solid;
	border-color:black;
	border-radius: 0.5em;
	-moz-border-radius: 0.5em;
	-webkit-border-radius: 0.5em;
	background-color:#0C0;
}
</style>
<script type="text/javascript">
$(function(){
	$("#disk_filter .resultbox").on('click',"li:not(.header,.bold)",function(){window.location.assign("disks.php?id="+$(this).attr("diskid"))})
	
	$("#disk_filter .resultbox").on('click',"li.addnew",function(){window.location.assign("disks.php?")})
	
	$("#disk_filter form, #disk_chooser form").on('submit',function(e){
		e.preventDefault()
		var parent = $(this).parents('.top').first()
		var form = this
		$.post("ajax/filter_disks.php",$(this).serialize(),function(data,status){
			if(status == "success") {
				var target = parent.find(".resultbox")
				target.html(data);
			}
		})
	})
	
	$("#disk_filter form").trigger("submit")
	
	$("#ref_filter .resultbox").on('click',"li:not(.header,.bold)",function(){window.location.assign("refs.php?id="+$(this).attr("refid"))})
	
	$("#ref_filter .resultbox").on('click',"li.addnew",function(){window.location.assign("refs.php?")})
	
	$("#ref_filter form,#ref_chooser form").on('submit',function(e){
		var parent = $(this).parents('.top').first()
		e.preventDefault()
		var form = this
		$.post("ajax/filter_refs.php",$(this).serialize(),function(data,status){
			if(status == "success") {
				var target = parent.find(".resultbox")
				target.html(data);
			}
		})
	})
	
	$("#ref_filter form,#ref_chooser form").trigger("submit")

	add_reset($("#editbands form"))
	$("#editbands form").on('submit',function(e) {
		e.preventDefault()
		$(this).find(".highlight,.new").each(function(){
			var row = $(this)
			var all_filled = check_required(row)
			if (all_filled)	$.post("ajax/tables.php?function=save_band",{
								band_id:row.attr("bandid"),
								band:row.find("[name='band']").val(),
								source:row.find("[name='source']").val(),
								wavelength:row.find("[name='wavelength']").val(),
								units:row.find("[name='units']").val(),
								fdefault:row.find("[name='fdefault']").val() },
						function(data,status){
							if(status == "success") {
								row.removeClass("new")
								row.attr("bandid",data)
								add_reset(row)
							}
						})
				})
	})
	
	add_reset($("#editdisks form"))
	$("#editdisks form").on('submit',function(e) {
		e.preventDefault()
		$(this).find(".highlight").each(function(){
			var row = $(this)
			var all_filled = check_required(row)
			if (all_filled)	$.post("ajax/tables.php?function=save_col",$(row).find("input,select").serializeArray(),
						function(data,status){
							if(status == "success") {
								add_reset(row)
							}
						})
				})
	})
	
	$("#view_history").on('submit',function(e){
		e.preventDefault()
		form = $(this)
		$.post("ajax/edit_history.php?function=view",form.serialize(),function(data,status){
			if(status == "success") {
				form.next().html(data);
			}
		})})
	$("#view_history").trigger("submit")
	
	$("#whatsnew").on('submit',function(e){
		e.preventDefault()
		form = $(this)
		$.post("ajax/edit_history.php?function=add",form.serialize(),function(data,status){
			if(status == "success") {
				form.siblings(".target").first().html(data);
				form.trigger("reset")
				if ($("#view_history select").val() == "all_new") {
					$("#view_history").trigger("submit")
				}
			}
		})})
})

function backup(button) {
	$.get("ajax/backup.php",{},function(data,status){
		if(status == "success") {
			var target = $(button).siblings(".resultbox").find("ul")
			$(data).insertAfter(target.children().first());
		}
	})
}

function add_new_band(button) {
	var number = $(button).siblings("[name='number']").val()
	for (var i = 0; i < number; i++) {
		$("#new_band>*").clone().insertBefore($(button).prop("parentRow"))
	}
}

var save_callback = function() {}
</script>
<!-- InstanceEndEditable -->
</head>

<body>

<div id="navbar" class="container">
<div>
<a class="col-2" href="../index.php" target="_self">Home
</a><a class="col-2" href="../search.php" target="_self">Search
</a><a class="col-2" href="../updates.php" target="_self">What's New
</a><a class="col-2" href="<?php echo root; ?>description.php" target="_self">Catalog Description
</a><span class="col-2 hover">Catalogs
<span><a href="../index.php?catalog=resolved" target="_self">Resolved Disks</a><a href="../index.php?catalog=candidate" target="_self">Unresolved Disks</a><a href="../index.php?catalog=refuted" target="_self">Refuted Disks</a></span></span>
</a><a class="col-2" href="../contribute.php">Contribute
</a></div></div>


<div id="banner"><div class="pagetitle" ><div><span><img src="../layout/imgs/pagetitle.png" alt="Catelog of Circumstellar Disks" /></span></div></div><img src="../layout/imgs/banner.png" class="banner"  /></div>

<div id="content" class="col-12">
<h1><!-- InstanceBeginEditable name="pagetitle" -->
Curate Home
<!-- InstanceEndEditable --></h1><hr />

<!-- InstanceBeginEditable name="tabbar" -->
<ul id="tabbar" class="ellipsis"><li class="col-2">
<span>Edit Disks</span></li><li class="col-2">
<span>Edit References</span></li><li class="col-2">
<span>Upload</span></li><li class="col-2">
<span>Edit Display</span></li><li class="col-2">
<span>Edit Bands</span></li><li class="col-2">
<span>History</span></li></ul>
<hr class="clear" />
<!-- InstanceEndEditable -->


<!-- InstanceBeginEditable name="content" -->


<div id="tabholder">

<div class="tab container top" id="disk_filter"><div>
	<div class="col-4 border-right">
    <h3>Filter Disks</h3>
    <?php 
		disk_filter();
	?>
    </div>
    <div class="col-8">
    <h3>Existing Disks</h3>
    <span class="resultbox-container resultbox"></span></div>
</div></div>

<div class="tab container top" id="ref_filter"><div>
	<div class="col-4 border-right">
    <h3>Filter References</h3>
    <?php 
		reference_filter();
	?>
    </div>
    <div class="col-8">
    <h3>Existing References</h3>
    <span class="resultbox-container resultbox"></span></div>
</div></div>


<div class="tab">
<h2>Photometry Upload</h2>

<div id="band_chooser" class="resultbox-container chooser">
<h3>Select Band</h3>
<ul  class="container fake-link  nodots">
<li class="bold addnew"><span>New Band</span><span><input type="button" value="Close" onclick="$('#band_chooser').css('display','none')" /></span></li>
<li class="header"><span>Band</span><span>Source</span><span>Wavelength</span></li>
<?php
	$db_bands = query("SELECT b.* FROM bands AS b ORDER BY b.wavelength ASC");
				
	foreach ($db_bands as $band) { 
		echo "<li bandid=\"".$band['band_id']."\" class=\"alternate\">";
		echo "<span band>".$band['band']."</span>";
		echo "<span source>".$band['source']."</span>";
		echo "<span wavelength>".$band['wavelength']."</span>";
		echo "</li>";
	}
?>
</ul>
</div>

<div class="chooser top"  id="ref_chooser">
    <h3>Select Reference</h3>
    <span><input type="button" value="Close" onclick="$('#ref_chooser').css('display','none')" /></span>
    <?php 
		reference_filter();
	?>
    <span class="resultbox-container resultbox"></span>
</div>

<div class="chooser top"  id="disk_chooser">
    <h3>Select Disk</h3>
    <span><input type="button" value="Close" onclick="$('#disk_chooser').css('display','none')" /></span>
    <?php 
		disk_filter();
	?>
    <span class="resultbox-container resultbox"></span>
</div>


<form action="#" id="upload" enctype="multipart/form-data" method="post">
<label>Select File for Upload:</label><input type="file" name="upload" /><input type="button" value="Cancel Upload" onclick="cancel_upload()" /><input type="button" onclick="$('#upload_instructions').toggle()" value="Show/Hide Instructions" />
</form>

<div id="upload_instructions" style="display:none;">
<h3>Instructions</h3>
<p>Choose a file to upload photometry data. The file must be in .csv format, and have headers that contain the following words (case insensitive):</p>
<ul>
<li>Name</li>
<li>RA</li>
<li>DEC</li>
<li>Wavelength</li>
<li>Measurement</li>
<li>Uncertainty</li>
<li>Flag - corresponding to the column indicating units</li>
<li>Reference - corresponding to a URL</li>
</ul>
<p>Currently, the allowed units are magnitude and Jansky. Magnitude is the assumed unit unless the cell contains "Flux Density","Jy","Jansky", or "Janskies". The measurement will be saved with the given units.</p><br />
<p>Once the file is uploaded, you'll be asked to confirm list of the unique wavelengths, references, and disks found in the file. If the given option is incorrect, clicking "Choose" will let you manually select the correct entry. If the entry does not already exist, "Add" will add the information the the database <i>even if the rest of the upload gets canceled</i>. Disks are listed in order of distance to the given coordinates. The "Confirm All Disks" button will select the top-listed option. You must Confirm, Add, or Skip all entries to be able to process the upload (save the actual measurements to the database).</p><br />
<p>The information about the upload is temporarily stored on the server while it's being processed. You may refresh the page to refresh the list of available bands and "unskip" all skipped entries- you will not need to re-confirm entries. Do not attempt to process multiple uploads at once from the same browser (via different windows). Completeing or canceling the upload, timing out (3 hours), or quitting will interrupt the upload. No measurements will be added, but any entries already added to the database will remain.</p>
</div>

<form action="#" id="upload_target" enctype="multipart/form-data" method="post">
<?php

if (isset($_SESSION['upload_data_disks'])) include "ajax/csv_upload_display.php";

?>
</form>
</div>



<div class="tab" id="editdisks">
<h3>Edit Display</h3>

<form action="#" class="container" enctype="multipart/form-data" method="post">
<span class="header"><label>Column Key</label><label>Display Text</label><label>Type</label><label>Required</label></span>
	<?php 
        $results = query("SELECT * FROM disk_cols");
		
		$type_options = array(
			array("name"=>"Text","value"=>"text"),
			array("name"=>"Number","value"=>"number"),
			array("name"=>"Boolean","value"=>"boolean"),
			array("name"=>"Date","value"=>"date"));		
		
        foreach ($results as $row) {
            echo "<span class=\"alternate\">";
            echo "<input type=\"hidden\" name=\"col\" value=\"".$row['col']."\" />";
			echo "<label>".$row['col']."</label>";
            show_field("display","text",$row['display'],true);
			
			if ($row['type']=='calculate') {
				echo "<label>Calculated Value</label>";
			} else if ($row['type'] == 'textarea') {
				echo "<label>Large Text Box</label>";
			} else if ($row['type'] == 'status') {
				echo "<label>Disk Status</label>";
			} else {
				show_field("type","select",$row['type'],true,$type_options);
			}
			
            show_field("required","boolean",$row['required']);
			
            echo "</span>";
        }
    ?>
	<input type="submit" value="Save" />
</form>
</div>

<div class="tab" id="editbands">
<h3>Edit Bands</h3>
<form action="" class="container" enctype="multipart/form-data" method="post">
<span class="header"><label>Band</label><label>Source</label><label>Wavelength</label><label>Zero-point Flux Denisty</label><label>Default Units</label></span>
    <?php 
		$db_bands = query("SELECT b.* FROM bands AS b INNER JOIN (SELECT source, MIN(wavelength) AS min FROM bands GROUP BY source) AS sort
						ON sort.source = b.source
						ORDER BY sort.min ASC, b.wavelength ASC");
		
		$unit_options = array(array("name"=>"Magnitude","value"=>"Mag"),array("name"=>"Jansky","value"=>"Jy"));		
		
		foreach ($db_bands as $band) { 
			echo "<span bandid=\"".$band['band_id']."\" class=\"alternate\">";
			
			show_field("band","text",$band['band'],true);
			show_field("source","text",$band['source']);
			show_field("wavelength","text",$band['wavelength']);
			show_field("fdefault","text",$band['fdefault'],true);
			show_field("units","select",$band['units'],true,$unit_options);
			
			echo "</span>";
		}
		
	?>
	<span class="alternate"><input type="submit" value="Save" class="col-8" /><span></span><span></span><span></span><span>Add <input name="number" type="number" style="width:40px;" value="1" /> new rows <input type="button" value="Add" onclick="add_new_band(this)"/></span></span>
</form>

<div id="new_band" style="display:none">
<?php 
//hidden "new band" entry
echo "<span bandid=\"-1\" class=\"alternate new\">";
		
	show_field("band","text",NULL,true);
	show_field("source","text");
	show_field("wavelength","text");
	show_field("fdefault","text",1.0,true);
	show_field("units","select",'Mag',true,$unit_options);
			
echo "</span>";

?>
</div>

</div>

<div class="tab container">
<div>
<div class="col-6 border-right">
<h3>What's New</h3>
<form class="container" id="whatsnew">
<span><label class="col-3">Title (optional):</label><span><input type="text" name="title" style="width:90%" /></span></span>
<span><label>Announcement:</label><span><textarea name="content" style="width:90%;max-width:90%;height:10em;"></textarea></span></span>
<span><span></span><span style="text-align:right;"><input type="submit" value="Add Announcement" /></span></span>
</form>
<hr />
<h3>Latest Entry</h3>
<div class="target section">
<?php
$filepath = root."../disk_symlinks/whatsnew.xml";
$xml = load_xml($filepath);

$entries = $xml->entry;
display_xml($entries[count($entries)-1]);
?>
</div>
</div>

<div class="col-3 border-right">
<h3>Edit History</h3>
<form id="view_history">
<label>View from...</label><select name="timescale"><option value="all_new">Last update</option><option value="3days">3 days</option><option value="week">Last week</option><option value="month">Last month</option><option value="6month">Last 6 months</option><option value="year">Last year</option><option value="all">All</option></select><br />
<input type="submit" value="View Edit History" />
</form>
<div class="history target resultbox-container resultbox">
</div>

</div>
<div class="col-3">
<h3>Backups</h3>
<input type="button" onClick="backup(this)" value="Backup Now" />
<div class="resultbox-container resultbox">
<ul class="nodots container">
<li class="header">Previous Backups</li>
<?php 

//show list of recent backups
if ($handle = opendir(root.'../disk_symlinks/resd_disks_backup')) {
    
	$entries = array();
    /* This is the correct way to loop over the directory. */
    while (false !== ($entry = readdir($handle))) {
        if ($entry != "." && $entry != "..") {
            $entries[] = $entry;
        }
    }
	
    closedir($handle);
	
	sort($entries);
	while ($entry = array_pop($entries)) {
		$dateime = strtotime(basename($entry,".db"));
		if ($dateime) {
			echo "<li>".date("F j Y, g:i:s a",$dateime)."</li>";
		}
	}
}
?>
	</ul>
</div>

</div>
</div>


</div>

</div>


<!-- InstanceEndEditable -->
<br />
<div id="footer">Created by Caer McCabe. Redesigned by Isabelle H. Jansen. Maintained by <a href="mailto:Karl.R.Stapelfeldt at jpl.nasa.gov">Karl Stapelfeldt</a>. Last updated <?php 
if (isset($disk_id)) $edit = prepare_query1("SELECT date FROM edits WHERE disk_id = ? ORDER BY date_dec DESC LIMIT 1",$disk_id); 
else $edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1"); 

echo date("F j, Y",strtotime($edit['date'])); ?>.</div>
</div>

</body>
<!-- InstanceEnd --></html>
