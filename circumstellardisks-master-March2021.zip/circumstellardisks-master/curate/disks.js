// JavaScript Document
$(function(){
	add_reset($("#bands"))
	
	$("#bands").on('submit',function(e) {
		e.preventDefault();
		var form = this
		var disk_id = $(form).find(".disk_id").val()
		if (disk_id > 0) {
			var rows = $(form).find("span[bandid].highlight,span[bandid].new");
			var count = 0
			var length = rows.length
			rows.each(function(){
				var bandid = $(this).attr("bandid")
				var units = $(this).find("[name='units']").val()
				var mag = $(this).find("[name='mag']").val();
				var unc = $(this).find("[name='unc']").val();
				var ref = $(this).find("[name='select_reference']").val();
				$.post("ajax/bands.php?function=save",{disk_id:disk_id,band_id:bandid,units:units,magnitude:mag,uncertainty:unc,select_reference:ref},function(data,status){
					if(status == "success") {
						count++;
						if (count == length) {
							$.post("ajax/bands.php?function=update_date",{disk_id:disk_id,count:count})
							rows.removeClass("highlight")
							add_reset($(form))
						}
					}
				})
			})
		} else {
			alert("Before saving band magnitudes, please save the disk details!");
		}
	})
	
	$(".newband li[bandid]").click(function(){
		//grab same source
		var source = $(this).find(".source").text()
		
		var same_source = $(".newband li[bandid]").has(".source:contains('"+source+"')")
		
		$(same_source.get().reverse()).each(function(){
			span = $("#new_band>*").clone().insertAfter($("#bands").children().first())
			span.attr('bandid',$(this).attr('bandid'))
			span.find("label").html($(this).find('.band').text()+' ('+$(this).find('.source').text()+')')
			span.find("[name='units']").find("[value='"+$(this).attr("units")+"']").prop("selected",true)
			$(this).remove()
		})
		
	})
	
	add_reset($("#newref"))
	
	$(".reftoggle").click(function(){
		$(this).parents(".ref").children().first().children().toggle()
	})
	
	$(".ref_filter").hide()
	
	$("#newref").on('submit',function(e) {
		e.preventDefault();
		var form = this
		
		if ($(form).find(".disk_id").val() > 0) {
			var all_filled = check_required($(form));
			console.log(all_filled)
			if (all_filled) {
				$.ajax({
					url: "ajax/disk_refs.php?function=newref",
					type: "POST",
					data: new FormData(this),
					contentType: false,
					cache: false,
					processData:false,
					success: function(data) {
						refresh_disk($(form).find("[name='disk_id']").val())
						
						var ref_id = $(form).find("[name='id']").val()
						if (ref_id > 0) {
							$(form).find(".sharednew li[refid='"+ref_id+"']").remove()
						}
						$(data).insertAfter($(form).parents(".tab").children("hr")).dblclick(function(){load_ref(this)}).find("a").click(function(e){e.preventDefault()});
						$(form).find("[name='date']").attr("type","date")
						$(form).find("img").each(function(){ $(this).attr("src",'../layout/imgs/transparent.png') })
						form.reset();
						add_reset($(form))
					}
				})}
		} else {
			alert("Before saving references, please save the disk details!");
		}
	})
	
	$(".ref_filter form").on('submit',function(e){
		e.preventDefault()
		var form = this
		$.post("ajax/filter_refs.php",$(this).serialize(),function(data,status){
			if(status == "success") {
				var target = $(form).parents(".ref_filter").first().find(".resultbox")
				target.empty();
				
				target.html(data);
				
				$(target).find("li").not(".header").click(function(){
					var form = $("#newref")
					
					form.find("[name='title']").val($(this).find(".title").text());
					form.find("[name='authors']").val($(this).find(".authors").attr("val"))
					form.find("[name='url']").val($(this).find("a").prop("href"))
					form.find("[name='id']").val($(this).attr("refid"))
					
					$(this).addClass("highlight").siblings().removeClass("highlight")
					
					var date = $(this).attr("date")
					if (date_regex.test(date)) {
						form.find("[name='date']").attr("type","date").val(date)
					} else {
						form.find("[name='date']").attr("type","text").val(date)
					}
					add_reset($("#newref"))
					$(form).parents(".ref").children().first().children().toggle()
				})
			}
		})
	})
	
	$(".ref_filter form").trigger("submit")
})

//gets passed the div
function load_ref(location) {
	var ref = $(location).attr("ref")
	
	$.post("ajax/disk_refs.php?function=load",{id:ref},function(data,status){
		if(status == "success") {
			$(data).appendTo(location).click(function(e){e.stopPropagation()})
			add_reset(location);
			$(location).find("form").on('submit',function(e) {
				e.preventDefault();
				var form = this;
				$.ajax({
					url: "ajax/disk_refs.php?function=save",
					type: "POST",
					data: new FormData(this),
					contentType: false,
					cache: false,
					processData:false,
					success: function(data) {
						var div = $(form).parents("[ref]").first()
						div.removeAttr("loaded")
						div.empty().html(data)
						div.children("a").click(function(e){e.preventDefault()})
					}
				})
			})
		}
	})
}

function remove_ref(form) {
	if (confirm("Are you sure you want to delete this reference?\nOnly this disk will be affected.")) {
		$.post("ajax/disk_refs.php?function=remove",$(form).serialize(),function(data,status){
			if(status == "success") {
				refresh_disk($(".disk_id").val())
				$(form).parents("[ref]").first().remove()
			}
		})
	}
}

function cancel_ref(form) {
	$.post("ajax/disk_refs.php?function=cancel",$(form).serialize(),function(data,status){
		if(status == "success") {
			var div = $(form).parents("[ref]").first()
			div.empty().html(data);
			div.removeAttr("loaded")
			div.find("a").click(function(e){e.preventDefault()})
		}
	})
}


function save_all_callback(e,result) {
	if (result[0]=="added") {
		new_tab = add_tab("View Disk",3)
		new_tab.attr("id","view_disk"+result[1])
		window.history.replaceState("object or string", "Title", window.location.pathname+"?id="+result[1]);
		
		new_tab = add_tab("Edit History",4)
		new_tab.attr("id","view_history")
	}
	
	if (result[0]=="duplicate") {
		new_tab = add_tab("View Duplicate Disk",-1)
		new_tab.attr("id","view_disk"+result[1])
		refresh_disk_callback(result[1],function(args){
			var new_tab = args[0]
			var id = args[1]
			new_tab.prepend("<a href=../curate/\"disks.php?id="+id+"\" class=\"link-notice\">Edit this disk instead</a>");},
			[new_tab,result[1]])
		change_tab($("#tabbar span").last())
	} else {
		$("#bands").trigger("submit")
		$("[ref] form").trigger("submit")
		$("#newref").trigger("submit")
		refresh_disk(result[1]);
	}
}

function save_all() {
	$(".disk_details").trigger('submit',{callback:save_all_callback,args:null})
}

var save_callback = function(e,result) {
	if (result[0]=="added") {
		new_tab = add_tab("View Disk",3)
		new_tab.attr("id","view_disk"+result[1])
		window.history.replaceState("object or string", "Title", window.location.pathname+"?id="+result[1]);
		
		new_tab = add_tab("Edit History",4)
		new_tab.attr("id","view_history")
	}
		
	if (result[0]=="duplicate") {
		new_tab = add_tab("View Duplicate Disk",-1)
		new_tab.attr("id","view_disk"+result[1])
		refresh_disk_callback(result[1],function(args){
			var new_tab = args[0]
			var id = args[1]
			new_tab.prepend("<a href=../curate/\"disks.php?id="+id+"\" class=\"link-notice\">Edit this disk instead</a>");},
			[new_tab,result[1]])
		change_tab($("#tabbar span").last())
	} else {
		refresh_disk(result[1])
	}
}

function refresh_disk(id) {
	$("#view_disk"+id).empty().html("Loading...");
	
	if (id > 0) {
		$.get("../show/show.php",{id:id},function(data,status){
			if(status == "success") {
				$("#view_disk"+id).html(data);
			}
		})
		
		$.post("ajax/disk_history.php?id=",{disk_id:id},function(data,status){
			if(status == "success") {
				$("#view_history").html(data);
			}
		})
	}
}

function refresh_disk_callback(id,callback,args) {
	$("#view_disk"+id).empty().html("Loading...");
	
	if (id > 0) {
		$.get("../show/show.php",{id:id},function(data,status){
			if(status == "success") {
				$("#view_disk"+id).html(data);
				callback(args);
			}
		})
	}
}