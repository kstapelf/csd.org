// JavaScript Document
$(function(){
	$("#disk_filter .resultbox").on('click',"li:not(.header,.bold)",function(){
					$(this).hide()
					var diskid = $(this).attr("diskid");
					var refid = $("[name='ref_id']").val();
					$.post("ajax/ref_disks.php?function=load_dr",{disk_id:diskid, ref_id:refid},function(data,status){
						if(status == "success") {
							var location = $('<div class="container alternate"></div>').insertAfter(".ref h3")
							location.html(data)
							$(location).click(function(e){e.stopPropagation()})
							add_reset(location);
							$(location).find("form").on('submit',save_dr)
						}
					})
				})
	
	$("#disk_filter .resultbox").on('click',"li.addnew",function(){
					tab = add_tab("New Disk "+count,-1)
					
					//add new tab content
					var name = $("#disk_filter form [name='name']").val();
					var ra = $("#disk_filter form [name='ra']").val();
					var dec = $("#disk_filter form [name='dec']").val();
					
					
					load_disk(-1*count,tab,[name,ra,dec])
					//add new section
					var diskid = -1*count;
					var refid = $("[name='ref_id']").val();
					
					//3. pass into load
					$.post("ajax/ref_disks.php?function=load_dr",{disk_id:diskid, ref_id:refid},function(data,status){
						
						if(status == "success") {
							var location = $('<div class="container alternate"></div>').insertAfter(".ref h3")
							location.html(data)
							$(location).click(function(e){e.stopPropagation()})
							add_reset(location);
							
							$(location).find("form").on('submit',function(e) {
								e.preventDefault();
								var diskid = $(this).find("[name='disk_id']").val()
								if (diskid < 0) {
									if (confirm("Save disk details first? (required)")) {
										//find the right form
										var number = $(this).find(".disk_id").attr("number")
										var form_finder = $(".tab.new .disk_id[number='"+number+"']").parents("form").first();
										var this_form = $(this)
										//save disk with callback to save_dr
										$(form_finder).trigger('submit')
									} else {
										return;
									}
								} else {
									save_dr.call(this,e)
								}
							})
						}
					})
					
					count++;
				})
	
	$("#disk_filter form").on('submit',function(e){
		e.preventDefault()
		var form = this
		$.post("ajax/filter_disks.php",$(this).serialize(),function(data,status){
			if(status == "success") {
				var target = $(form).siblings(".resultbox")
				target.html(data);
			}
		})
	})
	
	$("#disk_filter form").trigger("submit")
	
	$("#ref_details").on('submit',function(e,callback,args){
		e.preventDefault()
		var form = $(this)
		
		//check all required fields are filled out
		var all_filled = check_required(form);
		
		if (!all_filled) {
			alert("Please fill in all the required fields!");
			change_tab($("#tabbar").children().eq($(".tab").index($(form).parents(".tab"))));
		} else $.post("ajax/ref_disks.php?function=save_ref",$(form).serialize(),function(data,status){
			if(status == "success") {
				var result = data.split(";");
				
				if (result[2] != "") {
					alert(result[2]);
				}
				
				if (result[0]=="added") {
					$(".ref_id").val(result[1])
					window.history.replaceState("object or string", "Title", window.location.pathname+"?id="+result[1]);
				}
				
				add_reset(form) //resets default values
				
				if (!(typeof callback === 'undefined' || callback === null)) {
					callback(args,result)
				}
			}
		})
	})
})

var count = 1;

var save_dr_callback = function(form,result) {
				var new_dr = $(form).attr("newdr");
				new_dr = (typeof new_dr !== typeof undefined) && (new_dr !== false)
				console.log(new_dr)
				$.ajax({
					url: "ajax/ref_disks.php?function=save_dr",
					type: "POST",
					data: new FormData(form),
					contentType: false,
					cache: false,
					processData:false,
					success: function(data) {
						if (new_dr) {
							$(form).parents(".alternate").first().remove()
							var div = $(data).insertAfter(".ref h3");
						} else {
							var div = $(form).parent()
							$(div).removeAttr("loaded");
							div.empty().html(data)
						}
						div.find("a").click(function(e){e.preventDefault()})
					}
				})
			}

var save_dr = function(e) {
				e.preventDefault();
				var form = this
				
				//if new reference, make sure it's saved
				var refid = $("[name='ref_id']").val();
				if (refid < 0) {
					$("#ref_details").trigger("submit",[save_dr_callback, form])
				} else {
					save_dr_callback(form,null)
				} 
				
				
			}

//gets passed the div
function load_ref(location) {
	var ref = $(location).attr("ref")
	$.post("ajax/ref_disks.php?function=load_dr",{dr_id:ref},function(data,status){
		if(status == "success") {
			$(data).appendTo(location).click(function(e){e.stopPropagation()})
			add_reset(location);
			$(location).find("form").on('submit',save_dr)
		}
	})
}

function remove_dr(form) {
	if (confirm("Are you sure you want to delete this reference?")) {
		$.post("ajax/ref_disks.php?function=remove_dr",$(form).serialize(),function(data,status){
			if(status == "success") {
				$(form).parent().remove()
			}
		})
	}
}

function cancel_dr(form) {
	$.post("ajax/ref_disks.php?function=cancel_dr",$(form).serialize(),function(data,status){
		if(status == "success") {
			$(form).parent().removeAttr("loaded").empty().html(data);
			$(form).find("a").click(function(e){e.preventDefault()})
		}
	})
}

function save_callback(e,result) {
	//link this reference to disk
	var form = $(this)
	var number = form.find(".disk_id").attr("number");
	
	var dr_form = $(".ref").find(".disk_id[number="+number+"]").parents("form").first();
	
	dr_form.trigger("submit")
}