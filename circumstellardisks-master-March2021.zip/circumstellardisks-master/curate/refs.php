<?php
header("Cache-Control: no-store");
header("Pragma: no-cache");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/default.dwt.php" codeOutsideHTMLIsLocked="false" -->
<!-- InstanceBeginEditable name="initialize" -->
<?php

	define("root","../");
	require "../library.inc.php";
	include "library.curate.php";
	
	
	$ref_id = -1;
	if (isset($_GET['id']) && count(prepare_query("SELECT ref_id FROM refs WHERE ref_id = ?",$_GET['id'])))  $ref_id = $_GET['id'];

?>
<!-- InstanceEndEditable -->

<?php 
	//new is 2 months ago
	$sixmonths = date("Y-m-d",time()-(2*30*24*60*60));
	
?>


<head>
<!--Code written by Isabelle Jansen. Written for http://www.circumstellardisks.org/. Copyright 2016.-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- InstanceBeginEditable name="Keywords" --><meta name="keywords" content=""><!-- InstanceEndEditable -->
<base target="_blank">

<link rel="stylesheet" type="text/css" href="../layout/main.css" />
<link rel="stylesheet" type="text/css" href="../layout/mobile.css" />
<script type="text/javascript" src="../ajax/jquery-3.5.1.min.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Catalog of Circumstellar Disks | Edit Reference Details</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<script src="curate.js"></script>
<script src="refs.js"></script>

<style type="text/css"></style>
<script type="text/javascript">
$(function(){
	var ref_id = <?php echo $ref_id; ?>;
	if (ref_id > 0)  add_reset($('#ref_details'));
})
</script>
<!-- InstanceEndEditable -->
</head>

<body>

<div id="navbar" class="container">
<div>
<a class="col-2" href="../index.php" target="_self">Home
</a><a class="col-2" href="../search.php" target="_self">Search
</a><a class="col-2" href="../updates.php" target="_self">What's New
</a><a class="col-2" href="<?php echo root; ?>description.php" target="_self">Catalog Description
</a><span class="col-2 hover">Catalogs
<span><a href="../index.php?catalog=resolved" target="_self">Resolved Disks</a><a href="../index.php?catalog=candidate" target="_self">Unresolved Disks</a><a href="../index.php?catalog=refuted" target="_self">Refuted Disks</a></span></span>
</a><a class="col-2" href="../contribute.php">Contribute
</a></div></div>


<div id="banner"><div class="pagetitle" ><div><span><img src="../layout/imgs/pagetitle.png" alt="Catelog of Circumstellar Disks" /></span></div></div><img src="../layout/imgs/banner.png" class="banner"  /></div>

<div id="content" class="col-12">
<h1><!-- InstanceBeginEditable name="pagetitle" -->
Edit Reference Details
<!-- InstanceEndEditable --></h1><hr />

<!-- InstanceBeginEditable name="tabbar" -->
<ul id="tabbar" class="ellipsis"><li class="col-2"><span>Reference Details</span></li><li class="col-2"><span>Instructions</span></li></ul>
<hr class="clear" />
<!-- InstanceEndEditable -->


<!-- InstanceBeginEditable name="content" -->

<div id="tabholder">

<div class="tab container"><div>
	<div class="col-5 border-right">
    <div><h3>Reference Details</h3>
    <?php
	
		if ($ref_id > -1) {
            $refs = prepare_query("SELECT * FROM refs WHERE ref_id = ?",$ref_id);
            if ($ref_id > 0 && !$refs) {
                echo "Error: Could not find reference.";
                exit();
            }
            
            $ref = $refs[0];
		} else {
			$ref = array(
					"ref_id" => -1,
   					 "title" => "",
    				 "url" => "",
    				 "date" => "",
    				 "authors" => "",
					);
		}
   ?>
			<form id="ref_details" action="" class="container" enctype="multipart/form-data" method="post">
            
            <span class="manual-alternate1"><label><input type="hidden" name="ref_id" class="ref_id" value="<?php echo $ref_id; ?>" \>Title</label>
               <?php show_field("title","text",$ref['title'],true); ?>
                </span>
            <span class="manual-alternate0"><label>Link</label>
                <?php show_field("url","text",$ref['url'],true); ?>
                </span>
            <span class="manual-alternate1"><label>Date</label>
                <?php show_field("date","date",$ref['date']); ?>
                </span>
            <span class="manual-alternate0"><label>Authors</label>
                <?php show_field("authors","textarea",$ref['authors'],true); ?>
                </span>
            
            <span class="manual-alternate1"><span></span><span><input type="submit" value="Save" \><input type="reset" value="Reset" \></span></span>
            <?php $disks = prepare_query("SELECT DISTINCT disk_id, * FROM disk_refs WHERE ref_id = ?",$ref['ref_id']);
            if (count($disks) > 1) {
                echo "<span  class=\"manual-alternate0\"><span></span><i>".count($disks)." disks use this reference.</i></span>";
            } ?>
            </form>
            
            <hr>
    </div>
    
    <div id="disk_filter">
    <h3>Link A New Disk</h3>
    <?php 
		disk_filter($ref_id);
	?>
    <div class="resultbox"></div>
    </div>
    
    </div>

    <div class="col-7 ref"><h3>Disks in this reference</h3>
		<?php
            if (count($disks)) {
                foreach ($disks as $dr) {
                    display_disk_ref($dr['dr_id'],root);
                }
            }
        ?>
    </div>
</div></div>

<div class="tab">
<h2>Instructions</h2>
<p><b>Reference Details:</b> The information listed under "Reference Details" (Title, Authors, URL, Date) is shared by all the disks linked to the reference. When adding a new reference to the database, these details should be filled in first.</p><br />
<p><b>Editing Disk Details:</b> Double-click on a disk listed under "Disks in this Reference" to pull up the details specific to each disk, including the image upload. Of the four buttons, "Cancel" stops the changes made from saving, and "Remove" will remove the disk from linking to the reference.</p><br />
<p><b>Linking a Disk:</b> The disk filter form searches the database for possible matches that are not already linked to the disk. The "Name" input accepts a name or part of name, and will search both the name and second name fields. The RA and DEC fields accept either the standard RA/DEC inputs (DEC must start with + or -), or numerical values in degrees. Click on a result, then fill in the details per normal under "Disks in this Reference".</p><br />
<p><b>Adding a New Disk:</b> If the search doesn't find that the disk is already in the database (recommended to search by coordinates only), clicking "New Disk" in the search results will pull up a new tab under the page title that will allow you to fill out all the disk details. The values from the search will be automatically filled in. Saving the disk for the first time will automatically link the disk to the reference.</p>
</div>

</div>


<!-- InstanceEndEditable -->
<br />
<div id="footer">Created by Caer McCabe. Redesigned by Isabelle H. Jansen. Maintained by <a href="mailto:Karl.R.Stapelfeldt at jpl.nasa.gov">Karl Stapelfeldt</a>. Last updated <?php 
if (isset($disk_id)) $edit = prepare_query1("SELECT date FROM edits WHERE disk_id = ? ORDER BY date_dec DESC LIMIT 1",$disk_id); 
else $edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1"); 

echo date("F j, Y",strtotime($edit['date'])); ?>.</div>
</div>

</body>
<!-- InstanceEnd --></html>
