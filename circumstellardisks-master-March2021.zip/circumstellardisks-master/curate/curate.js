// JavaScript Document
$(function(){
	$("#tabholder").on("submit",".disk_details",{callback:save_callback},save_disk);
	
	change_tab($("#tabbar li").eq(0))
	
	$("#tabbar").on('click',"li:not(:has(input))",function(){
		change_tab(this)
		})
	
	$("#tabbar li:has(input[type='button'],input[type='submit'],input[type='reset'])").click(function(e){
		
	})
		
	bind_autofill($(".disk"))
	
	$("#tabholder").on("click","[ref]:not([loaded])",
	function(){
		$(this).attr("loaded","true")
		load_ref(this)
	})
	
	$(".tab").on("click",".ref a",function(e){e.preventDefault()})
	
});

var date_regex = /^\d{4}-(0[1-9]|1[0-2])-[0-3]\d$/;

function change_tab(span) {
	$(span).siblings().children().removeClass("selected")
	$(span).children().addClass("selected")
	$("#tabholder").children().hide().eq($("#tabbar li").index(span)).show()
}

function add_tab(name,index) {
	//add tab
	tab = "<li class=\"col-2\"></li>";
	if (index >= 0) tab = $(tab).insertBefore($("#tabbar>*").eq(index))
	else tab = $(tab).appendTo($("#tabbar"))
	$(tab).html("<span>"+name+"</span>");
		
	//add division
	div = "<div class=\"tab new\"></div>"
	if (index >= 0) div = $(div).insertAfter($("#tabholder .tab").eq(index-1))
	else div = $(div).appendTo($("#tabholder"))
	
	return div
}

function add_reset(form) {
	$(form).removeClass("highlight").removeClass("alert").find("*").removeClass("highlight").removeClass("alert");
	
	//text reset- the input box remembers the original value
	$(form).find(":input").not("[type='radio'],[type='checkbox'],[type='file']").each(function(){
			$(this).prop("origVal",$(this).val());	//stores original value
			$(this).prop("parentRow",$(this).parents().filter(function(){ return $(this).css("display")=="table-row" }).first())//stores table-row
			$(this).prop("parentRow").not("form").dblclick(function(){	//resets on dblclick
				$(this).removeClass("highlight");
				$(this).find(":input").each(function(){ $(this).val($(this).prop("origVal"))})
			})
		}).blur(function() {	//checks to highlight or not
			if ($(this).val() != $(this).prop("origVal")) {
				$(this).prop("parentRow").addClass("highlight");
			} else {
				var clear = true;
				$(this).prop("parentRow").find(":input").each(function(){ clear = clear&&($(this).val()==$(this).prop("origVal")); })
				if (clear) $(this).prop("parentRow").removeClass("highlight");
			}
		})
		
	//textareas allow to doubleclick inside box
	$(form).find("textarea").dblclick(function(e){
		e.stopPropagation();
	})
		
	//drop-down lists set properties differently
	$(form).find("select").change(function() {	//checks to highlight or not
			if ($(this).val() != $(this).prop("origVal")) {
				$(this).prop("parentRow").addClass("highlight");
			} else {
				var clear = true;
				$(this).prop("parentRow").find(":input").each(function(){ clear = clear&&($(this).val()==$(this).prop("origVal")); })
				if (clear) $(this).prop("parentRow").removeClass("highlight");
			}
		})
		
	//radio reset- the parent span remembers the original value
	$(form).find("span:has(>:input[type='radio'])").each(function(){
			$(this).prop("origVal",$(this).find(":input[type='radio']:checked").val());	//stores original value
			
			if ($(this).css("display")=="table-row") $(this).prop("parentRow",$(this));
			else $(this).prop("parentRow",$(this).parents().filter(function(){ return $(this).css("display")=="table-row" }).first())//stores table-row
			
			$(this).prop("parentRow").dblclick(function(){	//resets on dblclick
				$(this).removeClass("highlight");
				var span = $(this).find("span:has(>:input[type='radio'])")
				$(this).find(":input[type='radio'][value=" + $(span).prop("origVal") + "]").prop('checked', true);
			})
		}).find(":input[type='radio']").click(function() {	//checks to highlight or not
			if ($(this).val() != $(this).parent().prop("origVal")) {
				$(this).parent().prop("parentRow").addClass("highlight");
			} else {
				$(this).parent().prop("parentRow").removeClass("highlight");
			}
		})
		
	//checkbox reset- the checkbox remembers if it was checked or not
	$(form).find(":input[type='checkbox']").each(function(){
			$(this).prop("origVal",$(this).prop("checked"));	//stores original value
			$(this).prop("parentRow",$(this).parents().filter(function(){ return $(this).css("display")=="table-row" }).first())
			$(this).prop("parentRow").dblclick(function(){	//resets on dblclick
				$(this).removeClass("highlight");
				$(this).find(":input[type='checkbox']").each(function(){
					$(this).prop("checked",$(this).prop("origVal"));
				})
			})
		}).click(function() {	//checks to highlight or not
			if ($(this).prop("checked") != $(this).prop("origVal")) {
				$(this).prop("parentRow").addClass("highlight");
			} else { //loop through all of them
				var clear = true;
				$(this).siblings(":input[type='checkbox']")
						.each(function(){ clear = clear&&($(this).prop("checked")==$(this).prop("origVal")); })
				if (clear) $(this).prop("parentRow").removeClass("highlight");
			}
		})	
		
	//image preview
	$(form).find(":input[type='file']").each(function(){
			$(this).prop("origVal",$(this).val());
			$(this).siblings("img").prop("origVal",$(this).val());	//stores original value
			$(this).prop("parentRow",$(this).parents().filter(function(){ return $(this).css("display")=="table-row" }).first())//stores table-row
			$(this).prop("parentRow").dblclick(function(){	//resets on dblclick
				$(this).css("background-color","")
				var field = $(this).find(":input")
				field.val(field.prop("origVal"))
				var img = $(this).find("img")
				img.attr("src",img.prop("origVal"))
			})
		}).change(function() {	//checks to highlight or not
			if ($(this).val() != $(this).prop("origVal")) {
				$(this).prop("parentRow").addClass("highlight");
				
				//generate preview with magic
				var input = this
				if (input.files && input.files[0]) {
					var reader = new FileReader();
	
					reader.onload = function (e) {
						$(input).siblings("img").attr('src', e.target.result);
					}
	
					reader.readAsDataURL(input.files[0]);
				}
        
			} else {
				$(this).prop("parentRow").removeClass("highlight");
			}
		})
		
	$(form).find("[type='reset']").click(function(e) {
		$(form).find("*").removeClass("highlight").removeClass("alert");
		$(form).find("img").each(function(){ $(this).attr("src",$(this).prop("origVal")) })
	})
}

function bind_autofill(form) {
	form = $(form)
	if (form.find("[name='spatial_res']").val()!="") {
		form.find("[name='spatial_res']").attr("auto","false");
	} else {
		form.find("[name='spatial_res']").attr("auto","true");
	}
	
	form.on("blur","[name='dmirror'],[name='wavelength']",function(){
		//find all three fields
		var tab = $(this).parents(".tab").first();
		var mirror = tab.find("[name='dmirror']").val()
		var wavelength = tab.find("[name='wavelength']").val()
		var spacial_res = tab.find("[name='spatial_res']")
		if ((spacial_res.attr("auto")=="true")&&(mirror!="")&&(wavelength!="")) {
			//Spacial Resolution = wavelength/mirror converted to arcsecs
			spacial_res.val((wavelength*Math.pow(10,-6)*180*3600/(mirror*Math.PI)).toPrecision(4))
		}
	})
		
	form.on("blur","[name='spatial_res']",function(){
		if ($(this).val() != "") {
			$(this).attr("auto","false");
		} else {
			$(this).attr("auto","true");
		}
	})
}


function load_disk(id,tab,args) {
	$(tab).empty().html("Loading...");
	
	$.post("ajax/load_disk.php",{disk_id:id},function(data,status){
		if(status == "success") {
			$(tab).html(data);
			
			var name = args[0];
			var ra = args[1];
			var dec = args[2];
			
			$(tab).find("[name='name']").val(name);
			$(tab).find("[name='ra']").val(ra);
			
			$(tab).find("[name='dec']").val(dec);
			
			bind_autofill(tab)
			
			if (id > 0) add_reset(tab);
		}
	})
}

function check_required(form) {
	var all_filled = true;
	form.find("[required]").removeClass("alert").each(function(){
		this_filled = !($(this).val()=="")
		if (!this_filled) $(this).addClass("alert")
		all_filled = all_filled && this_filled
	})
	return all_filled
}


var save_disk = function(e) {
	e.preventDefault();
	
	var form = $(this)
	
	//check all required fields are filled out
	var all_filled = check_required(form);
	
	if (!all_filled) {
		alert("Please fill in all the required fields!");
		change_tab($("#tabbar").children().eq($(".tab").index($(form).parents(".tab"))));
	} else $.post("ajax/save_disk.php",$(form).serialize(),function(data,status){
		if(status == "success") {
			var result = data.split(";");
			
			if (result[2] != "") {
				alert(result[2]);
			}
			
			if (result[0]=="added") {
				count = $(form).find(".disk_id").attr("number")
				$(".disk_id[number='"+count+"']").val(result[1])
			}
			
			if (result[0]=="added" || result[0]=="normal") {
				add_reset(form) //resets default values
			}
			
			e.data.callback.call(form,e,result)
		}
	})
}