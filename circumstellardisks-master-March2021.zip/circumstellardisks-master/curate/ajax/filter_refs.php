<?php
	define("root","../../");
	require "../../library.inc.php";
	require "../library.curate.php";
	
	$query = "SELECT DISTINCT ref_id, * FROM refs
				WHERE NOT ref_id IN (SELECT ref_id FROM disk_refs WHERE disk_id = ?)";
	$args = array($_POST['disk_id']);
	
	//if title
	$title = $_POST['title'];
	if ($title) {
		$query .= " AND title LIKE ?";
		$args[] = "%".$title."%";
	}
	
	//if url
	$url = $_POST['url'];
	if ($url) {
		$query .= " AND url LIKE ?";
		$args[] = "%".$url."%";
	}
	
	//if authors
	$authors = $_POST['authors'];
	if ($authors) {
		$query .= " AND authors LIKE ?";
		$args[] = "%".$authors."%";
	}
	
	
	$date = $_POST['date'];
	$date_dec = date_to_dec($date);
	
	$datespan = $_POST['datespan'];
	
	
	if (is_numeric($date_dec) && isset($_POST['daterange']) && is_numeric($datespan) && ($datespan!=0)) { //if search nearby
			$query .= " AND date_dec BETWEEN ? AND ?";
			$datespan /= 12;
			if ($datespan<0) $datespan *= -1;
			$args[] = $date_dec - $datespan;
			$args[] = $date_dec + $datespan;
	} else if (is_numeric($date)) {
		$query .= " AND date = ?";
		$args[] = $date;
	}
	
	$query .= " ORDER BY title";
	
	$results = call_user_func_array(prepare_query,array_merge(array($query),$args));
	echo "<ul class=\"nodots container ellipsis fake-link\">";
	echo "<li class=\"bold addnew\"><span>New Reference</span><span></span><span></span></li>";
	echo "<li class=\"header\"><span>Title</span><span>Authors</span><span>URL</span></li>";
	foreach ($results as $ref) {
		?>
		<li refid="<?php echo $ref['ref_id']; ?>" date="<?php echo $ref['date']; ?>">
           	<span class="title"><?php echo $ref['title']; ?></span>
            <span class="authors" val="<?php echo $ref['authors']; ?>"><?php echo $ref['authors']; ?></span>
    	    <span class="url"><a href="<?php echo $ref['../../curate/ajax/url']; ?>"><?php echo $ref['url']; ?></a></span>
        </li>
		<?php
	}
	
	
	
	
	echo "</ul>";
?>