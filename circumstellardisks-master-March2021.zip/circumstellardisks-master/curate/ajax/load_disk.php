<?php
	if (!defined('root')) {
		define('root',"../../");
	}
	
	require_once root."library.inc.php";
	require_once root."curate/library.curate.php";
	
	if (!isset($disk_id)) {
		$disk_id = $_POST['disk_id'];
	}
	
	if ($disk_id < 0) {
		$disk = array();
	} else {
		$disk = prepare_query1("SELECT * FROM disks WHERE disk_id = ?",$disk_id);
	}

	$cols = prepare_query("SELECT * FROM disk_cols WHERE NOT type = ?","calculate");
?>
	<form class="disk_details">
	<input name="disk_id" class="disk_id" <?php echo ($disk_id<0)?"number=\"".(-1*$disk_id)."\"":"";?> type="hidden" value="<?php echo $disk_id; ?>">
	<div class="col-6 border-right"><div class="container">
<?php 
$i = 0;
$split = 15;
//separate into 2 columns, splitting at i=15
foreach ($cols as $c) {
	echo "<span class=\"alternate\"><label>".$c['display'].($c['required']?"*":"")."</label>";
	
	$val = isset($disk[$c['col']])?$disk[$c['col']]:'';
	
	show_field($c['col'],$c['type'],$val,$c['required']);
	
	echo "</span>\n\t\t";
	if ($i == $split) {
		echo '</div></div><div class="col-6"><div class="container">';
	}
	$i++;
}
?>
<span><input type="submit" class="save_disk" value="Save Disk" /><input type="reset" value="Reset All" /></span>
</div></div>
<br class="clear" />
</form>
