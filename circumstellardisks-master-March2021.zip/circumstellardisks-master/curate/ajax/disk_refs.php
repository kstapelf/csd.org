<?php
	define('root',"../../");
	require "../../library.inc.php";
	require "../library.curate.php";
	
	$valid_functions = array("load","newref","save","cancel","remove");

	function load() {
		$dr_id = $_POST['id'];
		$refs = get_ref_by_dr($dr_id);
		if (!$refs) {
			echo "Error: Could not find reference.";
			echo "<hr class=\"clear\">";
			exit();
		}
		
		$ref = $refs[0];
		
		echo "<form action=\"\" enctype=\"multipart/form-data\" method=\"post\" style=\"overflow:hidden\">";
		echo "<div class=\"col-4 border-right\"><div class=\"container\"><input type=\"hidden\" name=\"id\" value=\"".$dr_id."\" \>";
		echo "<span><label>Title</label>";
			show_field("title","text",$ref['title'],true);
			echo "</span>";
		echo "<span><label>Link</label>";
			show_field("url","text",$ref['url'],true);
			echo "</span>";
		echo "<span><label>Date</label>";
			show_field("date","date",$ref['date']);
			echo "</span>";
		echo "<span><label>Authors</label>";
			show_field("authors","textarea",$ref['authors'],true);
			echo "</span></div>";
		
		$shared = prepare_query("SELECT DISTINCT disk_id FROM disk_refs WHERE ref_id = ? AND NOT disk_id = ?",$ref['ref_id'],$ref['disk_id']);
		if (count($shared)) {
			echo "<span><i>This reference is shared by ".count($shared)." other disk".(count($shared)>1?"s":"").".</i></span>";
		}
		
		echo '</div><div class="col-4 border-right">';
		echo "<input type=\"submit\" value=\"Save\" \>
				<input type=\"reset\" value=\"Reset\" \>
				<input type=\"button\" value=\"Cancel\" onClick=\"cancel_ref($(this).parents('form').first())\"\>
				<input type=\"button\" value=\"Remove\" onClick=\"remove_ref($(this).parents('form').first())\"\>";
		
		echo "<div class=\"container\"><span><label>Photo Alt</label>";
			show_field("img_alt","text",$ref['img_alt']);
			echo "</span>";
		
		echo "<span><label>Description</label>";
			show_field("description","textarea",$ref['description']);
			echo "</span>";
		
		
		
		echo "</div></div><div class=\"col-4\"><div class=\"container\">";
		echo "<span><label>Photo</label>";
			show_field("image","image",$ref['photo']);
			echo "</span>";
		echo "</div></div>
			</form>";
	}
	
	function newref() {
		$ref_id = $_POST['id'];
		$disk_id = $_POST['disk_id'];
		
		if ($ref_id < 0 && (trim($_POST['title']," \t") != "")) {
			//add new first
			$name = rand();
			prepare_query("INSERT INTO refs(title,authors,date,url) VALUES (?,?,?,?)",$name,'0','0','0');
			$new_ref = prepare_query1("SELECT ref_id FROM refs WHERE title = ? AND url = ?",$name,'0');
			$ref_id = $new_ref['ref_id'];
		}
		
		//save into database
		prepare_query("INSERT INTO disk_refs(disk_id,ref_id) VALUES (?,?)",$disk_id,$ref_id);
		
		//get dr_id
		$new_ref = prepare_query1("SELECT dr_id FROM disk_refs WHERE disk_id = ? AND ref_id = ?",$disk_id,$ref_id);
		
		save($new_ref['dr_id']);
	}
	
	function save($dr_id = NULL) {
		$wrapper = true;
		if (!isset($dr_id)) {
			$dr_id = $_POST['id'];
			$wrapper = false;
		}
		
		//1. Save refs table
		$ref = prepare_query1("SELECT disk_id, ref_id FROM disk_refs WHERE dr_id = ?",$dr_id);
		
			//clean input
			$title = clean_string($_POST['title']);
			$authors = clean_textarea($_POST['authors']);
			$date = clean_string($_POST['date']);
			$date_dec = date_to_dec($date);
			$url = clean_string($_POST['url']);
			
			prepare_query("UPDATE refs SET title = ?, authors = ?, date = ?, date_dec = ?, url = ? WHERE ref_id = ?",$title,$authors,$date,$date_dec,$url,$ref['ref_id']);
		
		if ($wrapper) {
			$change_message = "Disk linked to Reference #".$ref['ref_id']." \"".$title."\"";
		}
		
		//2. Update description
			$description = clean_textarea($_POST['description']);
			$img_alt = clean_string($_POST['img_alt']);
			prepare_query("UPDATE disk_refs SET description = ?, img_alt = ? WHERE dr_id = ?",$description,$img_alt,$dr_id);
			
		//3. Update images
		$file = $_FILES['image'];
		if ($file['size'] > 0) {
			$old = prepare_query1("SELECT photo FROM disk_refs WHERE dr_id = ?",$dr_id);
			$filename = save_image($file);
			if ($filename) prepare_query("UPDATE disk_refs SET photo = ? WHERE dr_id = ?",$filename,$dr_id);
			$change_message .= ($change_message != ""?". Image added at ":"Reference #".$ref['ref_id']." \"".$title."\" image changed from \"".$old['photo']."\" to \"").$filename."\"";
		}
		
		//pull & show saved reference
		display_ref($dr_id,"../",$wrapper);
		
		set_update($change_message,$ref['disk_id']);
	}
	
	
	function cancel() {
		$dr_id = $_POST['id'];
		
		//pull & show saved reference- no saving
		display_ref($dr_id,"../",false);
	}
	
	function remove() {
		$dr_id = $_POST['id'];
		$dr = prepare_query1("SELECT * FROM disk_refs WHERE dr_id = ?",$dr_id);
		$ref = prepare_query1("SELECT * FROM refs WHERE ref_id = ?",$dr['ref_id']);
		
		//delete all for disk and ref
		prepare_query("DELETE FROM disk_refs WHERE ref_id = ? AND disk_id = ?",$dr['ref_id'],$dr['disk_id']);
		
		//if no disks left reference it, delete ref
		if (!count(prepare_query("SELECT * FROM disk_refs WHERE ref_id = ?",$dr['ref_id']))) {
			prepare_query("DELETE FROM refs WHERE ref_id = ?",$dr['ref_id']);
		}
		
		set_update("Reference to #".$dr['ref_id']." \"".$ref['title']."\" removed",$dr['disk_id']);
	}
	
	$function = $_GET['function'];
	
	if (in_array($function,$valid_functions)) {
		$function();
	} else {
		echo "Invalid Call.";
	}
?>