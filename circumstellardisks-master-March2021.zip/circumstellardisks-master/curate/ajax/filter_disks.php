<?php
	define("root","../../");
	require "../../library.inc.php";
	require "../library.curate.php";
	
	$query = "SELECT DISTINCT disk_id, name, secondname, ra, dec
				FROM disks
				WHERE NOT disk_id IN (SELECT disk_id FROM disk_refs WHERE ref_id = ?)";
	$args = array($_POST['ref_id']);
	
	//if name
	$name = $_POST['name'];
	if ($name) {
		$query .= " AND (name LIKE ? OR secondname LIKE ?)";
		$args[] = "%".$name."%";
		$args[] = "%".$name."%";
	}
	
	$ra = position_to_degrees($_POST['ra']);
	$dec = position_to_degrees($_POST['dec']);
	
	
	if (is_numeric($ra) && is_numeric($dec) && isset($_POST['nearby'])) { //if search nearby
			$arr = near($ra,$dec,$_POST['dist']);
			if ($arr["query"]) {
				$query .= " AND ".$arr["query"];
				$args = array_merge($args,$arr['args']);
			}
	} else if (is_numeric($ra)) {
		$query .= " AND ra_deg = ?";
		$args[] = $ra;
	} else if (is_numeric($dec)) {
		$query .= " AND dec_deg = ?";
		$args[] = $dec;
	}
	
	$order_arr = order_disks($_POST['order'],$ra,$dec);
	$query .= $order_arr[0].$order_arr[1];
	
	$results = call_user_func_array(prepare_query,array_merge(array($query),$args,$order_arr[2]));
	
	echo "<ul class=\"nodots container ellipsis fake-link\">";
	echo "<li class=\"bold  addnew\"><span>New Disk</span><span></span><span></span></li>";
	echo "<li class=\"header\"><span>Name</span><span>RA</span><span>DEC</span></li>";
	
	foreach ($results as $r) {
		echo "<li diskid=\"".$r['disk_id']."\"><span name=\"name\">".add_html($r['name']).($r['secondname']!=""?(" / ".$r['secondname']):"")."</span><span name=\"ra\">".$r['ra']."</span><span name=\"dec\">".$r['dec']."</span></li>";
	}
	echo "</ul>";
?>