<?php
	define('root',"../../");
	require "../../library.inc.php";
	require "../library.curate.php";
	
	$valid_functions = array("load_dr","save_dr","cancel_dr","remove_dr","save_ref","merge_ref");

	function load_dr() {
		$dr_id = $_POST['dr_id'];
		if (!isset($dr_id)) $dr_id = -1;
		
		if ($dr_id < 0) {
			$dr_id = -1;
			$ref_id = $_POST['ref_id'];
			if (isset($ref_id)) {
				$ref['ref_id'] = $ref_id;
			} else {
				$ref['ref_id'] = -1;
			}
			
			$disk_id = $_POST['disk_id'];
			if (isset($ref_id)) {
				$ref['disk_id'] = $disk_id;
			} else {
				$ref['disk_id'] = -1;
			}
		} else {
			$refs = get_ref_by_dr($dr_id);
			if (!$refs) {
				echo "Error: Could not find reference.";
				echo "<hr class=\"clear\">";
				exit();
			}
			
			$ref = $refs[0];
		}
		
		if ($ref['disk_id'] < 0) {
			$disk['name'] = "New Disk ".(-1*$ref['disk_id']);
		} else {
			$disk = prepare_query1("SELECT * FROM disks WHERE disk_id = ?",$ref['disk_id']);
		}
		
		echo "<form action=\"\" enctype=\"multipart/form-data\" method=\"post\"".($dr_id<0?" newdr=\"true\"":"").">
    			<input type=\"hidden\" name=\"dr_id\" value=\"".$dr_id."\" \>
				<input type=\"hidden\" name=\"ref_id\" class=\"ref_id\" value=\"".$ref['ref_id']."\" \>
				<input type=\"hidden\" name=\"disk_id\" class=\"disk_id\" ".($ref['disk_id']<0?"number=\"".(-1*$ref['disk_id'])."\"":"")."value=\"".$ref['disk_id']."\" \>";
		
		
		
		
		
		echo "<div class=\"col-6 border-right\"><div class=\"container\">";
		echo "<span><b></b><span class=\"header\">".display_string($disk['name']).($disk['secondname']!=''?' ('.$disk['secondname'].')':'')."</span></span>";
		echo "<span><label>Photo Alt</label>";
			show_field("img_alt","text",$ref['img_alt']);
			echo "</span>";
		
		echo "<span><label>Description</label>";
			show_field("description","textarea",$ref['description']);
			echo "</span></div>";
		if ($dr_id < 0) {
			echo "<input type=\"submit\" value=\"Add\" \>
				<input type=\"reset\" value=\"Reset\" \>
				<input type=\"button\" value=\"Cancel\" onClick=\"cancel_dr($(this).parents('form').first())\"\>";
		} else {
			echo "<input type=\"submit\" value=\"Save\" \>
				<input type=\"reset\" value=\"Reset\" \>
				<input type=\"button\" value=\"Cancel\" onClick=\"cancel_dr($(this).parents('form').first())\"\>
				<input type=\"button\" value=\"Remove\" onClick=\"remove_dr($(this).parents('form').first())\"\>";
		}
		
		
		
		echo "</div><div class=\"col-6\"><div class=\"container\">";
		echo "<span><label>Photo</label>";
			show_field("image","image",$ref['photo']);
			echo "</span></div>";
		echo "</div>
			</form>";
	}
	
	function save_dr() {
		$dr_id = $_POST['dr_id'];
		$ref_id = $_POST['ref_id'];
		$wrapper = false;
		$change_message = "";
		$ref = prepare_query1("SELECT title FROM refs WHERE ref_id = ?",$ref_id);
		
		//Add if needed
		if (!isset($dr_id) || $dr_id < 0) {
			$disk_id = $_POST['disk_id'];
			prepare_query("INSERT INTO disk_refs(disk_id,ref_id) VALUES (?,?)",$disk_id,$ref_id);
			$new_ref = prepare_query1("SELECT dr_id FROM disk_refs WHERE disk_id = ? AND ref_id = ?",$disk_id,$ref_id);
			$dr_id = $new_ref['dr_id'];
			$wrapper = true;
			$change_message = "Disk linked to Reference #".$ref_id." \"".$ref['title']."\"";
		}
		
		//1. Update description
		$description = clean_textarea($_POST['description']);
		$img_alt = clean_string($_POST['img_alt']);
		prepare_query("UPDATE disk_refs SET description = ?, img_alt = ? WHERE dr_id = ?",$description,$img_alt,$dr_id);
			
		//2. Update images
		$file = $_FILES['image'];
		if ($file['size'] > 0) {
			$old = prepare_query1("SELECT photo FROM disk_refs WHERE dr_id = ?",$dr_id);
			
			$filename = save_image($file);
			if ($filename) prepare_query("UPDATE disk_refs SET photo = ? WHERE dr_id = ?",$filename,$dr_id);
			
			$change_message .= ($change_message != ""?". Image added at ":"Reference #".$ref_id." \"".$ref['title']."\" image changed from \"".$old['photo']."\" to \"").$filename."\"";
		}
		
		//pull & show saved reference
		display_disk_ref($dr_id,"../",$wrapper);
		
		set_update($change_message,$disk_id);
	}
	
	function cancel_dr() {
		$dr_id = $_POST['dr_id'];
		
		//pull & show saved reference- no saving
		display_disk_ref($dr_id,"../",false);
	}
	
	function remove_dr() {
		$dr_id = $_POST['dr_id'];
		$dr = prepare_query1("SELECT * FROM disk_refs WHERE dr_id = ?",$dr_id);
		$ref = prepare_query1("SELECT * FROM refs WHERE ref_id = ?",$dr['ref_id']);
		
		prepare_query("DELETE FROM disk_refs WHERE dr_id = ?",$dr_id);
		set_update("Reference to #".$dr['ref_id']." ".$ref['title']." removed",$dr['disk_id']);
	}
	
	function save_ref() {
		//Check to add!
		$ref_id = $_POST['ref_id'];
		
		//add new reference if needed
		if ($ref_id < 0) {
			//add new first
			$name = rand();
			prepare_query("INSERT INTO refs(title,authors,date,url) VALUES (?,?,?,?)",$name,'0','0','0');
			$new_ref = prepare_query1("SELECT ref_id FROM refs WHERE title = ? AND url = ?",$name,'0');
			$ref_id = $new_ref['ref_id'];
			echo "added;".$ref_id.";";
		} else echo "normal;".$ref_id.";";
		
		//clean input
		$title = clean_string($_POST['title']);
		$authors = clean_textarea($_POST['authors']);
		$date = clean_string($_POST['date']);
		$date_dec = date_to_dec($date);
		$url = clean_string($_POST['url']);
			
		prepare_query("UPDATE refs SET title = ?, authors = ?, date = ?, date_dec = ?, url = ? WHERE ref_id = ?",$title,$authors,$date,$date_dec,$url,$ref_id);
	}
	
	function merge_ref() {
		$to = $_POST['to'];
		$from = $_POST['from'];
		
		prepare_query("UPDATE disk_refs SET ref_id = ? WHERE ref_id = ?",$to,$from);
		prepare_query("DELETE FROM refs WHERE ref_id = ?",$from);
	}
	
	$function = $_GET['function'];
	
	if (in_array($function,$valid_functions)) {
		$function();
	} else {
		echo "Invalid Call.";
	}
?>