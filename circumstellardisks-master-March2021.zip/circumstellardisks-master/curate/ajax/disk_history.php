<?php
	if (!defined('root')) {
		define('root',"../../");
	}
	
	require_once root."library.inc.php";
	require_once root."curate/library.curate.php";
	
	if (!isset($disk_id)) {
		$disk_id = $_POST['disk_id'];
	}
	
	$results = prepare_query("SELECT * FROM edits WHERE disk_id = ? ORDER BY date_dec DESC",$disk_id);
?>

<div class="resultbox-container" style="max-height:400px;height:400px;">
<ul class="nodots container">
<li class="header"><span class="col-3">Date</span><span>Edit</span></li>

<?php
    foreach ($results as $edit) {
		?>
		<li>
           	<span><?php echo date("F j Y, g:i:s a",strtotime($edit['date'])); ?></span>
            <span><?php echo $edit['change']; ?></span>
        </li>
		<?php
	}
	?>
	</ul>
</div>
