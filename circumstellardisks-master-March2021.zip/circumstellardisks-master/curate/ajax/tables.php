<?php
	define('root',"../../");
	require "../../library.inc.php";
	require "../library.curate.php";
	
	$valid_functions = array("save_col","save_band");

	function save_col() {
		if (isset($_POST['type'])) {
			prepare_query("UPDATE disk_cols SET display = ?, type = ?, required = ? WHERE col = ?",
				clean_string($_POST['display']),
				clean_string($_POST['type']),
				clean_string($_POST['required']),
				$_POST['col']);
		} else {
			prepare_query("UPDATE disk_cols SET display = ?, required = ? WHERE col = ?",
				clean_string($_POST['display']),
				clean_string($_POST['required']),
				$_POST['col']);
		}
	}
	
	function save_band() {
		$band_id = $_POST['band_id'];
		if ($band_id < 0) {
			$rand = rand();
			prepare_query("INSERT INTO bands(band) VALUES(?)",$rand);
			extract(prepare_query1("SELECT band_id FROM bands WHERE band = ?",$rand));
		}
		
		prepare_query("UPDATE bands SET band = ?, source = ?, wavelength = ?, units = ?, fdefault = ? WHERE band_id = ?",
							clean_string($_POST['band']),
							clean_string($_POST['source']),
							clean_string($_POST['wavelength']),
							clean_string($_POST['units']),
							clean_string($_POST['fdefault']),
							$band_id
							);
		echo $band_id;
	}
	
	$function = $_GET['function'];
	
	if (in_array($function,$valid_functions)) {
		$function();
	} else {
		echo "Invalid Call.";
	}
?>