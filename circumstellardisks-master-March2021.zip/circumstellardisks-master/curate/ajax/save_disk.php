<?php
	define('root',"../../");
	require root."library.inc.php";
	include root."curate/library.curate.php";
	
	//results go in format:
	//status;disk_id;alert_message
	
	$data = $_POST;
	$disk_id = $data['disk_id'];
	
	$change_message = "";
	
	//add new disk if needed
	if ($disk_id < 0) {
		$ra = $data['ra'];
		$dec = $data['dec'];
		
		$location_check = prepare_query("SELECT disk_id, name, secondname FROM disks WHERE ra = ? AND dec = ?",$ra,$dec);
		
		if (count($location_check) == 0) {
			prepare_query("INSERT INTO disks(name,date,ra,dec) VALUES (?,?,?,?)",
								$data['name'],$data['date'],$ra,$dec);
			
			extract(prepare_query1("SELECT disk_id FROM disks WHERE ra = ? AND dec = ?",$ra,$dec));
			echo "added;".$disk_id.";";
			$change_message = "Disk ".clean_string($data['name'])." added";
		} else {
			$disk = $location_check[0];
			echo "duplicate;".$disk['disk_id'].";";
			echo "Disk ".$disk['name'].($disk['secondname']!=""?" (".$disk['secondname'].")":"")." already exists at this position.";
			exit();
		}
	} else {
		echo "normal;".$disk_id.";";
	}
	
	//calculate fields as needed
		//ra_deg
		$data['ra_deg'] = position_to_degrees($data['ra']);
		
		//dec_deg
		$data['dec_deg'] = position_to_degrees($data['dec']);
	
		//size_au = round( dist * majorextent )
		if (is_numeric($data['dist']) && is_numeric($data['majorextent'])) {
			$data['size_au'] = round($data['dist']*$data['majorextent']);
		}
		
		//major_res = round( majorextent / spatial_res ,1) to nearest 0.1
		if (is_numeric($data['majorextent']) && is_numeric($data['spatial_res'])) {
			$data['major_res'] = round($data['majorextent']/$data['spatial_res'],1);
		}
		
		//date = today if not set
		if ($data['date'] == "") $data['date'] = get_date("today");
		
		//date_dec
		$data['date_dec'] = date_to_dec($data['date']);
		
		//KsMinusW4 gets updated if magnitudes are saved
		
	
	//grab columns and loop through sanitization
	$col_str = "";
	$args = array();
	
	$columns = prepare_query("SELECT * FROM disk_cols WHERE NOT col = ?","disk_id");
	
	foreach ($columns as $c) {
		$col_str .= " ".$c['col']." = ?,";
		$args[] = ($c['type']=="textarea")?clean_textarea($data[$c['col']]):clean_string($data[$c['col']]);
	}
	
	//find new values
	$old = prepare_query1("SELECT * FROM disks WHERE disk_id = ?",$disk_id);
	$val_change = array_diff_assoc($data,$old);
	if (count($val_change) && $change_message == "") {
		$change_message = "Changed ";
		foreach ($val_change as $key=>$val) {
			$change_message .= $key." from \"".$old[$key]."\" to \"".$val."\", ";
		}
		$change_message = trim($change_message,", ");
	}
	
	
	//save data
	$query_str = "UPDATE disks SET".rtrim($col_str,",")." WHERE disk_id = ?";
	$args[] = $disk_id;
	call_user_func_array(prepare_query,array_merge(array($query_str),$args));
	echo "Disk data saved.";
	
	set_update($change_message,$disk_id);
?>