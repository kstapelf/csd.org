<?php
	define("root","../../");
	require "../../library.inc.php";
	require "../library.curate.php";
	
	$valid_functions = array("save","update_date");
	
	function save() {
		$disk_id = $_POST['disk_id'];
		$band_id = $_POST['band_id'];
		
		$results = prepare_query("SELECT * FROM disk_bands WHERE disk_id = ? AND band_id = ?",$disk_id,$band_id);
		if (!count($results)) {
			prepare_query("INSERT INTO disk_bands(disk_id,band_id) VALUES (?,?)",$disk_id,$band_id);
		}
		
		if ($_POST['magnitude'] == '') {
			prepare_query("DELETE FROM disk_bands WHERE disk_id = ? AND band_id = ?",$disk_id,$band_id);
		} else {
			prepare_query("UPDATE disk_bands SET magnitude = ?, uncertainty = ?, units = ? WHERE disk_id = ? AND band_id = ?",
							clean($_POST['magnitude']),clean($_POST['uncertainty']),clean($_POST['units']),$disk_id,$band_id);
				
			if ($_POST['select_reference'] > 0) {
				prepare_query("UPDATE disk_bands SET dr_id = ? WHERE disk_id = ? AND band_id = ?",
							$_POST['select_reference'],$disk_id,$band_id);
			} else {
				prepare_query("UPDATE disk_bands SET dr_id = ? WHERE disk_id = ? AND band_id = ?",
							NULL,$disk_id,$band_id);
			}
		}
		
		//update KsMinusW4
		$Ks = prepare_query1("SELECT band_id FROM bands WHERE wavelength = ? AND source LIKE ?","2.159","2MASS");
		$W4 = prepare_query1("SELECT band_id FROM bands WHERE wavelength = ? AND source LIKE ?","22.0","WISE");
		
		if ($band_id == $Ks['band_id'] || $band_id == $W4['band_id']) {
			$mags = prepare_query("SELECT magnitude, band_id, units FROM disk_bands WHERE disk_id = ? AND band_id IN (?,?)",$disk_id,$Ks['band_id'],$W4['band_id']);
			if (count($mags)==2) {
				$total = 0;
				foreach ($mags as $m) {
					$magnitude = convert_to_mag($m['magnitude'],$m['uncertainty'],$m['units'],$m['band_id']);
					$total += (($m['band_id']==$W4['band_id'])?-1:1)*$magnitude['mag'];
				}
			} else {
				$total = NULL;
			}
			prepare_query("UPDATE disks SET KsMinusW4 = ? WHERE disk_id = ?",$total,$disk_id);
		}
	}
	
	function update_date() {
		$disk_id = $_POST['disk_id'];
		$number = $_POST['count'];
		if ($number > 0) {
			set_update("Changed photometry data for $number bands",$disk_id);
		}
	}
	
	$function = $_GET['function'];
	
	if (in_array($function,$valid_functions)) {
		$function();
	} else {
		echo "Invalid Call.";
	}
?>