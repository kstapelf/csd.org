<?php
	define("root","../../../disk_symlinks/");
	
	date_default_timezone_set("America/New_York");
	//get today's date
	$folder = "resd_disks_backup/";
	$name = date("Y-m-d  H:i:s").".db";
	$db_name = "resd_disks.db";
	
	//move to backup folder
	copy(root.$db_name,root.$folder.$name);
	
	echo "<li>".date("F j Y, g:i:s a",strtotime(basename($name,".db")))."</li>";

?>