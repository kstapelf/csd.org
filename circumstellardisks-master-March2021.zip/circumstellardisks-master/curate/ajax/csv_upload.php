<?php

	include "csv_upload_classes.php";
	session_start();
	
	define("root","../../");
	require "../../library.inc.php";
	require "../library.curate.php";
	
	
	$valid_functions = array("stage_1","confirm_band","confirm_ref","confirm_disk","cancel_upload","stage_2");

	function stage_1() {
		
		$file = $_FILES['upload'];
		
		if (!is_uploaded_file($file['tmp_name'])) {
			echo "Oops! There seems to be a problem with the upload.";
			return;
		}
		
		//Step 1: read file into rows
		ini_set('auto_detect_line_endings',TRUE);
		$file = fopen($file['tmp_name'],"r");
		
		$headers = fgetcsv($file);
		$needles = array("name","ra","dec","wavelength","measurement","uncertainty","flag","reference");
		$columns = array("name"=>"name",
							"ra"=>"ra_deg",
							"dec"=>"dec_deg",
							"wavelength"=>"wavelength",
							"measurement"=>"measurement",
							"uncertainty"=>"uncertainty",
							"flag"=>"units",
							"reference"=>"ref");
		
		//Searches given headers to determine columns
		foreach ($needles as $needle) {
			
			$result = array_filter($headers,function($i) use ($needle) { return (stripos($i,$needle) !== false); });
			//if more than 1 result, apply regex search (looks for needle as a complete word)
			if (count($result) > 1) {
				$result = array_filter($headers,function($i) use ($needle) { return (preg_match('/(^|\W)+'.$needle.'($|\W)+/i',$i) !== 1); });
			}
			
			$headers[key($result)] = $columns[$needle];
		}
		
		$rows = array();
		while (! feof($file)) {
			$row = fgetcsv($file);
			if (!empty($row)) {
				$obj = new stdClass;
				foreach ($row as $i=>$value) {
					$key = $headers[$i];
					$obj->$key = $value;
				}
				$rows[] = $obj;
			}
		}
		fclose($file);
			
		//Step 2: combine with itself based on RA/DEC given. Note References separately.
		$disks = array();
		$refs = array();
		$bands = array();
		
		foreach($rows as $row){
			$name = $row->name;		
			$ra = $row->ra_deg;
			$dec = $row->dec_deg;
				
			if ($ra && $dec) { //skip blank rows
			
				//lookup disk
				if (!$disks[$ra][$dec]) {
					$obj = new Disk($row->name, $row->ra_deg,$row->dec_deg);			
					$disks[$ra][$dec] = $obj;
				} else {
					$obj = $disks[$ra][$dec]; 	//passed via pointer
				}
				
				//lookup reference
				$url = $row->ref;
				if ($url != "") {
					if (!$refs[$url]) {
						$ref = new Reference($url);
						$refs[$url] = $ref;
					} else {
						$ref = $refs[$url];
					}
					$obj->refs[$url] = $ref;
				} else $ref = NULL;
				
				
				//lookup wavelength
				if (!$bands[$row->wavelength]) {
					$band = new Band($row->wavelength);
					$bands[$row->wavelength] = $band;
				} else {
					$band = $bands[$row->wavelength];
				}
				
				$units = "Mag";
				if ((stripos($row->units,"flux density")!==false)||(stripos($row->units,"jy")!==false)||(stripos($row->units,"jansk")!==false)) {
					$units = "Jy";
				} //***
				
				$measurement = array("band"=>$band,
									"measurement"=>$row->measurement,
									"uncertainty"=>$row->uncertainty,
									"units"=>$units);
				
				
				
				$obj->measurements[$band->wavelength] = array("measurement"=>$measurement,"ref"=>$ref);
				
				
			}
		}
		
		//re-index arrays
		$data = array();
		$refs = array_values($refs);
		$bands = array_values($bands);
		$disks = call_user_func_array("array_merge",array_map(array_values,array_values($disks)));
		
		include "csv_upload_display.php";
		
	}
	
	
	function confirm_band() {
		$band = $_SESSION['upload_data_bands'][$_POST['arrband']];
		
		//band was chosen from list
		if (isset($_POST['band_id'])) {
			$band->confirmed = $band->set_id($_POST['band_id']);
		} else if (isset($_POST['band'])) { //form was filled out
			$band->confirmed = $band->add_new($_POST['band'],$_POST['source']);
		} else $band->confirmed = true;
		
		if ($band->confirmed) {
			echo "Photometry band confirmed";
		} else {
			echo "Error! Try refreshing the page";
		}
	}
	
	function confirm_ref() {
		$ref = $_SESSION['upload_data_refs'][$_POST['arrref']];
		
		//ref was chosen from list
		if (isset($_POST['ref_id'])) {
			$ref->confirmed = $ref->set_id($_POST['ref_id']);
		} else if (isset($_POST['title'])) { //form was filled out
			$ref->confirmed = $ref->add_new($_POST['title'],$_POST['authors'],$_POST['date']);
		} else $ref->confirmed = true;
		
		if ($ref->confirmed) {
			echo "Reference confirmed";
		} else {
			echo "Error! Try refreshing the page";
		}
	}
	
	function confirm_disk() {
		$disk = $_SESSION['upload_data_disks'][$_POST['arrdisk']];
		
		$disk->confirmed = $disk->set_id($_POST['disk_id']);
		
		if ($disk->confirmed) {
			echo "Disk confirmed";
		} else {
			echo "Error! Try refreshing the page";
		}
	}
	
	function cancel_upload() {
		session_destroy();
	}
	
	function stage_2() {
		$results = array();
		$final_result = array("duplicate"=>0,"modified"=>0,"added"=>0,"skipped"=>0);
		
		foreach ($_SESSION['upload_data_disks'] as $disk) {
			$results[] = $disk->process();
		}
		
		//sum results
		foreach ($results as $r) {
			foreach ($r as $j=>$count) {
				$final_result[$j] += $count; 	
			}
		}
		//print summary
		echo "<h3>Upload Complete</h3>
		<ul>
        <li>".$final_result['added']." measurements added</li>
        <li>".$final_result['modified']." measurements modified</li>
        <li>".$final_result['duplicate']." duplicate measurements</li>
        <li>".$final_result['skipped']." measurements skipped</li>
        </ul>";
		session_destroy();
	}
	
	$function = $_GET['function'];
	
	if (in_array($function,$valid_functions)) {
		$function();
	} else {
		echo "Invalid Call.";
	}
?>