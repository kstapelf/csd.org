<?php
if (!isset($bands)) {
	$refs = $_SESSION['upload_data_refs'];
	$bands = $_SESSION['upload_data_bands'];
	$disks = $_SESSION['upload_data_disks'];
}
	$step = 1;
	
	
	if (count($bands) > 0) {
		echo "<div><h3>Step $step: Confirm Wavelengths</h3></div>";
		$step++;
		echo "<div class=\"container\" class=\"band\">";
		echo "<div class=\"header\"><span></span><span>Wavelength</span><span>Band</span><span>Source</span></div>";
		foreach ($bands as $key=>$band) {
			echo "<div class=\"alternate\" band>";
			
			if (!$band->confirmed) {
				$band->refresh();
				if (!($band->band_id < 0)) {
					echo "<label>Photometry band found</label>
							<label>".$band->wavelength."<i></i></label>
							<label>".$band->db_array['band']."</label>
							<label>".$band->db_array['source']."</label>
							<span><input value=\"Confirm\"";
				} else {
					echo "<label>Add new photometry band</label>
							<label>".$band->wavelength."<i></i></label>";
							show_field("band","text","Name",true);
							show_field("source","text","Source",true);
							echo "<span><input value=\"Add\"";
				}
				echo " type=\"button\"  onclick=\"confirm_band(this)\"></span><span><input type=\"button\" value=\"Choose\" onclick=\"choose_band(this)\"></span><span><input type=\"button\" value=\"Skip\" onclick=\"cancel_band(this)\"><input type=\"hidden\" name=\"arrband\" value=\"$key\"></span>";
			} else {
				echo "<label>Photometry band confirmed</label>
						<label>".$band->wavelength."<i> (".$band->db_array['wavelength'].")</i></label>
						<label>".$band->db_array['band']."</label>
						<label>".$band->db_array['source']."</label><span></span><span></span><span></span>";
			}
			
			echo "</div>";
		}
		echo "</div>";
	}
	
	
	if (count($refs) > 0) {
		echo "<div><h3>Step $step: Confirm References</h3></div>";
		$step++;
		echo "<div class=\"container\" class=\"ref\">";
		echo "<div class=\"header\"><span></span><span>Title</span><span>Authors</span><span>Date</span></div>";
		foreach ($refs as $key=>$ref) {
			echo "<div class=\"alternate\" ref='".$ref->url."'>";
			
			if (!$ref->confirmed) {
				$ref->refresh();
				if (!($ref->ref_id < 0)) {
					echo "<label>Reference found</label>
							<label><a href=\"".$ref->url."\">".$ref->db_array['title']."</a></label>
							<label>".$ref->db_array['authors']."</label>
							<label>".$ref->db_array['date']."</label>
							<span><input value=\"Confirm\"";
				} else {
					echo "<label><a href=\"".$ref->url."\">Add new reference</a></label>";
							show_field("title","text","Title",true);
							show_field("authors","textarea","Authors",true);
							show_field("date","date","",true);
							echo "<span><input value=\"Add\"";
				}
				echo " type=\"button\" onclick=\"confirm_ref(this)\"></span><span><input type=\"button\" value=\"Choose\" onclick=\"choose_ref(this)\"></span><span><input type=\"button\" value=\"Skip\" onclick=\"cancel_ref(this)\"><input type=\"hidden\" name=\"arrref\" value=\"$key\"></span>";
			} else {
				echo "<label>Reference confirmed</label>
						<label><a href=\"".$ref->db_array['url']."\">".$ref->db_array['title']."</a></i></label>
						<label>".$ref->db_array['authors']."</label>
						<label>".$ref->db_array['date']."</label><span></span><span></span><span></span>";
			}
			echo "</div>";
		}
		echo "</div>";
	}
	
	
	if (count($disks) > 0) {
		echo "<div><h3>Step $step: Confirm Disks</h3></div>";
		$step++;
		echo "<div class=\"container\" class=\"disk\">";
		echo "<div class=\"header\"><span></span><span>Object</span><span>RA</span><span>DEC</span></div>";
		
		$alternate = true;
		foreach ($disks as $key=>$disk) {
			
			
			if (!$disk->confirmed) {
				$disk->refresh();
				echo "<u class=\"manual-alternate$alternate\" disk arrdisk='$key'>";
				echo "<label>".count($disk->db_array)." disks matched to: </label>
					<label  name=\"name\">".$disk->name."</label>
					<label>".degrees_to_posistion($disk->ra_deg,"ra")." (<i name=\"ra\">".$disk->ra_deg."</i>)</label>
					<label>".degrees_to_posistion($disk->dec_deg,"dec")." (<i name=\"dec\">".$disk->dec_deg."</i>)</label>
					<span><input value=\"Add New\" type=\"button\" onclick=\"confirm_disk(this,$key,-1)\"></span><span><input type=\"button\" value=\"Choose Other\" onclick=\"choose_disk(this)\"></span><span><input type=\"button\" value=\"Skip\" onclick=\"cancel_disk(this)\"></span></u>";
				
				
				if (count($disk->db_array)) {
					foreach ($disk->db_array as $option) {
						echo "<div class=\"manual-alternate$alternate\" arrdisk=\"$key\">";
						echo "<label></label>
							<label>".$option['name'].($option['secondname']?" (".$option['secondname'].")":"")."</label>
							<label>".$option['ra']." <i>(".$option['ra_deg'].")</i></label>
							<label>".$option['dec']." <i>(".$option['dec_deg'].")</i></label>
							<span><input value=\"Confirm\" type=\"button\" onclick=\"confirm_disk(this,$key,".$option['disk_id'].")\"></span><span></span><span></span></div>";
					}
				}
				
				
			} else {
				echo "<div class=\"manual-alternate$alternate\" arrdisk='$key'>";
				echo "<label>Disk confirmed</label>
						<label>".$disk->db_array['name'].($disk->db_array['secondname']?" (".$disk->db_array['secondname'].")":"")."</label>
						<label>".$disk->db_array['ra']."</label>
						<label>".$disk->db_array['dec']."</label><span></span><span></span><span></span></div>";
			}
			$alternate = !$alternate;
		}
		echo "</div>";
	}
	
	$_SESSION['upload_data_refs'] = $refs;
	$_SESSION['upload_data_bands'] = $bands;
	$_SESSION['upload_data_disks'] = $disks;
	
	session_write_close();
	
	echo "<div><h3>Step $step: Process Measurements</h3></div>";
	?>
    
    <div style="text-align:center;margin:10px;">
    <input type="button" value="Confirm All Bands" onclick="confirm_all_bands()" extra />
    <input type="button" value="Confirm All References" onclick="confirm_all_refs()" extra />
    <input type="button" value="Confirm All Disks" onclick="confirm_all_disks()" extra /><br />
    <input type="button" value="Skip All Remaining" onclick="skip_all()" extra /><br />
    <input type="button" value="Process Upload" id="process" class="inactive" onclick="process_upload()" active="true" extra /></div>
	
<script type="text/javascript">
	activate_process();
</script>
