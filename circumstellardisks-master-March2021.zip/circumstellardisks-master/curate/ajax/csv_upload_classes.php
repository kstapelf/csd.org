<?php
	class Band {
		public $wavelength = 0;
		public $band_id = -1;
		public $db_array = array();
		public $confirmed = false;
		
		public function __construct($wavelength) {
			$this->wavelength = $wavelength;
    	}
		
		public function lookup() {
			$results = prepare_query("SELECT * FROM bands WHERE wavelength = ?",$this->wavelength);
			if (count($results) == 1) {
				$this->db_array = $results[0];
				$this->band_id = $this->db_array['band_id'];
			}
		}
		
		public function refresh() {
			if ($this->band_id<0) {
				$this->lookup();
			} else {
				$this->set_id($this->band_id);
			}
		}
		
		public function set_id($id) {
			$results = prepare_query("SELECT * FROM bands WHERE band_id = ?",$id);
			if (count($results) == 1) {
				$this->db_array = $results[0];
				$this->band_id = $id;
				return true;
			} else return false;
		}
		
		public function add_new($name,$source) {
			$rand = rand();
			prepare_query("INSERT INTO bands(band) VALUES(?)",$rand);
			extract(prepare_query1("SELECT band_id FROM bands WHERE band = ?",$rand));
			
			prepare_query("UPDATE bands SET band = ?, source = ?, wavelength = ? WHERE band_id = ?",
							clean_string($name), clean_string($source), clean_string($this->wavelength), $band_id);
			
			return $this->set_id($band_id);
		}
	}
	
	class Reference {
		public $url = "";
		public $ref_id = -1;
		public $db_array = array();
		public $confirmed = false;
		public $dr_id = -1;
		
		public function __construct($url) {
			$this->url = $url;
    	}
	
		public function lookup() {
			$results = prepare_query("SELECT * FROM refs WHERE url = ?",$this->url);
			if (count($results) == 1) {
				$this->db_array = $results[0];
				$this->ref_id = $this->db_array['ref_id'];
			}
		}
		
		public function refresh() {
			if ($this->ref_id<0) {
				$this->lookup();
			} else {
				$this->set_id($this->ref_id);
			}
		}
		
		public function set_id($id) {
			$results = prepare_query("SELECT * FROM refs WHERE ref_id = ?",$id);
			if (count($results) == 1) {
				$this->db_array = $results[0];
				$this->ref_id = $id;
				return true;
			} else return false;
		}
		
		public function add_new($title,$authors,$date) {
			$name = rand();
			prepare_query("INSERT INTO refs(title,authors,date,url) VALUES (?,?,?,?)",$name,'0','0','0');
			
			extract(prepare_query1("SELECT ref_id FROM refs WHERE title = ? AND url = ?",$name,'0'));
			
			prepare_query("UPDATE refs SET title = ?, authors = ?, date = ?, date_dec = ?, url = ? WHERE ref_id = ?",
						clean_string($title), clean_textarea(ucwords(strtolower($authors))), clean_string($date),date_to_dec($date), clean_string($this->url), $ref_id);
			
			return $this->set_id($ref_id);
		}
	}
	
	class Disk {
		public $disk_id = -1;
		public $db_array = array();
		public $confirmed = false;
		
		public $name;
		public $ra_deg;
		public $dec_deg;
		
		public $measurements = array();
		public $refs = array();
		
		public function __construct($name,$ra,$dec) {
			$this->name = $name;
			$this->ra_deg = $ra;
			$this->dec_deg = $dec;
    	}
		
		public function lookup() {	
			$this->disk_id = -1;
			
			$query = "SELECT * FROM disks WHERE ";
			$args = array();
			
			$arr = near($this->ra_deg,$this->dec_deg,0.003);
			
			if ($arr["query"]) {
				$query .= $arr["query"];
				$args = array_merge($args,$arr['args']);
			} else {
				$query .= " ra_deg = ? AND dec_deg = ?";
				$args[] = $this->ra_deg;
				$args[] = $this->dec_deg;
			}
			
			$query.= " OR name LIKE ? OR secondname LIKE ?";
			$args[] = clean_string($this->name);
			$args[] = "%".clean_string($this->name)."%";
			
			$query .= "ORDER BY (ra_deg - ?)*(ra_deg - ?)+(dec_deg - ?)*(dec_deg - ?) ASC";
			
			
			$results = call_user_func_array(prepare_query,array_merge(array($query),$args,array($this->ra_deg,$this->ra_deg,$this->dec_deg,$this->dec_deg)));
			$this->db_array = $results;
		}
		
		public function refresh() {
			if ($this->disk_id<0) {
				$this->lookup();
			} else {
				$this->set_id($this->disk_id);
			}
		}
		
		public function set_id($id) {
			if ($id < 0) return $this->add_new();
			
			$results = prepare_query("SELECT * FROM disks WHERE disk_id = ?",$id);
			if (count($results) == 1) {
				$this->db_array = $results[0];
				$this->disk_id = $id;
				return true;
			} else return false;
		}
		
		public function add_new() {
			$ra = degrees_to_posistion($this->ra_deg,"ra");
			$dec = degrees_to_posistion($this->dec_deg,"dec");
			$name = rand();
			$date = get_date("today");
			prepare_query("INSERT INTO disks(name,status,date,ra,dec) VALUES (?,?,?,?,?)",$name,"0",$date,$ra,$dec);
			
			extract(prepare_query1("SELECT disk_id FROM disks WHERE name = ? AND ra = ? AND dec = ?",$name,$ra,$dec));
			
			prepare_query("UPDATE disks SET name = ?, ra_deg = ?, dec_deg = ?, date_dec = ? WHERE disk_id = ?",
						$this->name,$this->ra_deg,$this->dec_deg,datetime_to_dec($date),$disk_id);
			
			set_update("Disk ".clean_string($this->name)." added",$disk_id);
			
			return $this->set_id($disk_id);
		}
		
		public function process() {
			$result = array("duplicate"=>0,"modified"=>0,"added"=>0,"skipped"=>0);
			$new_refs = 0;
			if ($this->confirmed) {
				if (count($this->refs)) {
					$db_query = prepare_query("SELECT ref_id FROM disk_refs WHERE disk_id = ?",$this->disk_id);
					$curr_refs = array();
					foreach ($db_query as $r) {
						$curr_refs[] = $r['ref_id'];
					}
					foreach ($this->refs as $ref) {
						if ($ref->confirmed) { 
							if (array_search($ref->ref_id,$curr_refs)===false) {
								prepare_query("INSERT INTO disk_refs(disk_id,ref_id) VALUES (?,?)",$this->disk_id,$ref->ref_id);
								$curr_refs[] = $ref->ref_id;
								$new_refs +=1;
							}
							$dr = prepare_query1("SELECT dr_id FROM disk_refs WHERE disk_id = ? AND ref_id = ? LIMIT 1",$this->disk_id,$ref->ref_id);
							$ref->dr_id = $dr['dr_id'];
						}
						
					}
				}
				
				
				foreach ($this->measurements as $arr) {
					$measurement = $arr['measurement'];
					if ($measurement['band']->confirmed) {
						$db_query = prepare_query1("SELECT * FROM disk_bands WHERE disk_id = ? AND band_id = ?",
														$this->disk_id,$measurement['band']->band_id);
						if ($db_query) { //if already in, update
							//compare
							if (($measurement['measurement']==$db_query['magnitude']) && 
								($measurement['uncertainty']==$db_query['uncertainty']) && 
								($measurement['units']==$db_query['units'])) {
									$result["duplicate"] += 1;
							} else {
								prepare_query("UPDATE disk_bands SET magnitude = ?, uncertainty = ?, units = ? WHERE db_id = ?",
											$measurement['measurement'],$measurement['uncertainty'],$measurement['units'],$db_query['db_id']);
								$result["modified"] += 1;
							}
						} else {
							//add
							prepare_query("INSERT INTO disk_bands(disk_id,band_id,magnitude, uncertainty, units) VALUES (?,?,?,?,?)",
											$this->disk_id, $measurement['band']->band_id,
											$measurement['measurement'],$measurement['uncertainty'],$measurement['units']);
							$result["added"] += 1;
							$db_query = prepare_query1("SELECT * FROM disk_bands WHERE disk_id = ? AND band_id = ?",
														$this->disk_id,$measurement['band']->band_id);
						}
						
						$ref = $arr['ref'];
						if ($ref && $ref->confirmed) {
							prepare_query("UPDATE disk_bands SET dr_id = ? WHERE db_id = ?",$ref->dr_id,$db_query['db_id']);
						}
					} else $result["skipped"] += 1;
				}
				
				
				if ($new_refs > 0) {
					set_update("Disk linked to ".$new_refs." references during upload.",$this->disk_id);
				}
				
				if (($result['added']+ $result['modified']) > 0) {
					set_update("Changed photometry data for ".($result['added']+$result['modified'])." bands during upload.",
										$this->disk_id);
				}
			}
			return $result;
		}
	}
?>