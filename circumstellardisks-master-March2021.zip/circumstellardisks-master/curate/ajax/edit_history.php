<?php
	define("root","../../");
	require "../../library.inc.php";
	
	$valid_functions = array("view","add");

	function view() {
		$query = "SELECT d.name, e.date, e.change FROM 
					edits AS e LEFT JOIN disks AS d ON d.disk_id = e.disk_id
					INNER JOIN (SELECT disk_id, MAX(date_dec) AS max FROM edits GROUP BY disk_id) AS sort ON sort.disk_id = e.disk_id";
		$order = " ORDER BY sort.max DESC, e.date_dec DESC";
		if ($_POST['timescale']=="all") {
			$results = query($query.$order);
		} else {
			if ($_POST['timescale']=="all_new") {
				$query .= " WHERE e.display = ?";
				$arg = 0;
			} else {
				$query .= " WHERE e.date_dec >= ?";
				$arg = date_to_dec(get_date("today","Y-m-d"));
				switch ($_POST['timescale']) {
					case "3days":
						$arg-= 3/365;
						break;
					case "week":
						$arg-= 7/365;
						break;
					case "month":
						$arg-= 31/365;
						break;
					case "6month":
						$arg-= 0.5;
						break;
					case "year":
						$arg-= 1;
						break;
				}
			}
			$results = prepare_query($query.$order,$arg);
		}
		
		$disk = "";
		$date = "";
		foreach ($results as $edit) {
			if ($edit['name'] != $disk) {
				$disk = $edit['name'];
				$date = "";
				echo "<span class=\"name\">".$disk."</span>";
			}
			if (substr($edit['date'],0,10) != $date) {
				$date = substr($edit['date'],0,10);
				echo "<span class=\"date\">".get_date($date,"M d, 'y")."</span>";
			}
			echo "<span class=\"change\">".$edit['change']."</span>";
		}
	}
	
	function add() {
		$filepath = root."../disk_symlinks/whatsnew.xml";
		$xml = load_xml($filepath);
		
		$entry = $xml->addChild("entry");
		$entry->addChild("date",get_date("today"));
		$entry->addChild("title",clean_string(clean_string($_POST['title'])));
		$entry->addChild("content",clean_string(clean_string($_POST['content'])));
		
		display_xml($entry);
		save_xml($xml,$filepath);
		prepare_query("UPDATE edits SET display = 1 WHERE display = 0");
	}
	
	$function = $_GET['function'];
	
	if (in_array($function,$valid_functions)) {
		$function();
	} else {
		echo "Invalid Call.";
	}
?>