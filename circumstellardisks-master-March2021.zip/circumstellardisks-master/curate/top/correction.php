<?php
	define("root","../../");
	require "../../library.inc.php";
	require "../library.curate.php";
	
	/*Correction needed between 3.2 and 3.3*/
	$arr = prepare_query_no_err("SELECT units from disk_bands"); 
	if (!$arr) {
		echo "<p>Correction between v3.2 and v3.3: fixes coordinate calculation for RA/DEC, changes some display settings, and adds units column to photometry data</p>";
		$disks = query("SELECT disk_id, ra, dec FROM disks");
		
		$stmt = prepare_multiquery("UPDATE disks SET ra_deg = ?, dec_deg = ? WHERE disk_id = ?");
		
		foreach ($disks as $disk) {
			$ra_deg = position_to_degrees($disk['ra']);
			$dec_deg = position_to_degrees($disk['dec']);
			execute_multiquery($stmt,$ra_deg,$dec_deg,$disk['disk_id']);
		}
		
		//fix columns table
		prepare_query("DELETE FROM disk_cols WHERE col = ? OR col = ?","ra_deg","dec_deg");
		
		prepare_query("UPDATE disk_cols SET col = ?, display = ? WHERE col = ?","date_update","Date Updated","date_dec");
		
		
		//add units to disk_bands table
		prepare_query("ALTER TABLE disk_bands ADD COLUMN units text");
	}
	//*/
	
	/*Correction needed between 3.3 and 4.0*/
	//if this throws an error, code has not already been run
	$arr = prepare_query_no_err("SELECT order_default from disk_cols WHERE col=?",'name');
	
	if (!$arr) {
		echo "<p>Correction between v3.3 and v4.0: Sets default display order of front page and object information tables</p>";
		query("ALTER TABLE disk_cols ADD COLUMN order_default int");
		query("ALTER TABLE disk_cols ADD COLUMN order_refuted int");
		query("ALTER TABLE disk_cols ADD COLUMN order_candidate int");
		query("ALTER TABLE disk_cols ADD COLUMN order_resolved int");
		
		//grab all, set to current order
		$cols = prepare_query("SELECT col FROM disk_cols");
		$stmt = prepare_multiquery("UPDATE disk_cols SET order_default = ?, order_refuted = ?, order_candidate = ?, order_resolved= ? WHERE col = ?");
		
		$order = array("name"=>array(0,1,1,1),
						"secondname"=>array(0,-1,2,-1),
						"status"=>array(-5,-5,-5,-5),
						"ra"=>array(1,-1,-1,-1),
						"dec"=>array(2,-1,-1,-1),
						"spty"=>array(4,3,5,3),
						"sfr"=>array(-1,-1,3,-1),
						"category"=>array(3,2,4,2),
						"class"=>array(-1,-1,-1,-1),
						"rmag"=>array(5,4,-1,4),
						"dist"=>array(6,5,6,5),
						"majorextent"=>array(7,6,-1,6),
						"minorextent"=>array(-1,-1,-1,-1),
						"size_au"=>array(8,7,-1,7),
						"incl"=>array(9,8,-1,8),
						"padisk"=>array(10,-1,-1,-1),
						"dmirror"=>array(-5,-5,-5,-5),
						"wavelength"=>array(13,10,-1,10),
						"spatial_res"=>array(-1,-1,-1,-1),
						"major_res"=>array(12,9,-1,9),
						"date"=>array(-1,-1,-1,-1),
						"date_update"=>array(-1,-1,-1,-1),
						"ref"=>array(11,-5,-5,-5),
						"note"=>array(-5,-5,-5,-5),
						"fil"=>array(-1,-1,-1,-1),
						"xray"=>array(-1,-1,-1,-1),
						"variable"=>array(-1,-1,-1,-1),
						"KsMinusW4"=>array(-1,-5,7,-5),
						"whalpha"=>array(-1,-1,-1,-1));
		
		foreach ($cols as $c) {
			execute_multiquery($stmt,$order[$c['col']][0],$order[$c['col']][1],$order[$c['col']][2],$order[$c['col']][3],$c['col']);
		}
		
	}//*/
	
	/*Correction needed between 4.0 and 4.1*/
	$arr = prepare_query_no_err("SELECT dr_id from disk_bands");
	
	if (!$arr) {
		echo "<p>Correction between v4.0 and v4.1: Creates announcement file (../disk_symlinks/whatsnew.xml), adds references to photometry measurements, and changes category 'MS' to category 'Debris'</p>";
	
		query("ALTER TABLE disk_bands ADD COLUMN dr_id int REFERENCES disk_refs (dr_id)");
		
		$file_name = root."../disk_symlinks/whatsnew.xml";
		$handle = fopen($file_name, 'w') or die('Cannot open file:  '.$file_name); //implicitly creates file
		$content = '<?xml version="1.0" encoding="UTF-8"?>'.PHP_EOL.'<all></all>';
		fwrite($handle,$content);
		fclose($handle);
		
		prepare_query("UPDATE disks SET category = ? WHERE category = ?","Debris","MS");
	}
	//*/
	
	/*Correction needed to hide column*/
	prepare_query("UPDATE disk_cols SET order_default = ?, order_refuted = ?, order_candidate = ?, order_resolved= ? WHERE col = ?",
						-5,-5,-5,-5,'dmirror');
	echo "All corrections complete";
?>