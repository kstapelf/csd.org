<?php
exit();


define("root","../../");

date_default_timezone_set("America/New_York");

//add backup folder
mkdir(root."../resd_disks_backup");

$converted = root."../new.db";
$old = root."../resd_disks.db";



function position_to_degrees($position) {
	//follows pattern of +dd dd dd.dd
		//1. optional +/-
		//2. (2 digits followed by a space) times 2
		//3. 2 digits, followed optionally by a . and then more digits
	if (preg_match('/^[+\-]?(\d{2} ){2}\d{2}(\.\d+)?$/',$position)) {
		$split = explode(" ",$position);
		$m1 = 15;
		$m2 = 1;
		if ($position[0]=='-' || $position[0]=='+') {
			$m1 = 1;
			if ($position[0]=='-') $m2 = -1;
		}
		
		return $m1*$m2*($m2*floatval($split[0])+floatval($split[1])/60+floatval($split[2])/3600);
	} else if (is_numeric($position)) {
		return $position;
	} else {
		return NULL;
	}	
}

function date_to_dec($date) {
	$datetime = strtotime($date);
	
	if (is_numeric($date)) {
		return $date;
	} else if ($datetime) {
		$year = date("Y",$datetime);
		$month = date("m",$datetime);
		$day = date("d",$datetime);
		return ($year + ($month-1)/12 + ($day-1)/(12*31));
	} else return NULL;
}


try {
	$old_db = new PDO("sqlite:".$old);
	$new_db = new PDO("sqlite:".$converted);
	} catch (PDOException $e) {
		echo "Failed to get DB handle: " . $e->getMessage() . "\n";
		exit;
}
	
function prepare_query(){
	$arg_list = func_get_args();
	
	$dbh = $arg_list[0];
	$query = $arg_list[1];
	
	$stmt = $dbh->prepare($query);
	if (!$stmt) {
		echo "\nPDO::errorInfo():\n";
		print_r($dbh->errorInfo());
		return false;
	} else {
		$stmt->execute(array_slice($arg_list,2));
		$result = $stmt->fetchAll();
		return $result;
	}
}

function query($dbh,$query) {
	
	$result = array();
	foreach ($dbh->query($query) as $row) {
		$result[] = $row;
	}
	
	$err = $dbh->errorInfo();
	if ($err[0]!="00000") echo $err[2];
	return $result;
}

function prepare_query1() {
	$result = call_user_func_array(prepare_query,func_get_args());
	if ($result) return $result[0];
	else return array();
}

function query1($dbh,$query) {
	$result = query($query);
	if ($result) return $result[0];
	else return array();
}


function prepare_statement($dbh,$query) {
	$stmt = $dbh->prepare($query);
	if (!$stmt) {
		echo "\nPDO::errorInfo():\n";
		print_r($dbh->errorInfo());
		return false;
	} else {
		return $stmt;
	}
}

function execute() {
	$arg_list = func_get_args();
	
	$stmt = $arg_list[0];
	
	$stmt->execute(array_slice($arg_list,1));
	$result = $stmt->fetchAll();
	return $result;
}

//Step 1: Set up tables in new file
$tables = array();

$tables[] = "CREATE TABLE IF NOT EXISTS disks (
				disk_id INTEGER PRIMARY KEY AUTOINCREMENT,
				name text NOT NULL,
				secondname text DEFAULT '',
				status int DEFAULT 0,
				class text DEFAULT '',
				ra text DEFAULT '',
				dec text DEFAULT '',
				ra_deg real DEFAULT '',
				dec_deg real DEFAULT '',
				majorextent int DEFAULT '',
				minorextent int DEFAULT '',
				wavelength int DEFAULT '',
				dmirror int DEFAULT '',
				spatial_res int DEFAULT '',
				major_res int DEFAULT '',
				spty text DEFAULT '',
				category text DEFAULT '',
				dist int DEFAULT '',
				size_au int DEFAULT '',
				incl int DEFAULT '',
				padisk int DEFAULT '',
				note blob DEFAULT '',
				date text NOT NULL,
				date_dec int DEFAULT 1970.00,
				date_update text DEFAULT '',
				date_update_dec int DEFAULT 1970.00,
				rmag int DEFAULT '',
				sfr text DEFAULT '',
				KsMinusW4 real DEFAULT '',
				fil real DEFAULT '',
				xray int DEFAULT 0,
				variable int DEFAULT 0,
				whalpha text DEFAULT '',
				ref text DEFAULT ''
				);";

$tables[] = "CREATE TABLE IF NOT EXISTS disk_cols (
				col text,
				display text,
				type text,
				required int DEFAULT 0
				);";

$tables[] = "CREATE TABLE IF NOT EXISTS edits (
				date text NOT NULL, 
				date_dec real,
				disk_id int,
				change text, 
				display int DEFAULT 1
				);";
				
$tables[] = "CREATE TABLE IF NOT EXISTS refs (
				ref_id INTEGER PRIMARY KEY AUTOINCREMENT,
				title text NOT NULL, 
				authors text NOT NULL,
				date text NOT NULL,
				
				date_dec ,
				url text NOT NULL
				);";

$tables[] = "CREATE TABLE IF NOT EXISTS disk_refs (
				dr_id INTEGER PRIMARY KEY AUTOINCREMENT,
				disk_id int NOT NULL,
				ref_id int NOT NULL,
				description text DEFAULT NULL,
				photo text DEFAULT NULL,
				img_alt text DEFAULT NULL,
				main int DEFAULT 0,
				FOREIGN KEY(disk_id) REFERENCES disks (disk_id),
				FOREIGN KEY(ref_id) REFERENCES refs (ref_id)
				);";

$tables[] = "CREATE TABLE IF NOT EXISTS bands (
				band_id INTEGER PRIMARY KEY AUTOINCREMENT,
				band text NOT NULL, 
				source text,
				wavelength real,
				units text DEFAULT 'Mag',
				fdefault real DEFAULT 1
				);";

$tables[] = "CREATE TABLE IF NOT EXISTS disk_bands (
				db_id INTEGER PRIMARY KEY AUTOINCREMENT,
				band_id int NOT NULL,
				disk_id int NOT NULL, 
				magnitude real,
				uncertainty real,
				FOREIGN KEY(band_id) REFERENCES bands (band_id),
				FOREIGN KEY(disk_id) REFERENCES disks (disk_id)
				);";


foreach ($tables as $t) {
	echo nl2br($t)."<br/><br/>";
	query($new_db,$t);
}

//populate measurements table


$bands = array(array("Tycho B",		"Hipparcos B",		0.430,	"Mag",	4130),
				array("Tycho V",	"Hipparcos V",		0.530,	"Mag",	3781),
				array("J",			"2MASS",			1.235,	"Mag",	1594),
				array("H",			"2MASS",			1.662,	"Mag",	1024),
				array("Ks",			"2MASS",			2.159,	"Mag",	666.7),
				array("IRAC1",		"Spitzer/IRAC",		3.6,	"Jy",	280.9),
				array("IRAC2",		"Spitzer/IRAC",		4.5,	"Jy",	179.7),
				array("IRAC3",		"Spitzer/IRAC",		5.7,	"Jy",	115),
				array("IRAC4",		"Spitzer/IRAC",		8.0,	"Jy",	64.1),
				array("W1",			"WISE",				3.4,	"Mag",	309.54),
				array("W2",			"WISE",				4.6,	"Mag",	171.787),
				array("W3",			"WISE",				12,		"Mag",	31.674),
				array("W4",			"WISE",				22,		"Mag",	8.363),
				array("MIPS1",		"Spitzer/MIPS",		23.8,	"Jy",	7.17),
				array("MIPS2",		"Spitzer/MIPS",		71.4,	"Jy",	0.78),
				array("MIPS3",		"Spitzer/MIPS",		156,	"Jy",	0.16),
				array("PACS1",		"Herschel/PACS",	70,		"Jy",	1),
				array("PACS2",		"Herschel/PACS",	100,	"Jy",	1),
				array("PACS3",		"Herschel/PACS",	160,	"Jy",	1),
				array("1.3mm",		"",					1300,	"Jy",	1),
				array("u",			"SDSS",				0.3551,	"Mag",	1),
				array("g",			"SDSS",				0.4686,	"Mag",	1),
				array("r",			"SDSS",				0.6165,	"Mag",	1),
				array("i",			"SDSS",				0.7481,	"Mag",	1),
				array("z",			"SDSS",				0.8931,	"Mag",	1)
				);


$cols = array(array("name",			"Object",						"text",			1),
				array("secondname",	"Secondary Name",				"text",			0),
				array("status",		"Status",						"status",		1),
				array("ra",			"RA (J2000)",					"text",			1),
				array("dec",		"DEC (J2000)",					"text",			1),
				array("ra_deg",		"RA (J2000)",					"calculate",	0),
				array("dec_deg",	"DEC (J2000)",					"calculate",	0),
				array("spty",		"SpTy",							"text",			0),
				array("sfr",		"Star-Forming Region",			"text",			0),
				array("category",	"Category",						"text",			0),
				array("class",		"Class",						"text",			0),
				array("rmag",		"R band (mag)",					"number",		0),
				array("dist",		"Distance (pc)",				"number",		0),
				array("majorextent","Disk Diameter (Major)(\")",	"number",		0),
				array("minorextent","Disk Diameter (Minor)(\")",	"number",		0),
				array("size_au",	"Disk Diameter (AU)",			"calculate",	0),
				array("incl",		"Inclination",					"number",		0),
				array("padisk",		"PADisk",						"number",		0),
				array("dmirror",	"Mirror Diameter",				"number",		0),
				array("wavelength",	"At ref. wavelength (micron)",	"number",		0),
				array("spatial_res","Spatial Resolution",			"number",		0),
				array("major_res",	"Major Resolution",				"calculate",	0),
				array("date",		"Date Added",					"date",			0),
				array("date_dec",	"Date Added",					"calculate",	0),
				array("ref",		"Reference",					"textarea",		0),
				array("note",		"Note",							"textarea",		0),
				array("fil",		"Fractional Infrared Luminosity","number",		0),
				array("xray",		"XRay Bright",					"boolean",		0),
				array("variable",	"Variable Star",				"boolean",		0),
				array("KsMinusW4",	"Ks - W4",						"calculate",	0),
				array("whalpha",	"Halpha equivalent width",		"number",		0)
				);


$stmt = prepare_statement($new_db,"INSERT INTO bands (band,source,wavelength,units,fdefault) VALUES (?,?,?,?,?)"); //***
if ($stmt) foreach ($bands as $entry) {
	call_user_func_array(execute,array_merge(array($stmt),$entry));
}

$stmt = prepare_statement($new_db,"INSERT INTO disk_cols (col,display,type,required) VALUES (?,?,?,?)");
if ($stmt) foreach ($cols as $entry) {
	call_user_func_array(execute,array_merge(array($stmt),$entry));
}

//copy disks table
$disks = query($old_db,"SELECT rowid, * FROM disks");
$disk_cols = array("name","secondname","status","class","ra","dec","majorextent","minorextent","wavelength",
					"dmirror","spatial_res","major_res","spty","category","dist","size_au","incl","padisk",
					"note","date","rmag","sfr","KsMinusW4","fil","xray","variable","whalpha","ref");

$today = date("Y-m-d");
$today_dec =  date_to_dec($today);

function mapper($key) {
	global $old_disk;
	return trim($old_disk[$key]);
}

foreach ($disks as $old_disk) {
	//copy entry
	$query = "INSERT INTO disks (".implode(",",$disk_cols).") VALUES (".rtrim(str_repeat("?,",count($disk_cols)),",").")";
	call_user_func_array(prepare_query,array_merge(array($new_db,$query),array_map(mapper,$disk_cols)));
	
	$new_disk = prepare_query1($new_db,"SELECT * FROM disks WHERE name = ?",$old_disk['name']);
	
	//add ra_deg and dec_deg columns
	prepare_query($new_db,"UPDATE disks SET ra_deg = ?, dec_deg = ? WHERE disk_id = ?",
				position_to_degrees(trim($new_disk['ra'])),position_to_degrees(trim($new_disk['dec'])),$new_disk['disk_id']);
	
	//add date_dec column
	prepare_query($new_db,"UPDATE disks SET date_dec = ? WHERE disk_id = ?",
				date_to_dec(trim($new_disk['date'])),$new_disk['disk_id']);
	
	//add columns for last update
	prepare_query($new_db,"UPDATE disks SET date_update = ?, date_update_dec = ? WHERE disk_id = ?",
				$today,$today_dec,$new_disk['disk_id']);
	prepare_query($new_db,"INSERT INTO edits(date, date_dec, disk_id, change, display) VALUES (?,?,?,?,?)",
						$today,$today_dec,$new_disk['disk_id'],"Shifted over to website version 3.0",0);
	
	//grab references
	$references = prepare_query($old_db,"SELECT * FROM ref WHERE disk = ?",$old_disk['rowid']);
	
	foreach ($references as $old_ref) {
		//check to see if url/link already exists
		$new_ref = prepare_query1($new_db,"SELECT ref_id FROM refs WHERE url = ?",$old_ref['link']);
		if (!count($new_ref)) { //if not, create it
			prepare_query($new_db,"INSERT INTO refs(title, authors, date, date_dec, url) VALUES (?,?,?,?,?)",
									ltrim($old_ref['title']," \t"),$old_ref['authors'],$old_ref['date'],date_to_dec($old_ref['date']),$old_ref['link']);
			$new_ref = prepare_query1($new_db,"SELECT ref_id FROM refs WHERE url = ?",$old_ref['link']);
		}
		//add to disk_references
		prepare_query($new_db,"INSERT INTO disk_refs(disk_id, ref_id, description, photo, img_alt) VALUES (?,?,?,?,?)",
						$new_disk['disk_id'],$new_ref['ref_id'],$old_ref['description'],$old_ref['photo'],$old_ref['img_alt']);
	}
}
?>