<?php 
if (!defined('root')) {
	define('root',"../");
}

require_once root."library.inc.php";

if (!isset($disk_id)) {
	$disk_id = $_GET['id'];
}
if (!isset($disk)) {
	$disk = prepare_query1("SELECT * FROM disks WHERE disk_id = ?",$disk_id);
}


$ref = get_all_disk_references($disk_id);

if ($disk) {
	$query_str = "SELECT photo, ref_id FROM disk_refs
				WHERE photo NOT LIKE '' AND photo NOT NULL AND disk_id = ? ORDER BY RANDOM() LIMIT 15";
	$pictures = prepare_query($query_str,$disk_id);
	if ($pictures) {
		echo "<hr class=\"clear\" style=\"border:none;margin-bottom:3px;\" /><div id=\"imgbox\">";
			foreach ($pictures as $pic) {
				echo "<a href=\"#refid".$pic['ref_id']."\" target=\"_self\"><img src=\"".root.'imgs/'.$pic['photo']."\" /></a>";
			}
		echo "</div><hr class=\"clear\" />";
	}
	
	
	$cols = query("SELECT * FROM disk_cols WHERE order_default > 0 ORDER BY order_default");
	
	$countref = count($ref);
	
	echo '<table class="display-disk">';
	
	echo '<tr>';
	
		foreach ($cols as $c) {
			if (!$disk[$c['col']]=='') echo '<th><div class="turn">'.$c['display'].'</div></th>';
		}
	
		echo '<th><div class="turn"># References</div></th>';
	echo '</tr>';
	
	echo '<tr>';
	
		foreach ($cols as $c) {
			if (!$disk[$c['col']]=='') echo '<td>'.display_string($disk[$c['col']]).'</td>';
		}
		echo '<td>'.$countref.'</td>';
	echo '</tr>';
	
	echo '</table>';
	
	echo "<div style='text-align:right;padding:10px 20px;'>";
	if (count(prepare_query("SELECT * FROM disk_bands WHERE disk_id = ?",$disk_id)) > 0) {
		echo "<a href='".root."show/viewmag.php?id=$disk_id' ".(root==""?"target='_self'":"").">View Photometry Data</a>";
	} else echo "&nbsp;";
	
	echo '</div>';
	
	if (!$disk['note']=='') {
		echo '<div class="section">
				<h3>Notes:</h3>
				<p>'.display_textarea($disk['note']).'</p>
				</div>';
	}
	?>
	
	<div class="section"><h3>References:</h3></div>
	
	<?php
    foreach ($ref as $reference) {
		display_ref($reference['dr_id'],root);
	}

} else echo 'No results found.';
?>