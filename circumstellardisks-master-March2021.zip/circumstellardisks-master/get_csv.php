<?php
require "library.inc.php";

header("Content-type: text/csv");
header("Content-Disposition: attachment; filename=circumstellardisks.csv");
header("Pragma: no-cache");
header("Expires: 0");

$cols_tag = $_GET['columns'];
$disk_ids = $_GET['disks'];

//Check that all columns are good
$verified_cols = array_filter($cols_tag,"check_disk_col");

$disks_unordered = call_user_func_array(prepare_query,array_merge(array("SELECT * FROM disks WHERE disk_id IN (".trim(str_repeat("?,",count($disk_ids)),",").")"),$disk_ids));

//index $disks by ids
$disks = array();
foreach ($disks_unordered as $d) {
	$disks[$d['disk_id']] = $d;
}
unset($disks_unordered);

//Start outputting csv file

$last_update = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1");

$edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1");
//
echo "\"Circumstellar Disks http://www.circumstellardisks.org/\"".PHP_EOL;
echo "\"Downloaded on ".date("M. d Y")."\"".PHP_EOL;
echo "\"Database maintained by Karl Stapelfeldt. Last updated ".date("M. d Y",strtotime($edit['date']))."\"".PHP_EOL;

$outstream = fopen("php://output", 'w');

$all_cols = prepare_query("SELECT col, display FROM disk_cols");
$col_names = array();
foreach ($all_cols as $c) {
	$col_names[$c['col']] = $c['display'];
}

fputcsv($outstream,array_map(function($c) use ($col_names) { return $col_names[$c]; },$verified_cols), ',', '"');

foreach($disk_ids as $d_id) {
	$disk = $disks[$d_id];
	fputcsv($outstream,array_map(function($c) use ($disk) { return $disk[$c]; },$verified_cols), ',', '"');
}

fclose($outstream);

exit();
?>