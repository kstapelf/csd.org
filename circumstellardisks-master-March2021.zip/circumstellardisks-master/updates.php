<?php
header("Cache-Control: no-store");
header("Pragma: no-cache");
header("Content-Security-Policy: default-src 'self';style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline';");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/default.dwt.php" codeOutsideHTMLIsLocked="false" -->
<!-- InstanceBeginEditable name="initialize" -->
<?php

	define("root","");
	require root."library.inc.php";

?>
<!-- InstanceEndEditable -->

<?php 
	//new is 2 months ago
	$sixmonths = date("Y-m-d",time()-(2*30*24*60*60));
	
?>


<head>
<!--Code written by Isabelle Jansen. Written for http://www.circumstellardisks.org/. Copyright 2016.-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- InstanceBeginEditable name="Keywords" --><meta name="keywords" content=""><!-- InstanceEndEditable -->
<base target="_blank">

<link rel="stylesheet" type="text/css" href="layout/main.css" />
<link rel="stylesheet" type="text/css" href="layout/mobile.css" />
<script type="text/javascript" src="ajax/jquery-3.5.1.min.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Catalog of Circumstellar Disks | What's New</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<style type="text/css"></style>
<script type="text/javascript">
</script>
<!-- InstanceEndEditable -->
</head>

<body>

<div id="navbar" class="container">
<div>
<a class="col-2" href="index.php" target="_self">Home
</a><a class="col-2" href="search.php" target="_self">Search
</a><a class="col-2" href="updates.php" target="_self">What's New
</a><a class="col-2" href="<?php echo root; ?>description.php" target="_self">Catalog Description
</a><span class="col-2 hover">Catalogs
<span><a href="index.php?catalog=resolved" target="_self">Resolved Disks</a><a href="index.php?catalog=candidate" target="_self">Unresolved Disks</a><a href="index.php?catalog=refuted" target="_self">Refuted Disks</a></span></span>
</a><a class="col-2" href="contribute.php">Contribute
</a></div></div>


<div id="banner"><div class="pagetitle" ><div><span><img src="layout/imgs/pagetitle.png" alt="Catelog of Circumstellar Disks" /></span></div></div><img src="layout/imgs/banner.png" class="banner"  /></div>

<div id="content" class="col-12">
<h1><!-- InstanceBeginEditable name="pagetitle" -->
What's New
<!-- InstanceEndEditable --></h1><hr />

<!-- InstanceBeginEditable name="tabbar" -->
<!-- InstanceEndEditable -->


<!-- InstanceBeginEditable name="content" -->

<div class="section">
<?php

$filepath = root."../disk_symlinks/whatsnew.xml";
$xml = load_xml($filepath);

$entries = $xml->entry;
$len = count($entries);
for ($i=$len-1; $i>=0; $i--) {
	$entry = $entries[$i];
	display_xml($entry);
	
	if ($entry->date < $sixmonths) break;
}

?>
</div>
<!-- InstanceEndEditable -->
<br />
<div id="footer">Created by Caer McCabe. Redesigned by Isabelle H. Jansen. Maintained by <a href="mailto:Karl.R.Stapelfeldt at jpl.nasa.gov">Karl Stapelfeldt</a>. Last updated <?php 
if (isset($disk_id)) $edit = prepare_query1("SELECT date FROM edits WHERE disk_id = ? ORDER BY date_dec DESC LIMIT 1",$disk_id); 
else $edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1"); 

echo date("F j, Y",strtotime($edit['date'])); ?>.</div>
</div>

</body>
<!-- InstanceEnd --></html>
