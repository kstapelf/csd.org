<?php
header("Cache-Control: no-store");
header("Pragma: no-cache");
header("Content-Security-Policy: default-src 'self';style-src 'self' 'unsafe-inline';");
header("X-Content-Type-Options: nosniff");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/default.dwt.php" codeOutsideHTMLIsLocked="false" -->
<!-- InstanceBeginEditable name="initialize" -->
<?php

	define("root","");
	require "library.inc.php";
	$disk_id = $_GET['id'];
	
	$disk = prepare_query1("SELECT * FROM disks WHERE disk_id=?",$disk_id);
	if (!$disk) {
		echo "No results found.";
	} else {
		$name = display_string($disk['name']);
	}

?>
<!-- InstanceEndEditable -->

<?php 
	//new is 2 months ago
	$sixmonths = date("Y-m-d",time()-(2*30*24*60*60));
	
?>


<head>
<!--Code written by Isabelle Jansen. Written for http://www.circumstellardisks.org/. Copyright 2016.-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- InstanceBeginEditable name="Keywords" --><meta name="keywords" content="<?php echo $name;?>"><meta name="description" content="Disk details and list of references for circumstellar disk <?php echo $name;?>"><!-- InstanceEndEditable -->
<base target="_blank">

<link rel="stylesheet" type="text/css" href="layout/main.css" />
<link rel="stylesheet" type="text/css" href="layout/mobile.css" />
<script type="text/javascript" src="ajax/jquery-3.5.1.min.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Catalog of Circumstellar Disks | <?php echo $name; ?></title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<style type="text/css"></style>
<!-- InstanceEndEditable -->
</head>

<body>

<div id="navbar" class="container">
<div>
<a class="col-2" href="index.php" target="_self">Home
</a><a class="col-2" href="search.php" target="_self">Search
</a><a class="col-2" href="updates.php" target="_self">What's New
</a><a class="col-2" href="<?php echo root; ?>description.php" target="_self">Catalog Description
</a><span class="col-2 hover">Catalogs
<span><a href="index.php?catalog=resolved" target="_self">Resolved Disks</a><a href="index.php?catalog=candidate" target="_self">Unresolved Disks</a><a href="index.php?catalog=refuted" target="_self">Refuted Disks</a></span></span>
</a><a class="col-2" href="contribute.php">Contribute
</a></div></div>


<div id="banner"><div class="pagetitle" ><div><span><img src="layout/imgs/pagetitle.png" alt="Catelog of Circumstellar Disks" /></span></div></div><img src="layout/imgs/banner.png" class="banner"  /></div>

<div id="content" class="col-12">
<h1><!-- InstanceBeginEditable name="pagetitle" -->
<?php 
echo $name; 
if ($disk['date'] > $sixmonths) echo "<img src='".root."layout/imgs/new1.gif' width='50' align='left'/>";
echo "</h1>";
if (!($disk['secondname']=='N/A'||$disk['secondname']=='')) echo "<h3>".display_string($disk['secondname'])."</h3>";
if ($disk['status']==0) echo "<h4>Candidate Object</h4>";
if ($disk['status']==-1) echo "<h4>Refuted Object</h4>";
?>
<!-- InstanceEndEditable --></h1><hr />

<!-- InstanceBeginEditable name="tabbar" -->
<!-- InstanceEndEditable -->


<!-- InstanceBeginEditable name="content" -->

<?php
include "show/show.php";
?>


<!-- InstanceEndEditable -->
<br />
<div id="footer">Created by Caer McCabe. Redesigned by Isabelle H. Jansen. Maintained by <a href="mailto:Karl.R.Stapelfeldt at jpl.nasa.gov">Karl Stapelfeldt</a>. Last updated <?php 
if (isset($disk_id)) $edit = prepare_query1("SELECT date FROM edits WHERE disk_id = ? ORDER BY date_dec DESC LIMIT 1",$disk_id); 
else $edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1"); 

echo date("F j, Y",strtotime($edit['date'])); ?>.</div>
</div>

</body>
<!-- InstanceEnd --></html>
