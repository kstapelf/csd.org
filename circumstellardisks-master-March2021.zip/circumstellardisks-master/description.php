<?php
header("Cache-Control: no-store");
header("Pragma: no-cache");
header("Content-Security-Policy: default-src 'self';");
header("X-Content-Type-Options: nosniff");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/default.dwt.php" codeOutsideHTMLIsLocked="false" -->
<!-- InstanceBeginEditable name="initialize" -->
<?php

	define("root","");
	require root."library.inc.php";

?>
<!-- InstanceEndEditable -->

<?php 
	//new is 2 months ago
	$sixmonths = date("Y-m-d",time()-(2*30*24*60*60));
	
?>


<head>
<!--Code written by Isabelle Jansen. Written for http://www.circumstellardisks.org/. Copyright 2016.-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- InstanceBeginEditable name="Keywords" --><meta name="keywords" content=""><!-- InstanceEndEditable -->
<base target="_blank">

<link rel="stylesheet" type="text/css" href="layout/main.css" />
<link rel="stylesheet" type="text/css" href="layout/mobile.css" />
<script type="text/javascript" src="ajax/jquery-3.5.1.min.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Catalog of Circumstellar Disks | Catalog Description</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->

<!-- InstanceEndEditable -->
</head>

<body>

<div id="navbar" class="container">
<div>
<a class="col-2" href="index.php" target="_self">Home
</a><a class="col-2" href="search.php" target="_self">Search
</a><a class="col-2" href="updates.php" target="_self">What's New
</a><a class="col-2" href="<?php echo root; ?>description.php" target="_self">Catalog Description
</a><span class="col-2 hover">Catalogs
<span><a href="index.php?catalog=resolved" target="_self">Resolved Disks</a><a href="index.php?catalog=candidate" target="_self">Unresolved Disks</a><a href="index.php?catalog=refuted" target="_self">Refuted Disks</a></span></span>
</a><a class="col-2" href="contribute.php">Contribute
</a></div></div>


<div id="banner"><div class="pagetitle" ><div><span><img src="layout/imgs/pagetitle.png" alt="Catelog of Circumstellar Disks" /></span></div></div><img src="layout/imgs/banner.png" class="banner"  /></div>

<div id="content" class="col-12">
<h1><!-- InstanceBeginEditable name="pagetitle" -->
Catalog Description
<!-- InstanceEndEditable --></h1><hr />

<!-- InstanceBeginEditable name="tabbar" -->
<!-- InstanceEndEditable -->


<!-- InstanceBeginEditable name="content" -->
<div class="section">
<h3></h3>
<p>For an object to be included in this database it must have a
published, refereed, article that shows: </p>
<ul> 
<li>spatially resolved scattered light, thermal continuum or line emission from the circumstellar disk, or, 
<li> the presence of a shadowed dark lane from the disk midplane,
</ul>
<p> on which the outer disk radius can be measured. <BR>
Some of these objects include significant extended envelope emission. These are included only if the disk itself has been resolved as well.  Objects whose resolved disk detection has been refuted are not
included. For each object, the following information is
provided:</p>

<h3>Name</h3>
<p>Commonly used name for the object. Click on the name to bring up detailed page on the object. Clicking on the 'Object' column header will allow you to reorder the table in alphabetical or reverse alphabetical order.
</p>

<p>The information page on each object provides a table with the basic
information for the star (coordinates, spectral type, distance) and
the disk (position angle, disk inclination and reference for this
information, when available).  A list of published, refereed,
references is also provided for each star. This list is not complete;
references that provide information on the resolved disk or the
unresolved disk at wavelengths longer than 1 micron are provided,
along with theoretical/modelling papers that are specific to the
object in question. </p>

<h3>Spectral type</h3>
<p>If known, the spectral type of the central star is provided. Clicking on the SpTy column header will re-sort the table in alphabetical or reverse alphabetical order.</p>

<h3>Category</h3>
<p>The stars are classified in the category column based on mass and age.</p>
<ul> 
<li>TT = T Tauri star (typically < 2 solar masses)</li>
<li>Hae = Herbig Ae or Be type star</li>
<li>MS = star is on Main Sequence</li>
<li>YSO = Object appears younger than TT or Hae stage in that it shows significant envelope emission</li>
<li>Trans = A transition object</li>
<li>PPN = protoplanetary nebula</li>
<li>UC = The central star in these systems has either not been detected or has not yet been classified. This class largely consists of 
Orion proplyd objects in which the disk silhouette is resolved</li>
</ul>
<p>Clicking on the Category column header will re-sort the table in alphabetical or reverse alphabetical order, showing all objects in the same category together.</p>

<h3>Distance</h3>
<p>The distance, in parsec, either to the star or star
forming region the star is in, is provided. Clicking on the Distance
column header will re-sort the table in either increasing or decreasing
distance.</p>

<h3>Disk Diameter</h3>
<p>For a specific wavelength (listed in the last
column of the table) the diameter of the resolved emission is
provided, in both arcsec and AU (if the distance is known).The extent
of disk emission can vary significantly depending on whether you are
observing scattered light or mm line emission; we provide the largest
measurement available for each disk, the reference to which is
highlighted with an asterisk on the object details page.  Clicking on
the Disk diameter column header will re-sort the table in either
increasing or decreasing disk size.</p>

<h3>Inclination</h3>
<p>The inclination angle of the disk is provided
when it has been calculated in the literature; in some cases this
value is model dependent. We define inclination to be the angle
between the line of sight and the normal to the disk plane, i.e.,
face-on disks have i = 0, whereas edge-on disks have i = 90 degrees.
Where necessary, measurements in the literature have been converted to
this definition. Clicking on the inclination column header will
re-sort the table in either increasing or decreasing inclination
angle.</p>

<h3>How well resolved </h3>
<p>This measurement provides a
rough quantification of how well resolved each disk is. Taking the
disk diameter at the reference wavelength listed (last column in
table), the number of diffraction beams that can fit in the disk
diameter is calculated.  Clicking on the column header will re-sort the
table in either increasing or decreasing inclination angle.  <BR> Note, 
this is highly dependent on the wavelength of observation.  The
extent of disk emission can vary significantly depending on whether
you are observing scattered light or mm line emission.</p>

<h3>At ref. wavelength</h3>
<p>Lists the wavelength at which the disk
diameter and 'how well resolved' columns are calculated. The
publication which provided the disk size is highlighted by an asterisk
on the object details page.</p>


<h3>How often is this catalog updated?</h3>
<p>Newly resolved disks will be added as we become aware of them. You
can help by pro-actively sending your object and journal citation <a
href="contribute.php">to us</a>. References for each object will
be updated at least quarterly.</p>
</div>

<!-- InstanceEndEditable -->
<br />
<div id="footer">Created by Caer McCabe. Redesigned by Isabelle H. Jansen. Maintained by <a href="mailto:Karl.R.Stapelfeldt at jpl.nasa.gov">Karl Stapelfeldt</a>. Last updated <?php 
if (isset($disk_id)) $edit = prepare_query1("SELECT date FROM edits WHERE disk_id = ? ORDER BY date_dec DESC LIMIT 1",$disk_id); 
else $edit = query1("SELECT date FROM edits ORDER BY date_dec DESC LIMIT 1"); 

echo date("F j, Y",strtotime($edit['date'])); ?>.</div>
</div>

</body>
<!-- InstanceEnd --></html>
