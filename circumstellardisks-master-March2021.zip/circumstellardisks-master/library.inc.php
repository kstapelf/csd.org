<?php 
//session_start();

if (!defined('root')) {
	define('root',"");
}

date_default_timezone_set("America/Los_Angeles");

try {
	$database = new PDO("sqlite:".root."../disk_symlinks/resd_disks.db");
	} catch (PDOException $e) {
		echo "Failed to get DB handle: " . $e->getMessage() . "\n";
		exit;
	}

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
//Database Functions
//Protects against injection
define("prepare_query","prepare_query");

function prepare_query() {
	global $database;
	
	$arg_list = func_get_args();
	$query = $arg_list[0];
	
	
	$stmt = $database->prepare($query);
	if (!$stmt) {
		echo "\nPDO::errorInfo():\n";
		print_r($database->errorInfo());
		return false;
	} else {
		$stmt->execute(array_slice($arg_list,1));
		$result = $stmt->fetchAll();
		return $result;
	}
}

//Runs a simple parameter-less query
function query($query) {
	global $database;
	
	$result = array();
	foreach ($database->query($query) as $row) {
		$result[] = $row;
	}
	
	$err = $database->errorInfo();
	if ($err[0]!="00000") echo $err[2];
	return $result;
}

//Protects against injection. Returns first row only.
function prepare_query1() {
	$result = call_user_func_array(prepare_query,func_get_args());
	if ($result) return $result[0];
	else return array();
}

//Runs a simple parameter-less query. Returns first row only.
function query1($query) {
	$result = query($query);
	if ($result) return $result[0];
	else return array();
}

//Same as prepare_query, but does not display error messages
function prepare_query_no_err() {
	global $database;
	
	$arg_list = func_get_args();
	$query = $arg_list[0];
	
	$stmt = $database->prepare($query);
	if (!$stmt) {
		return false;
	} else {
		$stmt->execute(array_slice($arg_list,1));
		$result = $stmt->fetchAll();
		return $result;
	}
}

//Prepares a query for multiple uses
function prepare_multiquery($query) {
	global $database;
	
	$stmt = $database->prepare($query);
	if (!$stmt) {
		echo "\nPDO::errorInfo():\n";
		print_r($database->errorInfo());
		return false;
	} else {
		return $stmt;
	}
}

function execute_multiquery() {
	$arg_list = func_get_args();
	
	$stmt = $arg_list[0];
	
	$stmt->execute(array_slice($arg_list,1));
	$result = $stmt->fetchAll();
	return $result;
}

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
//XML Functions
function load_xml($filepath) {
	libxml_use_internal_errors(true);
	$objXML = simplexml_load_file($filepath);
	
	if ($objXML === false) {
		$errors = libxml_get_errors();
	  	foreach($errors as $error) {
			echo $error->message,'<br/>';
	 	}
	  	return false;
	} else return $objXML;
}

function save_xml($handle,$filepath) {
	$handle->asXML($filepath);
}

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
//Sanitation Functions
//replaces tags with HTML entities.
function clean($string) {
	$string = trim($string);
	return htmlentities(get_magic_quotes_gpc()?stripslashes($string):$string,ENT_QUOTES,"UTF-8");
}

function clean_string($string) {
	//replace <$tag> with [$tag] before cleaning
	$allow = array("b","i","u","table","tr","th","td","tab");
	
	foreach ($allow as $tag) {
		$string = str_replace("<$tag>","[$tag]",$string);
		$string = str_replace("</$tag>","[/$tag]",$string);
	}
	
	$string = clean($string);
	return $string;
}

function clean_textarea($string) {
	return str_replace("</textarea>","",get_magic_quotes_gpc()?stripslashes($string):$string);
}

function display_string($string) {
	return add_html($string);
}

function display_textarea($string) {
	return add_html(clean_string(get_magic_quotes_gpc()?addslashes($string):$string));
}

//Allows <br>, <b>, <i>, and table tags
function add_html($string) {
	$allow = array("b","i","u","table","tr","th","td");
	
	foreach ($allow as $tag) {
		$string = str_replace("[$tag]","<$tag>",$string);
		$string = str_replace("[/$tag]","</$tag>",$string);
	}
	
	$string = str_replace("[br]","<br />",$string);
	$string = str_replace("[gap]","&nbsp;",$string);
	$string = str_replace("[gap5]","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",$string);
	
	//parse a quick table
	// syntax:
	// indicate start of table with [tab]
	// and end of table with [/tab]
	// between tags, a single "|" means "</td><td>"
	// and double "||" means "</td></tr><tr><td>"
	$regex1='/\[tab\]([^]]+)\[\/tab\]/';
	$regex2='/(\[tab\][^]]+\[\/tab\])/';
	
	preg_match_all($regex1, $string, $arr);
	$eResult=array();
	foreach($arr[1] as $k=>$v) {
		$v = str_replace(array("\r", "\n"), "", $v);
		$v = str_replace("||", "</td></tr><tr><td>", $v);
		$v = str_replace("|", "</td><td>", $v);
		$eResult[$k]="<table class='borders'><tr><td>".$v."</td></tr></table>";
	}
	foreach($eResult as $r) {
	  $string = preg_replace($regex2, $r, $string, 1);
	}
	
	return nl2br($string);
}



//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
//Navigation Functions
function go_to($address) {
	$next_page = "Location: $address";
    header($next_page);
}


//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
//DateTime Functions

//Formats a datestring
function get_date($date,$format="Y-m-d") {
	if ($date=="today") {
		return date($format);
	}
	if ($date != NULL) {
		$dh = date_create($date);
		return date_format($dh,$format);
	} else {
		return "";
	}
}

function position_to_degrees($position) {
	//follows pattern of +dd dd dd.dd
		//1. optional +/-
		//2. (2 digits followed by a space) times 2
		//3. 2 digits, followed optionally by a . and then more digits
	if (preg_match('/^[+\-]?(\d{2} ){2}\d{2}(\.\d+)?$/',$position)) {
		$split = explode(" ",$position);
		$m1 = 15;
		$m2 = 1;
		if ($position[0]=='-' || $position[0]=='+') {
			$m1 = 1;
			if ($position[0]=='-') $m2 = -1;
		}
		
		return $m1*$m2*($m2*floatval($split[0])+floatval($split[1])/60+floatval($split[2])/3600);
	} else if (is_numeric($position)) {
		return $position;
	} else {
		return NULL;
	}	
}

function degrees_to_posistion($degree,$type) {
	$m2 = 1;
	if ($type == "dec") {
		$format = "%02d %02d %04.1f";
		//start with +/-
		$pre = "+";
		if ($degree < 0) {
			$pre = "-";
			$m2 = -1;
		}
		$m1 = 1;
	} else {
		$format = "%02d %02d %05.2f";
		$pre = "";
		$m1 = 15;
	}
	
	$r1 = $degree/$m1*$m2; //to positive number
	
	$r2 = ($r1 - floor($r1))*60;
	$r3 = ($r2 - floor($r2))*60;
	
	return $pre.sprintf($format,floor($r1),floor($r2),$r3);
}

//generates a query string to find stars within a certain angular distance
function near($ra,$dec,$degrees = 0.0003) {
	//convert ra/dec to degrees
	
	$r = position_to_degrees($ra);
	$d = position_to_degrees($dec);
	
	$degrees = abs($degrees);
	
	//find search in a box
	if (is_numeric($r)&&is_numeric($d)) {
		return array("query" => "(ra_deg BETWEEN ? AND ?) AND (dec_deg BETWEEN ? AND ?)", "args" => array($r - $degrees,$r + $degrees,$d - $degrees,$d + $degrees));
	} else return array("query" => "","args" =>array());
}


function date_to_dec($date) {
	$datetime = strtotime($date);
	
	if (is_numeric($date)) {
		return $date;
	} else if ($datetime) {
		$year = date("Y",$datetime);
		$month = date("m",$datetime);
		$day = date("d",$datetime);
		return ($year + ($month-1)/12 + ($day-1)/(12*31));
	} else return NULL;
}

function datetime_to_dec($date) {
	$datetime = strtotime($date);
	
	if (is_numeric($date)) {
		return $date;
	} else if ($datetime) {
		$year = date("Y",$datetime);
		$month = date("m",$datetime);
		$day = date("d",$datetime);
		
		$hour = date("H",$datetime);
		$minute = date("i",$datetime);
		$sec = date("s",$datetime);
		
		$date_dec = $sec/60;
		$date_dec = ($date_dec + $minute)/60;
		$date_dec = ($date_dec + $hour)/24;
		$date_dec = ($date_dec + ($day-1))/31;
		$date_dec = ($date_dec + ($month-1))/12;
		$date_dec = $date_dec + $year;
		return $date_dec;
	} else return NULL;
}

function convert_to_mag($measurement,$uncertainty,$units,$band_id) {
		switch ($units) {
			case "Jy":
				$Jy = $measurement;
				//get fdefault
				extract(prepare_query1("SELECT fdefault FROM bands WHERE band_id = ?",$band_id));
				
				//convert according to:
					//Mag = log10(Jy/fdefault)*(-2.5)
					//(uncMag)^2 = ([dMag/dJ]*uncJ)^2 => uncMag = abs(uncJ/Jy * 2.5/ln(10))
					$const = 1.08574; // = 2.5/ln(10)
					return array("mag"=>-1*$const*log($Jy/$fdefault),"unc"=>($uncertainty<0?-1:$uncertainty*$const/$Jy),"units"=>"Mag");
				break;
			case "Mag":
			default:
				return array("mag"=>$measurement,"unc"=>$uncertainty,"units"=>"Mag");
		}
	}

function convert_to_jy($measurement,$uncertainty,$units,$band_id) {
		switch ($units) {
			case "Mag":
				$Mag = $measurement;
				//get fdefault
				if (in_array($band_id,array(10,11,12,13))) {
					//WISE color correction ***
					extract(prepare_query1("SELECT fdefault FROM bands WHERE band_id = ?",$band_id));
				} else extract(prepare_query1("SELECT fdefault FROM bands WHERE band_id = ?",$band_id));
				
				//convert according to:
					//Jy = fdefault * 10^(-Mag/2.5)
					//(uncJy)^2 = ([dJ/dMag]*uncMag)^2 => uncJy = fdefault*ln(10)/2.5*exp(-Mag*ln(10)/2.5)
					//(uncJy)^2 = fdefault 
					$const = 0.92103; // = ln(10)/2.5
					return array("mag"=>$fdefault*exp(-1*$const*$Mag),"unc"=>($uncertainty<0?-1:$fdefault*$const*exp(-1*$const*$Mag)),"units"=>"Jy");
				break;
			case "Jy":
			default:
				return array("mag"=>$measurement,"unc"=>$uncertainty,"units"=>"Jy");
		}
	}
	
function units_conversion($units_to,$units_from,$measurement,$uncertainty,$band_id) {
	switch ($units_to) {
		case "Jy":
			return convert_to_jy($measurement,$uncertainty,$units_from,$band_id);
		case "Mag":
			return convert_to_mag($measurement,$uncertainty,$units_from,$band_id);
		default:
			return array("mag"=>$measurement,"unc"=>$uncertainty,"units"=>$units_from);
	}
}
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

function get_all_disk_references($disk_id) {
	return prepare_query("SELECT * FROM refs AS r INNER JOIN disk_refs AS dr ON r.ref_id = dr.ref_id WHERE dr.disk_id = ? ORDER BY r.date_dec DESC, r.authors ASC",$disk_id);
}

function get_all_reference_disks($ref_id) {
	return prepare_query("SELECT * FROM disks AS d INNER JOIN disk_refs AS dr ON d.disk_id = dr.disk_id WHERE dr.ref_id = ? ORDER BY UPPER(d.name) ASC",$ref_id);
}

function get_ref_by_dr($dr_id) {
	$refs = prepare_query("SELECT * FROM disk_refs as dr
								INNER JOIN refs AS r ON dr.ref_id = r.ref_id 
								WHERE dr.ref_id = (SELECT ref_id FROM disk_refs WHERE dr_id = ?) 
								AND dr.disk_id = (SELECT disk_id FROM disk_refs WHERE dr_id = ?)",$dr_id,$dr_id);
	if (count($refs)) return $refs;
	else return false;
}


//show reference with title
function display_ref($dr_id,$path="",$wrapper = true) {
	//possible there's  more than 1!
	$refs = get_ref_by_dr($dr_id);
	if ($refs) {
		$ref = $refs[0];
		$count = count(prepare_query("SELECT DISTINCT disk_id FROM disk_refs WHERE ref_id = ?",$ref['ref_id'])) - 1;
		
		if ($wrapper) echo "<div id=\"refid".$ref['ref_id']."\" class=\"container display alternate ref\" ref=\"".$ref['dr_id']."\">";
			echo "<div>";	
			echo "<span class=\"col-7\"><a class=\"bold\" href=\"".$ref['url']."\">".display_string($ref['title'])."</a>";
			echo "<p>".display_string($ref['authors'])."</p>";
			if ($count > 0) echo "<p><a href=\"".$path."reference.php?id=".$ref['ref_id']."\">$count other objects in this reference</a></p>";
			echo "</span>";
			echo "<p class=\"col-3\">".display_string($ref['description'])."</p>";
			if ($ref['photo']!="") echo "<a class=\"col-12\" href=\"".root."imgs/".$ref['photo']."\">
			<img src=\"".$path."imgs/".$ref['photo']."\" alt=\"".$ref['img_alt']."\"/></a>";
			echo "</div>";
		if ($wrapper) echo "</div>";
	}
}

//show reference with disk name
function display_disk_ref($dr_id,$path="",$wrapper = true) {
	//possible there's  more than 1!
	$refs = get_ref_by_dr($dr_id);
	if ($refs) {
		$ref = $refs[0];
		$disk = prepare_query1("SELECT * FROM disks WHERE disk_id = ?",$ref['disk_id']);
		
		if ($wrapper) echo "<div class=\"container display alternate ref\" ref=\"".$ref['dr_id']."\">";
			echo "<div>";	
			echo "<span class=\"col-8\"><a class=\"bold\" href=\"".$path."show.php?id=".$disk['disk_id']."\">".display_string($disk['name']).($disk['secondname']!=''?' ('.$disk['secondname'].')':'')."</a>";
			echo "<p>".display_string($ref['description'])."</p>";
			echo "</span>";
			if ($ref['photo']!="") echo "<a class=\"col-12\" href=\"".$path."imgs/".$ref['photo']."\">
			<img src=\"".$path."imgs/".$ref['photo']."\" alt=\"".$ref['img_alt']."\"/></a><br class='clear'>";
			echo "</div>";
		if ($wrapper) echo "</div>";
	}
}

function display_xml($entry) {
	if ($entry->title != "") echo "<h3>".display_string($entry->title)."</h3>";
	echo "<small>".get_date($entry->date,"M j, Y")."</small>";
	echo "<p>".display_string($entry->content)."</p>";
}

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

function check_disk_col($col) {
	if (prepare_query1("SELECT col FROM disk_cols WHERE col = ?",$col)) return true;
	else return false;	
}

function order_disks($col,$ra = NULL,$dec = NULL,$order = "ASC") {
	//if two words, grab only first word
	$arr = explode(' ',trim($col));
	if (count($arr) > 1) {
		$col = $arr[0];
		$order = $arr[1];
	}
	
	if (!(check_disk_col($col)||$col=="distance")) {
		$col = 'name';
	}
	
	$return_arr = array(" ORDER BY ");
	$query = "";
	$args = array();
	
	switch($col) {
		case "ra":
			$query .= "ra_deg ASC";
			break;
		case "dec":
			$query .= "dec_deg ASC";
			break;
		case "distance":
			$ra_deg = position_to_degrees($ra);
			$dec_deg = position_to_degrees($dec);
			if (is_numeric($ra_deg)) {
				$query .= "(ra_deg - ?)*(ra_deg - ?)";
				$args[] = $ra_deg; $args[] = $ra_deg;
			}
			if (is_numeric($ra_deg) && is_numeric($dec_deg)) $query.="+";
			if (is_numeric($dec_deg)) {
				$query .= "(dec_deg - ?)*(dec_deg - ?)";
				 $args[] = $dec_deg; $args[] = $dec_deg;
			}
			if (is_numeric($ra_deg) || is_numeric($dec_deg)) break;
		case "name":
			$query .= "UPPER(name)";
			break;
		case "secondname":
			$query .= "UPPER(secondname)";
			break;
		case "date":
			$query .= "date_dec";
			break;
		case "date_update":
			$query .= "date_update_dec";
			break;
		default:
			$query .= $col;
	}
	
	if ($order == "DESC") $query.= " DESC";
	else $query.= " ASC";
	$return_arr[] = $query;
	$return_arr[] = $args;
	
	return $return_arr;
}

?>